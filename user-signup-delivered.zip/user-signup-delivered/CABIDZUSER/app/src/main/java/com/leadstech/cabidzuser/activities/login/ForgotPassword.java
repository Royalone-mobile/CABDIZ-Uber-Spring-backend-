package com.leadstech.cabidzuser.activities.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.jawadali.myapplication.backend.signUPApi.SignUPApi;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.cloud_apis.JsonAPICall;
import com.leadstech.cabidzuser.cloud_apis.MakeAPICall;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.singleton.URLs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.leadstech.cabidzuser.singleton.StaticFunctios.PostMethod;

public class ForgotPassword extends AppCompatActivity implements APIResponseListner {
    Button Submit;
    EditText Email;
    ImageView BACK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        Submit = (Button) findViewById(R.id.submit);
        Email = (EditText) findViewById(R.id.email);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Email.getText().length() > 0){
                    Map<String, String> parm = new HashMap<String, String>();
                    parm.put("email" , Email.getText().toString());
                    new MakeAPICall(ForgotPassword.this,parm,PostMethod, URLs.EmailVerfication, APIActions.ApiActions.email_verfication,ForgotPassword.this).execute();
                }else {
                    Toast.makeText(getApplicationContext(),"Enter email address",Toast.LENGTH_SHORT).show();
                }
            }
        });

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apieActions) {
        Log.d("response", response+"sd");
        if(apieActions == APIActions.ApiActions.email_verfication){
            if(response.status.equalsIgnoreCase("false")){
                this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Map<String, String> parm = new HashMap<String, String>();
                        parm.put("email" , Email.getText().toString());
                        parm.put("name" , "User");
                        parm.put("subject" , "Password Recovery!");
                        parm.put("text" , "Please use the following link to reset your password! <a href='https://0-dot-massive-amulet-153623.appspot.com/forgot_password.html'> <h1> Rest Password </h1> </a>");
                      new MakeAPICall(ForgotPassword.this, parm , PostMethod ,URLs.SendEmail , APIActions.ApiActions.send_email,ForgotPassword.this).execute();
                    }
                });
            }else {
                Toast.makeText(getApplicationContext(),"Email not Exist!!",Toast.LENGTH_SHORT).show();
                Email.setText("");
                Email.setError("Email not Exist!!");
                Email.requestFocus();
            }
        }else if(apieActions == APIActions.ApiActions.send_email) {
            if(response.status.equalsIgnoreCase("true")){
                Toast.makeText(getApplicationContext(),response.message,Toast.LENGTH_SHORT).show();
                finish();
            }else{
                Toast.makeText(getApplicationContext(),response.message,Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apieActions) {
        Log.d("response", response+"eroor");
    }
}
