package com.leadstech.cabidzuser.activities.login;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.provider.ContactsContract;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.cloud_apis.JsonAPICall;
import com.leadstech.cabidzuser.cloud_apis.MakeAPICall;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;
import com.leadstech.cabidzuser.singleton.StripeResponse;
import com.leadstech.cabidzuser.singleton.URLs;
import com.stripe.android.TokenCallback;
import com.stripe.android.exception.APIConnectionException;
import com.stripe.android.exception.InvalidRequestException;
import com.stripe.android.model.BankAccount;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;
import com.stripe.exception.APIException;
import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.model.Customer;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static com.leadstech.cabidzuser.activities.login.SignupStepOne.parm;
import static com.leadstech.cabidzuser.activities.login.Varification_number.is_update_email;
import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.ShowProgress;
import static java.security.AccessController.getContext;

public class SignupSecondStep extends AppCompatActivity implements APIResponseListner, StripeResponse {
    Button NEXT;
    ImageView BACK;
    ImageView Profile;
    boolean isDrawerLeftSelect = false;
    Context context;
    String ERROR_MSG = "";
    String month_txt = "", year_txt = "";
    Spinner mnth_spinner, year_cpinner;
    EditText First_Name, Last_Name, _PH, _Email, Password, Credit_card, Card_CVC, Postal_code;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_second_step);
        context = this;
        Profile = (ImageView) findViewById(R.id.profile_img);
        if (!SharedPrefrences.getString("profile_pic", SignupSecondStep.this).equalsIgnoreCase("null")) {
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic", SignupSecondStep.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
        First_Name = (EditText) findViewById(R.id.firstname_txt);
        Last_Name = (EditText) findViewById(R.id.lastname_text);
        _PH = (EditText) findViewById(R.id.phone_number_txt);
        _Email = (EditText) findViewById(R.id.email_txt);
        Password = (EditText) findViewById(R.id.password);
        Credit_card = (EditText) findViewById(R.id.card_number);
        Card_CVC = (EditText) findViewById(R.id.card_cvc);
        Postal_code = (EditText) findViewById(R.id.postal_code);

        mnth_spinner = (Spinner) findViewById(R.id.mnth);
        year_cpinner = (Spinner) findViewById(R.id.year);

        year_cpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if (i > 0) {
                    year_txt = adapterView.getItemAtPosition(i).toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                year_txt = "";
            }
        });

        mnth_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if (i > 0) {
                    month_txt = adapterView.getItemAtPosition(i).toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                month_txt = "";
            }
        });

        Credit_card.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (Credit_card.getText().length() > 0) {
                    if (!isDrawerLeftSelect) {
                        if (Credit_card.getText().toString().charAt(0) == '4') {
                            isDrawerLeftSelect = true;
                            Drawable img = SignupSecondStep.this.getResources().getDrawable(R.drawable.visa_card);
                            img.setBounds(0, 0, 95, 70);
                            Credit_card.setCompoundDrawables(img, null, null, null);
                        } else if (Credit_card.getText().toString().charAt(0) == '5') {
                            isDrawerLeftSelect = true;
                            Drawable img = SignupSecondStep.this.getResources().getDrawable(R.drawable.master_card);
                            img.setBounds(0, 0, 95, 70);
                            Credit_card.setCompoundDrawables(img, null, null, null);
                        }
                    }
                } else {
                    isDrawerLeftSelect = false;
                    Credit_card.setCompoundDrawables(null, null, null, null);
                }
            }
        });
        NEXT = (Button) findViewById(R.id.next);
        NEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("date = ", month_txt + "/" + year_txt);
                if (First_Name.getText().length() == 0 ||
                        Last_Name.getText().length() == 0 ||
                        _Email.getText().length() == 0 ||
                        _PH.getText().length() == 0 ||
                        Password.getText().length() == 0 ||
                        Credit_card.getText().length() == 0 ||
                        Card_CVC.getText().length() == 0 ||
                        Postal_code.getText().length() == 0 ||
                        month_txt.length() == 0 ||
                        year_txt.length() == 0) {
                    Toast.makeText(getApplicationContext(), "all fields are required!", Toast.LENGTH_SHORT).show();
                    if (_Email.getText().length() == 0) {
                        _Email.setError("Email required");
                    }
                    if (_PH.getText().length() == 0) {
                        _PH.setError("PhoneNumber required");
                    }

                } else {
                    if (Credit_card.getText().length() < 16) {
                        Credit_card.setError("invalid card number");
                        Toast.makeText(getApplicationContext(), "Enter correct Card number", Toast.LENGTH_SHORT).show();
                    } else {
                        CreateNewStripeCustomer(Credit_card.getText().toString(), month_txt, year_txt, Card_CVC.getText().toString(), _Email.getText().toString(), SignupSecondStep.this);
//                        JSONObject jsonBody = null;
//                        try {
//                            jsonBody = new JSONObject("{\n" +
//                                    "\"creditCardNo\":\""+Credit_card.getText().toString()+"\"" +
//                                    "}\n");
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                        new JsonAPICall(SignupSecondStep.this,jsonBody, Request.Method.POST, URLs.CreditCardVerification, APIActions.ApiActions.credit_card_verfication,SignupSecondStep.this);
                    }
                }
            }
        });

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        setText();
    }

    public void setText() {
        First_Name.setText(parm.get("first_name"));
        Last_Name.setText(parm.get("last_name"));
        _PH.setText(parm.get("phone_number"));
        _Email.setText(parm.get("email"));
        Password.requestFocus();
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if (apiActions == APIActions.ApiActions.credit_card_verfication) {
            if (response.status != null && response.status.equalsIgnoreCase("success")) {
                Random random = new Random();
                String code = String.format("%04d", random.nextInt(10000));
                parm.put("code", code);
                Log.d("codee--------", "\n\n" + code);
                JSONObject jsonBody = null;
                try {
                    jsonBody = new JSONObject("{\n" +
                            "\"from\":\"no-reply@cabidz.com\",\n" +
                            "\"subject\":\"Email Verification!\",\n" +
                            "\"message\":\"your verification code is = " + code + "\",\n" +
                            "\"email_where_to_send\":\"" + _Email.getText().toString() + "\"\n" +
                            "}\n");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                new JsonAPICall(SignupSecondStep.this, jsonBody, Request.Method.POST, URLs.SendEmail, APIActions.ApiActions.send_email, SignupSecondStep.this);
            } else {
                Credit_card.setError("Invalid Card");
                Credit_card.requestFocus();
                Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
            }
        } else if (apiActions == APIActions.ApiActions.send_email) {
            if (response.status.equalsIgnoreCase("true")) {
                parm.put("password", Password.getText().toString());
                parm.put("card_number", Credit_card.getText().toString());
                parm.put("card_expiry", month_txt + "/" + year_txt);
                parm.put("card_cvc", Card_CVC.getText().toString());
                parm.put("postal_code", Postal_code.getText().toString());
                GOTO(SignupSecondStep.this, Varification_number.class);
            } else {
                if (response.message == null) {
                    Toast.makeText(getApplicationContext(), "Email verification failed try again later!!", Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (is_update_email) {
            _Email.setText("");
            _Email.requestFocus();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (is_update_email) {
            _Email.setText("");
            _Email.requestFocus();
        }
    }

    public void CreateNewStripeCustomer(final String cardNumber, final String cardExpMonth, final String cardExpYear, final String cardCVC, final String Email, final StripeResponse response) {
        ShowProgress(SignupSecondStep.this);
        com.stripe.Stripe.apiKey = "sk_test_n8hO8g8giswb1pE1OOpDliSC";
        com.stripe.android.Stripe stripe = new com.stripe.android.Stripe(SignupSecondStep.this);
        stripe.setDefaultPublishableKey("pk_test_2BdrpyDNN2Vy5r220T9xp2d3");
        Card card = new Card(
                cardNumber,
                Month(cardExpMonth),
                Integer.parseInt(cardExpYear),
                cardCVC
        );
        stripe.createToken(card, new TokenCallback() {
            @Override
            public void onError(Exception error) {
                HideProgress();
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onSuccess(Token token) {
                final Map<String, Object> customerParams = new HashMap<String, Object>();
                customerParams.put("email", Email);
                customerParams.put("source", token.getId());
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        try {
                            Customer customer =  Customer.create(customerParams);
                            parm.put("stripe_id" , customer.getId());
                            response.getResponse(true);
                        } catch (AuthenticationException | com.stripe.exception.InvalidRequestException | com.stripe.exception.APIConnectionException | CardException | APIException e) {
                           e.printStackTrace();
                            ERROR_MSG = e.getMessage();
                            response.getResponse(false);
                        }
                    }
                };
                thread.start();
            }
        });
    }

    @Override
    public void getResponse(final boolean status) {

        this.runOnUiThread(new Runnable() {
            public void run() {
                if(status){
                    HideProgress();
                    Random random = new Random();
                    String code = String.format("%04d", random.nextInt(10000));
                    parm.put("code", code);
                    Log.d("codee--------", "\n\n" + code);
                    Map<String, String> parm = new HashMap<String, String>();
                    parm.put("email", _Email.getText().toString());
                    parm.put("name", "User");
                    parm.put("subject", "Email Verification!");
                    parm.put("text", "your verification code is = <h2>" + code + " </h2>");
                    new MakeAPICall(SignupSecondStep.this, parm, PostMethod, URLs.SendEmail, APIActions.ApiActions.send_email, SignupSecondStep.this).execute();

                }else {
                    HideProgress();
                    Toast.makeText(getApplicationContext(), ERROR_MSG , Toast.LENGTH_LONG).show();
                }
             }
        });
    }

    public static int Month(String mtnh) {
        switch (mtnh) {
            case "January":
                return 1;
            case "February":
                return 2;
            case "March":
                return 3;
            case "April":
                return 4;
            case "May":
                return 5;
            case "June":
                return 6;
            case "July":
                return 7;
            case "August":
                return 8;
            case "September":
                return 9;
            case "October":
                return 10;
            case "November":
                return 11;
            case "December":
                return 12;
            default:
                return 0;
        }
    }
}
