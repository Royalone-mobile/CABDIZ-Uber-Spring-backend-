package com.leadstech.cabidzuser.cloud_apis;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;

import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.leadstech.cabidzuser.activities.login.ForgotPassword;
import com.leadstech.cabidzuser.model.LoginResponse;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.singleton.URLs;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class JsonAPICall {
    private Context context;
    private JSONObject jsonBody;
    private int Method;
    private String URL;
    private APIActions.ApiActions serviceAction;
    private APIResponseListner apiResponseListner;
    KProgressHUD pd;

    public JsonAPICall(Context context, JSONObject pairameters, int method, String url , APIActions.ApiActions service_action, APIResponseListner api_responseListner ) {
        this.jsonBody = pairameters;
        this.Method = method;
        this.URL = url;
        this.context = context;
        this.apiResponseListner =  api_responseListner;
        this.serviceAction = service_action;
        pd = KProgressHUD.create(this.context).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setCancellable(false).setAnimationSpeed(1).setDimAmount(0.5F).setWindowColor(Color.parseColor("#3EC79C")).show();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Method,url, jsonBody, new com.android.volley.Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                pd.dismiss();
                Log.d("Response",response+"");
                pd.dismiss();
                if (apiResponseListner != null && response != null) {
                    apiResponseListner.onRequestSuccess(genrateResponse(response.toString(),serviceAction), serviceAction);
                } else if (apiResponseListner != null) {
                    apiResponseListner.onRequestError(genrateResponse(response.toString(),serviceAction), serviceAction);
                }
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pd.dismiss();
                Log.d("Response",error.getMessage()+"");
                Response resp = new Response();
                resp.error = error.getMessage();
                resp.status = "failed";
                apiResponseListner.onRequestError(resp, serviceAction);
            }
        });
        Volley.newRequestQueue(context).add(jsonObjectRequest);
    }
    private Response genrateResponse(String response, APIActions.ApiActions actions){
        Gson mGson = new Gson();
        switch (actions){
            case log_in:
                return  mGson.fromJson(response, LoginResponse.class );
            case send_email:
                return  mGson.fromJson(response, Response.class );
            default:
                return mGson.fromJson(response, Response.class );
        }
    }
}