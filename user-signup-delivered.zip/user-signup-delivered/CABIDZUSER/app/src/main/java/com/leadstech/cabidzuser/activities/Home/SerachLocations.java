package com.leadstech.cabidzuser.activities.Home;

import android.content.Context;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;

import java.util.ArrayList;

import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;

public class SerachLocations extends AppCompatActivity {
    EditText Where_To;
    ImageView BACK;
    ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_serach_locations);
        Where_To = (EditText) findViewById(R.id.where_to);
        Where_To.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(Where_To, InputMethodManager.SHOW_IMPLICIT);
        list = (ListView) findViewById(R.id.list_view);
        ArrayList<String> list_data = new ArrayList<>();
        list.setAdapter(new SearchListAdapter(SerachLocations.this,list_data));
        if(!SharedPrefrences.getBool("isLocationDialog",SerachLocations.this)){
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    SharedPrefrences.SetBool("isLocationDialog",true,SerachLocations.this);
                    GOTO(SerachLocations.this, LocationEnalment.class);
                }
            }, 100);
        }
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Where_To.setText("Parramatta Rd 116");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        GOTO(SerachLocations.this, CarSelectionScreen.class);
                        finish();
                    }
                }, 1000);
            }
        });
    }
}
