package com.leadstech.cabidzuser.activities.Home;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Point;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bruce.pickerview.popwindow.DatePickerPopWin;
import com.bruce.pickerview.popwindow.TimePickerPopWin;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.Projection;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.leftMenu.PastTrips;
import com.leadstech.cabidzuser.activities.leftMenu.PaymentActivity;
import com.leadstech.cabidzuser.activities.leftMenu.SettingActivity;
import com.leadstech.cabidzuser.activities.leftMenu.UpcomingTrip;
import com.leadstech.cabidzuser.activities.login.LoginSelection;
import com.leadstech.cabidzuser.activities.trip.TripHelp;
import com.leadstech.cabidzuser.cloud_apis.MakeAPICall;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;
import com.leadstech.cabidzuser.singleton.StaticFunctios;
import com.leadstech.cabidzuser.singleton.URLs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.leadstech.cabidzuser.activities.login.Login.login_parm;
import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.PostMethod;

public class HomeScreen extends AppCompatActivity implements OnMapReadyCallback, LocationListener, View.OnClickListener, APIResponseListner {

    private GoogleMap mMap;
    Button WHERE_TO, NOW,Picker_button;
    DrawerLayout drawerLayout;
    ImageView Menu_btn ,Profile;
    RelativeLayout PickerLayout;
    public static boolean isImageupload = false;
    TextView Time_Text, Date_Text , USERNAME;
    boolean now_tap = true;
    private LocationManager locationManager = null;
    final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 998;
    List<Marker> car_markers = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        PickerLayout = (RelativeLayout) findViewById(R.id.picker_clock);
        Picker_button = (Button) findViewById(R.id.clock_btn);
        Time_Text = (TextView) findViewById(R.id.time_text);
        Date_Text = (TextView) findViewById(R.id.date_text);

        Toolbar toolbar = (Toolbar) findViewById(R.id.my_awesome_toolbar);
        setSupportActionBar(toolbar);
        // Now retrieve the DrawerLayout so that we can set the status bar color.
        // This only takes effect on Lollipop, or when using translucentStatusBar
        // on KitKat.
        Profile = (ImageView) findViewById(R.id.profile_img);
        getDefaultImg();
        USERNAME = (TextView) findViewById(R.id.user_name);
        if(!SharedPrefrences.getString("name",HomeScreen.this).equalsIgnoreCase("null")){
            USERNAME.setText(SharedPrefrences.getString("name",HomeScreen.this));
        }
        Menu_btn = (ImageView) findViewById(R.id.menu);
        Menu_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        drawerLayout = (DrawerLayout) findViewById(R.id.my_drawer_layout);
        drawerLayout.setDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

            }

            @Override
            public void onDrawerOpened(View drawerView) {

            }

            @Override
            public void onDrawerClosed(View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });

//        ShowProgress(this);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        SetPermissions();

        WHERE_TO = (Button) findViewById(R.id.where_to);
        WHERE_TO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GOTO(HomeScreen.this, SerachLocations.class);
            }
        });

        NOW = (Button) findViewById(R.id.now_btn);
        NOW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (now_tap) {
                    now_tap = false;
                    NOW.setBackgroundColor(Color.parseColor("#d0d0d2"));
                    PickerLayout.setVisibility(View.VISIBLE);
                    PickerInit();
                } else {
                    now_tap = true;
                    NOW.setBackgroundColor(Color.parseColor("#40D294"));
                    PickerLayout.setVisibility(View.GONE);
                }
            }
        });

        Picker_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get Current Date
                PickerInit();
            }
        });
        InitDrawerClick();
    }

    public void SetPermissions() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(HomeScreen.this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(HomeScreen.this,
                    Manifest.permission.ACCESS_FINE_LOCATION) && ActivityCompat.shouldShowRequestPermissionRationale(HomeScreen.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(HomeScreen.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


    public void InitDrawerClick(){
        LinearLayout Dwl_Payment = (LinearLayout) findViewById(R.id.drw_payment);
        Dwl_Payment.setOnClickListener(this);
        LinearLayout Dwl_PastTrips = (LinearLayout) findViewById(R.id.drw_past_trips);
        Dwl_PastTrips.setOnClickListener(this);
        LinearLayout Dwl_UpComingTrip = (LinearLayout) findViewById(R.id.drw_upcoming_trips);
        Dwl_UpComingTrip.setOnClickListener(this);
        LinearLayout Dwl_Help = (LinearLayout) findViewById(R.id.drw_help);
        Dwl_Help.setOnClickListener(this);
        LinearLayout Dwl_Settings = (LinearLayout) findViewById(R.id.drw_settings);
        Dwl_Settings.setOnClickListener(this);
        LinearLayout Dwl_Logout = (LinearLayout) findViewById(R.id.drw_logout);
        Dwl_Logout.setOnClickListener(this);
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */


    public void PickerInit(){
        TimePickerPopWin timePickerPopWin=new TimePickerPopWin.Builder(HomeScreen.this, new TimePickerPopWin.OnTimePickListener() {
            @Override
            public void onTimePickCompleted(int hour, int minute, String AM_PM, String time) {
                Time_Text.setText(StaticFunctios.get12Hour(hour)+":"+minute+" "+ AM_PM);
                DatePickerPopWin pickerPopWin = new DatePickerPopWin.Builder(HomeScreen.this, new DatePickerPopWin.OnDatePickedListener() {
                    @Override
                    public void onDatePickCompleted(int year, int month, int day, String dateDesc) {
                        Date_Text.setText(StaticFunctios.Month(month)+" "+day+","+year);
                    }
                }).textConfirm("CONFIRM") //text of confirm button
                        .textCancel("CANCEL") //text of cancel button
                        .btnTextSize(16) // button text size
                        .viewTextSize(25) // pick view text size
                        .colorCancel(Color.parseColor("#999999")) //color of cancel button
                        .colorConfirm(Color.parseColor("#009900"))//color of confirm button
                        .minYear(1990) //min year in loop
                        .maxYear(2550) // max year in loop
                        .dateChose("2013-11-11") // date chose when init popwindow
                        .build();
                pickerPopWin.showPopWin(HomeScreen.this);

            }
        }).textConfirm("CONFIRM")
                .textCancel("CANCEL")
                .btnTextSize(16)
                .viewTextSize(25)
                .colorCancel(Color.parseColor("#999999"))
                .colorConfirm(Color.parseColor("#009900"))
                .build();
        timePickerPopWin.showPopWin(HomeScreen.this);


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
//        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 100, this);
        MarkerOptions marker = new MarkerOptions()
                .position(new LatLng(-37.812381, 144.962126))
                .title("Current Location")
                .alpha(1)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.current_location_pin));
        mMap.addMarker(marker);
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(
                new LatLng(-37.812381, 144.962126), 15);
        mMap.animateCamera(cameraUpdate);
        createTestCarMarkers();
    }

    @Override
    public void onLocationChanged(Location location) {
//        HideProgress();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    public void createTestCarMarkers() {
        LatLng create_newLatlng = new LatLng(-37.813325, 144.958503);
        MarkerOptions marker = new MarkerOptions()
                .position(create_newLatlng)
                .title("Car1")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker));
        LatLng create_newLatlng5 = new LatLng(-37.816569, 144.969830);
        MarkerOptions marker5 = new MarkerOptions()
                .position(create_newLatlng5)
                .title("Car5")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker5));
        LatLng create_newLatlng1 = new LatLng(-37.809135, 144.960857);
        MarkerOptions marker1 = new MarkerOptions()
                .position(create_newLatlng1)
                .title("Car2")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker1));
        LatLng create_newLatlng4 = new LatLng(-37.816873, 144.961626);
        MarkerOptions marker4 = new MarkerOptions()
                .position(create_newLatlng4)
                .title("Car4")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker4));

        LatLng create_newLatlng3 = new LatLng(-37.816101, 144.955586);
        MarkerOptions marker3 = new MarkerOptions()
                .position(create_newLatlng3)
                .title("Car3")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker3));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                rotateMarker(car_markers.get(1), MarkerDetails.getMarkerOneEangle().get(0), 0);
                animateMarker(0, MarkerDetails.getMarkerOneRoute(), MarkerDetails.getMarkerOneEangle(), MarkerDetails.getMarkerOneDuration(), false, car_markers.get(1));

                rotateMarker(car_markers.get(0), MarkerDetails.getMarkerTwoEangle().get(0), 0);
                animateMarker(0, MarkerDetails.getMarkerTwoRoute(), MarkerDetails.getMarkerTwoEangle(), MarkerDetails.getMarkerTwoDuration(), false, car_markers.get(0));

                rotateMarker(car_markers.get(2), MarkerDetails.getMarkerThreeEangle().get(0), 0);
                animateMarker(0, MarkerDetails.getMarkerThreeRoute(), MarkerDetails.getMarkerThreeEangle(), MarkerDetails.getMarkerThreeDuration(), false, car_markers.get(2));


                rotateMarker(car_markers.get(3), MarkerDetails.getMarkerfourEangle().get(0), 0);
                animateMarker(0, MarkerDetails.getMarkerfourRoute(), MarkerDetails.getMarkerfourEangle(), MarkerDetails.getMarkerfourDuration(), false, car_markers.get(3));


                rotateMarker(car_markers.get(4), MarkerDetails.getMarkerfiveEangle().get(0), 0);
                animateMarker(0, MarkerDetails.getMarkerfiveRoute(), MarkerDetails.getMarkerfiveEangle(), MarkerDetails.getMarkerfiveDuration(), false, car_markers.get(4));


            }
        }, 3500);


    }

    public void rotateMarker(final Marker marker, final float toRotation, final float st) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final float startRotation = st;
        final long duration = 105;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed / duration);
                float rot = t * toRotation + (1 - t) * startRotation;
                marker.setRotation(-rot > 180 ? rot / 2 : rot);
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                }
            }
        });
    }
    public void animateMarker(final int duration_time, final LatLng positn, final boolean hideMarke, final Marker m) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = mMap.getProjection();
        Point startPoint = proj.toScreenLocation(m.getPosition());
        final LatLng startLatLng = proj.fromScreenLocation(startPoint);
        final long duration = duration_time;
        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * positn.longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * positn.latitude + (1 - t)
                        * startLatLng.latitude;
                m.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                } else {
                    if (hideMarke) {
                        m.setVisible(false);
                    } else {
                        m.setVisible(true);
                    }
                }
            }
        });
    }


    public void animateMarker(final int x, final List<LatLng> list, final List<Integer> angle, final List<Integer> duration_t, final boolean hideMarke, final Marker m) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = mMap.getProjection();
        Point startPoint = proj.toScreenLocation(m.getPosition());
        final LatLng startLatLng = proj.fromScreenLocation(startPoint);
        final long duration = duration_t.get(x);
        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * list.get(x).longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * list.get(x).latitude + (1 - t)
                        * startLatLng.latitude;
                m.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                } else {
                    if (hideMarke) {
                        m.setVisible(false);
                    } else {
                        m.setVisible(true);
                        if (x < list.size() - 1) {
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    rotateMarker(m, angle.get(x + 1), angle.get(x));
                                    animateMarker(x + 1, list, angle, duration_t, false, m);
                                }
                            }, 100);
                        } else {
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    rotateMarker(m, angle.get(0), 0);
                                    animateMarker(0, list, angle, duration_t, false, m);
                                }
                            }, 100);
                        }

                    }
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.drw_help:
                drawerLayout.closeDrawer(Gravity.START);
                Intent help = new Intent(HomeScreen.this, TripHelp.class);
                help.putExtra("id" , 1);
                startActivity(help);
                break;
            case R.id.drw_payment:
                if(SharedPrefrences.getBool("islogin", HomeScreen.this)){
                    drawerLayout.closeDrawer(Gravity.START);
                    GOTO(HomeScreen.this, PaymentActivity.class);
                }else {
                    SharedPrefrences.SetBool("ishomeLogin" , true , HomeScreen.this);
                    drawerLayout.closeDrawer(Gravity.START);
                    GOTO(HomeScreen.this, LoginSelection.class);
//                    finish();
                }
                break;
            case R.id.drw_past_trips:
                drawerLayout.closeDrawer(Gravity.START);
                GOTO(HomeScreen.this, PastTrips.class);
                break;
            case R.id.drw_upcoming_trips:
                drawerLayout.closeDrawer(Gravity.START);
                GOTO(HomeScreen.this, UpcomingTrip.class);
                break;
            case R.id.drw_settings:
                if(SharedPrefrences.getBool("islogin", HomeScreen.this)){
                    drawerLayout.closeDrawer(Gravity.START);
                    GOTO(HomeScreen.this, SettingActivity.class);
                }else {
                    SharedPrefrences.SetBool("ishomeLogin" , true , HomeScreen.this);
                    drawerLayout.closeDrawer(Gravity.START);
                    GOTO(HomeScreen.this, LoginSelection.class);
//                    finish();
                }
                break;
            case R.id.drw_logout:
                drawerLayout.closeDrawer(Gravity.START);
                StaticFunctios.ShowProgress(HomeScreen.this);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        StaticFunctios.HideProgress();
                        SharedPrefrences.SetBool("ishomeLogin" , true , HomeScreen.this);
                        SharedPrefrences.SetBool("islogin" , false , HomeScreen.this);
                        SharedPrefrences.SetBool("islogin_social" , false , HomeScreen.this);
                        isImageupload = false;
                        Intent i = new Intent(HomeScreen.this, LoginSelection.class);
                        startActivity(i);
                    }
                }, 1000);
                break;
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if(SharedPrefrences.getBool("islogin", HomeScreen.this) && !SharedPrefrences.getBool("islogin_social", HomeScreen.this)  ){
            Profile = (ImageView) findViewById(R.id.profile_img);
            Map<String, String> parm = new HashMap<String, String>();
            parm.put("img_id", login_parm.get("img_id"));
            if(!isImageupload){
                new MakeAPICall(HomeScreen.this, parm, PostMethod, URLs.RetrieveImage, APIActions.ApiActions.retrive_img, HomeScreen.this).execute();
            }
            USERNAME.setText(login_parm.get("first_name")+" " +login_parm.get("last_name"));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(SharedPrefrences.getBool("islogin", HomeScreen.this) && !SharedPrefrences.getBool("islogin_social", HomeScreen.this)  ){
            Profile = (ImageView) findViewById(R.id.profile_img);
            Map<String, String> parm = new HashMap<String, String>();
            parm.put("img_id", login_parm.get("img_id"));
            if(!isImageupload){
                new MakeAPICall(HomeScreen.this, parm, PostMethod, URLs.RetrieveImage, APIActions.ApiActions.retrive_img, HomeScreen.this).execute();
            } USERNAME.setText(login_parm.get("first_name")+" " +login_parm.get("last_name"));

        }
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(response != null){
            if(response.status.equalsIgnoreCase("true")){
                try {
                    String base_64 = response.img_data;
                    base_64 = base_64.replace(" " , "+");
                    Log.d("bit_map_%_img" , base_64);
                    isImageupload = true;
                    byte[] decodedString = Base64.decode(base_64, 0);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    if(decodedByte != null){
                        SharedPrefrences.SetString("profile_pic_base64",base_64, getApplicationContext());
                        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                        roundDrawable.setCircular(true);
                        Profile.setImageDrawable(roundDrawable);
                        Log.d("image", base_64);
                    }else {
                        getDefaultImg();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            } else {
                getDefaultImg();
            }
        }else {
            getDefaultImg();
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {
        getDefaultImg();
    }

    public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", HomeScreen.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", HomeScreen.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if(decodedByte != null){
                SharedPrefrences.SetString("profile_pic_base64", SharedPrefrences.getString("profile_pic_base64", HomeScreen.this), getApplicationContext());
                RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                roundDrawable.setCircular(true);
                Profile.setImageDrawable(roundDrawable);
                Log.d("image", SharedPrefrences.getString("profile_pic_base64", HomeScreen.this));
            }
        }else if(!SharedPrefrences.getString("profile_pic", HomeScreen.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , HomeScreen.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
    }
}