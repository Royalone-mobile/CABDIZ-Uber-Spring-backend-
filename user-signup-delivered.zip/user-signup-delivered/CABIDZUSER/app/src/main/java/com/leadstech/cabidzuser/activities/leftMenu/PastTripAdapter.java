package com.leadstech.cabidzuser.activities.leftMenu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.leadstech.cabidzuser.R;

import java.util.ArrayList;

/**
 * Created by jawadali on 4/14/17.
 */

public class PastTripAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    ArrayList<String> data = new ArrayList<>();
    PastTripAdapter(Context context, ArrayList<String> list){
        this.context =  context;
        this.data= list;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount()
    {
        return 10;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
        if(convertView == null){
            rowView = inflater.inflate(R.layout.past_trip_list_item, parent, false);
        }else {
            rowView = convertView;
        }
        return rowView;
    }
}