package com.leadstech.cabidzuser.singleton;

/**
 * Created by jawadali on 5/5/17.
 */

public class APIActions {
    public static enum ApiActions{
        upload_img,retrive_img,update_payment,log_in,signup,porgot_password,send_email,email_verfication,credit_card_verfication
    };
}
