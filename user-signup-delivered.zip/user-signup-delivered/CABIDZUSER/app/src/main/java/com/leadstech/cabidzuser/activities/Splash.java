package com.leadstech.cabidzuser.activities;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.Home.CarSelectionScreen;
import com.leadstech.cabidzuser.activities.Home.HomeScreen;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;

import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        SharedPrefrences.SetBool("islogin",false,Splash.this);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                GOTO(Splash.this, HomeScreen.class);
                finish();
            }
        }, 3000);

    }
}
