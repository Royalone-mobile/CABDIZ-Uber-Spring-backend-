package com.leadstech.cabidzuser.activities.leftMenu;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.leadstech.cabidzuser.R;

import java.util.ArrayList;

/**
 * Created by jawadali on 4/14/17.
 */

public class UpcommingTripAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    ArrayList<String> data = new ArrayList<>();
    UpcommingTripAdapter(Context context, ArrayList<String> list){
        this.context =  context;
        this.data= list;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount()
    {
        return 10;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
            rowView = inflater.inflate(R.layout.past_trip_list_item, parent, false);
            final TextView name = (TextView) rowView.findViewById(R.id.name);
            name.setVisibility(View.GONE);
            final TextView DATE = (TextView) rowView.findViewById(R.id.date_txt);
            if(position == 0){
                DATE.setText("NOW");
                DATE.setTextColor(Color.parseColor("#F43A42"));
            }
        return rowView;
    }
}