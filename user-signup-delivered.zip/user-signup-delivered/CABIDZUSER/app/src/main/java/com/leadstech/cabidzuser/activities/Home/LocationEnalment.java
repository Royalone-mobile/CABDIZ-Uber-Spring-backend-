package com.leadstech.cabidzuser.activities.Home;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.leadstech.cabidzuser.R;

import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;

public class LocationEnalment extends AppCompatActivity {
    Button Location_btn, PickUp;
    final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 998;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_enalment);
        Location_btn = (Button) findViewById(R.id.location);
        PickUp = (Button) findViewById(R.id.pickup);
        Location_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });
        PickUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}
