package com.leadstech.cabidzuser.activities.leftMenu;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.Home.HomeScreen;
import com.leadstech.cabidzuser.activities.login.Login;
import com.leadstech.cabidzuser.activities.login.SignupSecondStep;
import com.leadstech.cabidzuser.activities.login.Varification_number;
import com.leadstech.cabidzuser.cloud_apis.JsonAPICall;
import com.leadstech.cabidzuser.cloud_apis.MakeAPICall;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;
import com.leadstech.cabidzuser.singleton.StripeResponse;
import com.leadstech.cabidzuser.singleton.URLs;
import com.stripe.android.TokenCallback;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;
import com.stripe.exception.APIException;
import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.model.AccountCollection;
import com.stripe.model.Customer;
import com.stripe.model.ExternalAccount;
import com.stripe.model.ExternalAccountCollection;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.leadstech.cabidzuser.activities.login.Login.login_parm;
import static com.leadstech.cabidzuser.activities.login.SignupSecondStep.Month;
import static com.leadstech.cabidzuser.activities.login.SignupStepOne.parm;
import static com.leadstech.cabidzuser.singleton.APIActions.ApiActions.update_payment;
import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.ShowProgress;

public class PaymentActivity extends AppCompatActivity implements APIResponseListner, StripeResponse {
    Button UPDATE;
    ImageView BACK;
    ImageView Profile;
    String ERROR_MSG ="";
    String Card_Expiry = "";
    boolean isDrawerLeftSelect = true;
    String month_txt = "" , year_txt = "";
    Spinner mnth_spinner,year_cpinner;
    EditText Credit_card,Card_CVC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        Profile = (ImageView) findViewById(R.id.profile_img);
        getDefaultImg();
        mnth_spinner = (Spinner) findViewById(R.id.mnth);
        year_cpinner = (Spinner) findViewById(R.id.year);
        Credit_card = (EditText) findViewById(R.id.card_number);
        Card_CVC = (EditText) findViewById(R.id.card_cvc);
        year_cpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(i>0){
                    year_txt = adapterView.getItemAtPosition(i).toString();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                year_txt = "";
            }
        });

        mnth_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(i>0){
                    month_txt = adapterView.getItemAtPosition(i).toString();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                month_txt ="";
            }
        });

        Credit_card.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(Credit_card.getText().length() > 0){
                    if(!isDrawerLeftSelect){
                        if(Credit_card.getText().toString().charAt(0) == '4'){
                            isDrawerLeftSelect = true;
                            Drawable img = PaymentActivity.this.getResources().getDrawable( R.drawable.visa_card );
                            img.setBounds( 0, 0, 95, 70 );
                            Credit_card.setCompoundDrawables( img, null, null, null );
                        }else if(Credit_card.getText().toString().charAt(0) == '5'){
                            isDrawerLeftSelect = true;
                            Drawable img = PaymentActivity.this.getResources().getDrawable( R.drawable.master_card );
                            img.setBounds( 0, 0, 95, 70 );
                            Credit_card.setCompoundDrawables( img, null, null, null );
                        }
                    }
                }else {
                    isDrawerLeftSelect = false;
                    Credit_card.setCompoundDrawables( null, null, null, null );
                }
            }
        });


        UPDATE = (Button) findViewById(R.id.update);
        UPDATE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(month_txt.length() > 0 && year_txt.length() > 0){
                    Card_Expiry = month_txt +"/"+year_txt;
                }
                Log.d("date = " , month_txt+"/"+year_txt);
                if( Credit_card.getText().length()== 0 ||
                        Card_CVC.getText().length()== 0 ||
                        Card_Expiry.length() ==0 ){
                    Toast.makeText(getApplicationContext(),"all fields are required!",Toast.LENGTH_SHORT).show();
                }else {
                    if(Credit_card.getText().length() < 16){
                        Credit_card.setError("invalid card number");
                        Toast.makeText(getApplicationContext(),"Enter correct Card number",Toast.LENGTH_SHORT).show();
                    }else {
                        CreateNewStripeCustomer(Credit_card.getText().toString(),month_txt,year_txt,Card_CVC.getText().toString(),login_parm.get("email"),PaymentActivity.this);

                    }

                }
            }
        });

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
//        SetText();
    }

    public  void SetText(){
        Credit_card.setText(login_parm.get("card_number"));
        Card_CVC.setText(login_parm.get("card_cvc"));
        Card_Expiry = login_parm.get("card_expiry");

        if(login_parm.get("card_number").charAt(0) == '4'){
            Drawable img = PaymentActivity.this.getResources().getDrawable( R.drawable.visa_card );
            img.setBounds( 0, 0, 95, 70 );
            Credit_card.setCompoundDrawables( img, null, null, null );
        }else if(login_parm.get("card_number").charAt(0) == '5'){
            Drawable img = PaymentActivity.this.getResources().getDrawable( R.drawable.master_card );
            img.setBounds( 0, 0, 95, 70 );
            Credit_card.setCompoundDrawables( img, null, null, null );
        }

    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(apiActions == APIActions.ApiActions.credit_card_verfication){
            if(response.status != null && response.status.equalsIgnoreCase("success")){
                //update call
                login_parm.put("card_number" , Credit_card.getText().toString());
                login_parm.put("card_cvc" , Card_CVC.getText().toString());
                login_parm.put("card_expiry" ,Card_Expiry);
                new MakeAPICall(PaymentActivity.this, login_parm, PostMethod, URLs.UpdatePaymentData, update_payment, PaymentActivity.this).execute();
            }else {
                Credit_card.setError("Invalid Card");
                Credit_card.requestFocus();
                Toast.makeText(getApplicationContext(),response.message,Toast.LENGTH_SHORT).show();
            }
        }else if(apiActions == update_payment){
            if(response.status != null && response.status.equalsIgnoreCase("true")){
                  Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_LONG).show();
                   finish();
            }else {
                Credit_card.setError("Invalid Card");
                Credit_card.requestFocus();
                Toast.makeText(getApplicationContext(),response.message,Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }

    public  void  CreateNewStripeCustomer(final String cardNumber, final String cardExpMonth, final String cardExpYear ,final String cardCVC, final String Email , final StripeResponse response){
        ShowProgress(PaymentActivity.this);
        com.stripe.Stripe.apiKey = "sk_test_n8hO8g8giswb1pE1OOpDliSC";
        com.stripe.android.Stripe stripe = new com.stripe.android.Stripe(PaymentActivity.this);
        stripe.setDefaultPublishableKey("pk_test_2BdrpyDNN2Vy5r220T9xp2d3");
        final Card card = new Card(
                cardNumber,
                Month(cardExpMonth),
                Integer.parseInt(cardExpYear),
                cardCVC
        );
        stripe.createToken(card, new TokenCallback() {
            @Override
            public void onError(Exception error) {
                HideProgress();
                Toast.makeText(getApplicationContext(),error.getMessage() , Toast.LENGTH_LONG).show();
            }
            @Override
            public void onSuccess(final Token token) {
                final Map<String, Object> customerParams = new HashMap<String, Object>();
                customerParams.put("source", token.getId());
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        try {
                            Customer customer = Customer.retrieve(login_parm.get("stripe_id"));
                            ExternalAccountCollection accountCollection1 = customer.getSources();
                            List<ExternalAccount> data1 =  accountCollection1.getData();
                            List<String> old_card_id = new ArrayList<String>();
                            for (int x= 0 ; x < data1.size() ; x++){
                                old_card_id.add(data1.get(x).getId());
                            }
                            Log.d("custmer" , customer.getId());
                            customer.createCard(customerParams);
                            customer = Customer.retrieve(login_parm.get("stripe_id"));
                             ExternalAccountCollection accountCollection = customer.getSources();
                             List<ExternalAccount> data =  accountCollection.getData();
                             for(int x=0 ; x<data.size() ; x++){
                                if(!old_card_id.contains(data.get(x).getId())){
                                    customer.setDefaultSource(data.get(x).getId());
                                    customer.setDefaultCard(data.get(x).getId());
                                }
                            }
                            response.getResponse(true);
                        } catch (AuthenticationException | com.stripe.exception.InvalidRequestException | com.stripe.exception.APIConnectionException | CardException | APIException e) {
                           ERROR_MSG = e.getMessage();
                            response.getResponse(false);
                            e.printStackTrace();
                        }
                    }
                };
                thread.start();
            }
        });
    }

    @Override
    public void getResponse(final boolean status) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(status){
                    HideProgress();
                    Toast.makeText(getApplicationContext(), "payment information has been updated successfully!!", Toast.LENGTH_LONG).show();
                    finish();
                }else {
                    Toast.makeText(getApplicationContext(), ERROR_MSG, Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", PaymentActivity.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", PaymentActivity.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }else if(!SharedPrefrences.getString("profile_pic", PaymentActivity.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , PaymentActivity.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
    }
}
