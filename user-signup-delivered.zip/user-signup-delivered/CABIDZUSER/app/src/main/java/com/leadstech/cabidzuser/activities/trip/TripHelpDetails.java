package com.leadstech.cabidzuser.activities.trip;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.singleton.StaticFunctios;

import java.util.ArrayList;

public class TripHelpDetails extends AppCompatActivity {
    ListView list;
    TextView _title;
    ImageView BACK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_help_details);
        _title = (TextView) findViewById(R.id.heading_title);
        _title.setText(getIntent().getExtras().getString("title"));
        list = (ListView) findViewById(R.id.list_view);
        list.setAdapter(new TripDetailListAdapter(TripHelpDetails.this, StaticFunctios.getHelpSubTitlesTitles()));
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
