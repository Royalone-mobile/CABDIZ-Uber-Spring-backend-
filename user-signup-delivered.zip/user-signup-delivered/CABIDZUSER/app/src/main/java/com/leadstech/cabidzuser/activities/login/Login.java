package com.leadstech.cabidzuser.activities.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginBehavior;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.Home.CarSelectionScreen;
import com.leadstech.cabidzuser.activities.Home.HomeScreen;
import com.leadstech.cabidzuser.cloud_apis.MakeAPICall;
import com.leadstech.cabidzuser.model.LoginResponse;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;
import com.leadstech.cabidzuser.singleton.URLs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.leadstech.cabidzuser.activities.login.SignupStepOne.parm;
import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.ShowProgress;

public class Login extends AppCompatActivity implements APIResponseListner {
    Button btn_Login, Forgot_Password;
    EditText Username, Password;
    ImageView header_img;
    public static Map<String, String> login_parm = new HashMap<>();
    ImageView FACEBOOK_BTN;
    private String socialID="";
    private CallbackManager callbackManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        FacebookSdk.sdkInitialize(getApplicationContext());
        callbackManager = CallbackManager.Factory.create();
        Username = (EditText) findViewById(R.id.username);
        Password = (EditText) findViewById(R.id.password);
        header_img = (ImageView) findViewById(R.id.header_img);
        FACEBOOK_BTN = (ImageView) findViewById(R.id.face_book_login);
        btn_Login = (Button) findViewById(R.id.login);
        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Username.length() > 0 && Password.length() > 0) {
                    Map<String, String> parm = new HashMap<String, String>();
                    parm.put("email", Username.getText().toString());
                    parm.put("password",Password.getText().toString());
                    new MakeAPICall(Login.this, parm, PostMethod, URLs.LoginURL, APIActions.ApiActions.log_in, Login.this).execute();
                } else {
                    Toast.makeText(getApplicationContext(), "username or password is missing!", Toast.LENGTH_LONG).show();
                }
            }
        });
        Forgot_Password = (Button) findViewById(R.id.forgot_password);
        Forgot_Password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GOTO(Login.this, ForgotPassword.class);
            }
        });
        FACEBOOK_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginManager.getInstance().logInWithPublishPermissions(Login.this, Arrays.asList("publish_actions , public_profile, email, user_birthday, user_friends"));
                LoginManager.getInstance().setLoginBehavior(LoginBehavior.NATIVE_ONLY);
                LoginManager.getInstance().registerCallback(callbackManager,
                        new FacebookCallback<LoginResult>() {
                            @Override
                            public void onSuccess(LoginResult loginResult) {
                                ShowProgress(Login.this);
                                try {
                                    AccessToken aToken = loginResult.getAccessToken();
                                    Log.d("FaceBook_token" , aToken.getToken());
                                    GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(),
                                            new GraphRequest.GraphJSONObjectCallback() {
                                                @Override
                                                public void onCompleted(JSONObject object, GraphResponse response) {
                                                    if (response != null) {
                                                        JSONObject data;
                                                        try {
                                                             data = response.getJSONObject();
                                                            if (data.has("id")) {
                                                                socialID = data.getString("id");
                                                            }
                                                            if (data.has("email")) {
                                                                String socialID = data.getString("email");
                                                            }
                                                            JSONObject userObj = new JSONObject();
                                                            try {
                                                                userObj.put("facebook_id", socialID);
                                                                userObj.put("issocial", "1");
                                                            } catch (JSONException e) {
                                                                e.printStackTrace();
                                                            }
                                                            HideProgress();
                                                            login_parm.put("first_name" , data.getString("first_name"));
                                                            login_parm.put("last_name" , data.getString("last_name"));
                                                            login_parm.put("phone_number" , "");
                                                            login_parm.put("email" ,data.getString("email"));
                                                            login_parm.put("password","");
                                                            login_parm.put("card_number","");
                                                            login_parm.put("card_expiry", "");
                                                            login_parm.put("card_cvc","");
                                                            login_parm.put("img_id",data.getJSONObject("picture").getJSONObject("data").getString("url"));
                                                            login_parm.put("stripe_id", "");
                                                            login_parm.put("postal_code", "");
                                                              SharedPrefrences.SetBool("islogin", true, Login.this);
                                                              SharedPrefrences.SetBool("islogin_social", true, Login.this);
                                                              Toast.makeText(getApplicationContext(),"Login Successfully!!" , Toast.LENGTH_LONG).show();
                                                              finish();
                                                        } catch (Exception e) {
                                                            e.printStackTrace();
                                                        }
                                                        if (LoginManager.getInstance() != null) {
                                                            LoginManager.getInstance().logOut();
                                                        }

                                                    }else{
                                                        Toast.makeText(getApplicationContext(),"No public data received from Facebook!!" , Toast.LENGTH_LONG).show();
                                                    }
                                                }

                                            });
                                    Bundle parameters = new Bundle();
                                    parameters.putString("fields", "id,first_name,last_name,email,gender, birthday, picture.width(300)");
                                    request.setParameters(parameters);
                                    request.executeAsync();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onCancel() {
                            Toast.makeText(getApplicationContext(),"Login Canceled" , Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onError(FacebookException error) {
                                Toast.makeText(getApplicationContext(),"Login Error" , Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 195278 || requestCode == 64206) {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }
    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if (response.status != null) {
            if (response.status.equalsIgnoreCase("true")) {
                LoginResponse result_reponse = (LoginResponse) response;
                SharedPrefrences.SetString("name" , result_reponse.getProperty().getFirst_name()+" "+ result_reponse.getProperty().getLast_name() , Login.this);
                login_parm.put("first_name" , result_reponse.getProperty().getFirst_name());
                login_parm.put("last_name" , result_reponse.getProperty().getLast_name());
                login_parm.put("phone_number" , result_reponse.getProperty().getPhone_number());
                login_parm.put("email" ,result_reponse.getProperty().getEmail());
                login_parm.put("password",result_reponse.getProperty().getPassword());
                login_parm.put("card_number",result_reponse.getProperty().getCard_number());
                login_parm.put("card_expiry", result_reponse.getProperty().getCard_expiry());
                login_parm.put("card_cvc",result_reponse.getProperty().getCard_cvc());
                login_parm.put("img_id", result_reponse.getProperty().getImage());
                login_parm.put("stripe_id", result_reponse.getProperty().getStripe_id());
                login_parm.put("postal_code", result_reponse.getProperty().getPostal_code());
                SharedPrefrences.SetBool("islogin", true, Login.this);
                Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
//                if(SharedPrefrences.getBool("ishomeLogin" , Login.this)){
//
//                }else {
                    finish();
//                }
            } else {
                Password.setText("");
                Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(getApplicationContext(), "Connection Error", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {
        Log.d("response", response.response_data);
    }
}
