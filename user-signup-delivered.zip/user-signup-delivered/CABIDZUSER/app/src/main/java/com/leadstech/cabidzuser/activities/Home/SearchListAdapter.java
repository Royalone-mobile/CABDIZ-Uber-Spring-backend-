package com.leadstech.cabidzuser.activities.Home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.leadstech.cabidzuser.R;

import java.util.ArrayList;


public class SearchListAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    ArrayList<String> data = new ArrayList<>();
    SearchListAdapter(Context context, ArrayList<String> list){
        this.context =  context;
        this.data= list;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return 40;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
        if(convertView == null){
            rowView = inflater.inflate(R.layout.search_list_items, parent, false);
        }else {
            rowView = convertView;
        }
        return rowView;
    }
}