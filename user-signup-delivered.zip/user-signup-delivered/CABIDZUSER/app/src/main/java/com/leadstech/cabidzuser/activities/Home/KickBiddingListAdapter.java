package com.leadstech.cabidzuser.activities.Home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;

import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.custome_object.BidAcceptCallback;

public class KickBiddingListAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    BidAcceptCallback calback;
    public KickBiddingListAdapter(Context context, BidAcceptCallback callback){
        this.context =  context;
        this.calback = callback ;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return 3;
    }
    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View rowView;
        if(convertView == null){
            rowView = inflater.inflate(R.layout.kick_bidding_list_item, parent, false);
            final Button accept = (Button) rowView.findViewById(R.id.accept);
            final ImageView Profile = (ImageView) rowView.findViewById(R.id.profile_btn);
            Profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    CarSelectionScreen.Driver_Profile.setVisibility(View.VISIBLE);
                }
            });
            accept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                 calback.AcceptBid(position);
                }
            });
        }else {
            rowView = convertView;
        }
        return rowView;
    }
}
