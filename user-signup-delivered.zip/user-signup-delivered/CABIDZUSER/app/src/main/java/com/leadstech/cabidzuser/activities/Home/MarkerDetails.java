package com.leadstech.cabidzuser.activities.Home;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;


 class MarkerDetails {
      static List<LatLng> getMarkerOneRoute (){
        List<LatLng> marker1_route = new ArrayList<>();
        marker1_route.add(new LatLng(-37.806871, 144.965610));
        marker1_route.add(new LatLng(-37.805803, 144.955998));
        marker1_route.add(new LatLng(-37.809622, 144.955304));
        marker1_route.add(new LatLng(-37.819493, 144.960009));
        marker1_route.add(new LatLng(-37.816686, 144.969988));
        return  marker1_route;
    }

      static List<Integer> getMarkerOneEangle (){
        List<Integer> marker1_engle = new ArrayList<>();
        marker1_engle.add(-18);
        marker1_engle.add(-78);
        marker1_engle.add(160);
        marker1_engle.add(160);
        marker1_engle.add(77);
        return  marker1_engle;
    }

      static List<Integer> getMarkerOneDuration (){
        List<Integer> marker1_engle = new ArrayList<>();
        marker1_engle.add(150000);
        marker1_engle.add(110000);
        marker1_engle.add(100000);
        marker1_engle.add(200000);
        marker1_engle.add(150000);
        return  marker1_engle;
    }


     static List<LatLng> getMarkerTwoRoute (){
         List<LatLng> marker1_route = new ArrayList<>();
         marker1_route.add(new LatLng(-37.810060, 144.969703));
         marker1_route.add(new LatLng(-37.816007, 144.972447));
         marker1_route.add(new LatLng(-37.818168, 144.964671));
         marker1_route.add(new LatLng(-37.812306, 144.962283));
         return  marker1_route;
     }

     static List<Integer> getMarkerTwoEangle (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(65);
         marker1_engle.add(148);
         marker1_engle.add(-170);
         marker1_engle.add(-26);

         return  marker1_engle;
     }

     static List<Integer> getMarkerTwoDuration (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(150000);
         marker1_engle.add(140000);
         marker1_engle.add(130000);
         marker1_engle.add(150000);
         return  marker1_engle;
     }





     static List<LatLng> getMarkerThreeRoute (){
         List<LatLng> marker1_route = new ArrayList<>();
         marker1_route.add(new LatLng(-37.804064, 144.958451));
         marker1_route.add(new LatLng(-37.805120, 144.969093));
         marker1_route.add(new LatLng(-37.807994, 144.968644));
         marker1_route.add(new LatLng(-37.813988, 144.971428));
         marker1_route.add(new LatLng(-37.816222, 144.963975));
         marker1_route.add(new LatLng(-37.807426, 144.959979));


         return  marker1_route;
     }

     static List<Integer> getMarkerThreeEangle (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(-18);
         marker1_engle.add(90);
         marker1_engle.add(-302);
         marker1_engle.add(96);
         marker1_engle.add(-102);
         marker1_engle.add(-22);
         return  marker1_engle;
     }

     static List<Integer> getMarkerThreeDuration (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(330000);
         marker1_engle.add(330000);
         marker1_engle.add(130000);
         marker1_engle.add(330000);
         marker1_engle.add(360000);
         marker1_engle.add(330000);
         return  marker1_engle;
     }


     static List<LatLng> getMarkerfourRoute (){
         List<LatLng> marker1_route = new ArrayList<>();
         marker1_route.add(new LatLng(-37.814087, 144.960256));
         marker1_route.add(new LatLng(-37.806546, 144.986122));
         return  marker1_route;
     }

     static List<Integer> getMarkerfourEangle (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(-18);
         marker1_engle.add(65);
         return  marker1_engle;
     }

     static List<Integer> getMarkerfourDuration (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(80000);
         marker1_engle.add(1160000);
         return  marker1_engle;
     }


     static List<LatLng> getMarkerfiveRoute(){
         List<LatLng> marker1_route = new ArrayList<>();
         marker1_route.add(new LatLng(-37.812475, 144.953943));
         marker1_route.add(new LatLng(-37.810987, 144.958888));
         marker1_route.add(new LatLng(-37.816916, 144.961634));
         marker1_route.add(new LatLng(-37.818308, 144.956590));
         marker1_route.add(new LatLng(-37.815931, 144.955527));
         return  marker1_route;
     }

     static List<Integer> getMarkerfiveEangle (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(-18);
         marker1_engle.add(65);
         marker1_engle.add(155);
         marker1_engle.add(240);
         marker1_engle.add(333);
         return  marker1_engle;
     }

     static List<Integer> getMarkerfiveDuration (){
         List<Integer> marker1_engle = new ArrayList<>();
         marker1_engle.add(60000);
         marker1_engle.add(100000);
         marker1_engle.add(340000);
         marker1_engle.add(430000);
         marker1_engle.add(110000);
         return  marker1_engle;
     }
}
