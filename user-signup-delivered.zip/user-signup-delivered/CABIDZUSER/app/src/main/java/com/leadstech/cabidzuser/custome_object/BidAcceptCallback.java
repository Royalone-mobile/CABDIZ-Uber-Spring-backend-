package com.leadstech.cabidzuser.custome_object;

/**
 * Created by jawadali on 4/9/17.
 */

public interface BidAcceptCallback {
     void AcceptBid(int id);
}
