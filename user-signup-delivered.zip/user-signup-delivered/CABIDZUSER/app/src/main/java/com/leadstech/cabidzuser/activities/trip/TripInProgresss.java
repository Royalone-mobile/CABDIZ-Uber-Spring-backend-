package com.leadstech.cabidzuser.activities.trip;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.Home.CarSelectionScreen;
import com.leadstech.cabidzuser.custome_object.JSONParse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.ShowProgress;

public class TripInProgresss extends AppCompatActivity implements OnMapReadyCallback,LocationListener, RoutingListener {
    boolean is_BidInProcess = false;
    ImageView BACK;
    RelativeLayout Cancel_Bid_dialog;
    Button Cancel_Dialog_cancel_btn,Cancel_dialog_dont_btn;
    private GoogleMap mMap;
    private LocationManager locationManager = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_in_progresss);
        Toast.makeText(getApplicationContext(), "Trip will be ended automatically after 12 sec",Toast.LENGTH_LONG).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                GOTO(TripInProgresss.this, TripEndedActivity.class);
                finish();
            }
        }, 12000);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Cancel_Bid_dialog = (RelativeLayout) findViewById(R.id.cancel_dialog);
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Cancel_Bid_dialog.setVisibility(View.VISIBLE);
            }
        });
        Cancel_Dialog_cancel_btn = (Button) findViewById(R.id.cancel);
        Cancel_Dialog_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowProgress(TripInProgresss.this);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        HideProgress();
                        finish();
                    }
                }, 2000);

            }
        });

        Cancel_dialog_dont_btn = (Button) findViewById(R.id.dont);
        Cancel_dialog_dont_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cancel_Bid_dialog.setVisibility(View.GONE);
            }
        });

        new connectAsyncTask(makeURL(-37.796831, 144.964633, -37.812381, 144.962126)).execute();
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
//        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000, 100, this);
        MarkerOptions marker = new MarkerOptions()
                .position(new LatLng(-37.812381, 144.962126))
                .title("Current Location")
                .alpha(1)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.current_location_pin));
        mMap.addMarker(marker);
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(
                new LatLng(-37.812381, 144.962126), 8);
        mMap.animateCamera(cameraUpdate);
    }

    @Override
    public void onLocationChanged(Location location) {
//        HideProgress();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onRoutingFailure() {
    }
    @Override
    public void onRoutingStart() {

    }
    @Override
    public void onRoutingSuccess(PolylineOptions polylineOptions, Route route) {
        PolylineOptions polyoptions = new PolylineOptions();
        polyoptions.color(Color.parseColor("#F2A24D"));
        polyoptions.width(12);
        polyoptions.addAll(polylineOptions.getPoints());
        mMap.addPolyline(polyoptions);
    }
    @Override
    public void onRoutingCancelled() {
    }

    //Draw Path

    private class connectAsyncTask extends AsyncTask<Void, Void, String> {

        String url;

        connectAsyncTask(String urlPass) {
            url = urlPass;
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            JSONParse jParser = new JSONParse();
            String json = jParser.getJSONFromUrl(url);
            return json;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null) {
                drawPath(result);
            }
        }
    }

    public void drawPath(String result) {
        try {
            final JSONObject json = new JSONObject(result);
            JSONArray routeArray = json.getJSONArray("routes");
            JSONObject routes = routeArray.getJSONObject(0);
            JSONObject overviewPolylines = routes.getJSONObject("overview_polyline");
            String encodedString = overviewPolylines.getString("points");
            List<LatLng> list_lat = decodePoly(encodedString);
            Routing routing = new Routing.Builder()
                    .avoid(AbstractRouting.AvoidKind.FERRIES)
                    .travelMode(Routing.TravelMode.DRIVING)
                    .withListener(TripInProgresss.this)
                    .waypoints(list_lat.get(list_lat.size() - 1), list_lat.get(0))
                    .build();
            routing.execute();
            mMap.addMarker(new MarkerOptions()
                    .position(list_lat.get(0))
                    .title("")
                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.destination_pin)));
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(list_lat.get(list_lat.size() - 1), 15);
            mMap.animateCamera(cameraUpdate);
        } catch (JSONException e) {
        }
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }
        return poly;
    }

    public String makeURL(double sourcelat, double sourcelog, double destlat, double destlog) {
        StringBuilder urlString = new StringBuilder();
        urlString.append("http://maps.googleapis.com/maps/api/directions/json");
        urlString.append("?origin=");// from
        urlString.append(Double.toString(sourcelat));
        urlString.append(",");
        urlString.append(Double.toString(sourcelog));
        urlString.append("&destination=");// to
        urlString.append(Double.toString(destlat));
        urlString.append(",");
        urlString.append(Double.toString(destlog));
        urlString.append("&sensor=false&mode=driving&alternatives=true");
        return urlString.toString();
    }

}
