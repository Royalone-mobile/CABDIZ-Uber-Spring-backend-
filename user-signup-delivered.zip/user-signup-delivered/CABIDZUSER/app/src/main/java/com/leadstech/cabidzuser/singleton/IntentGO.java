package com.leadstech.cabidzuser.singleton;

import android.content.Context;
import android.content.Intent;

/**
 * Created by dany on 03/04/2017.
 */

public class IntentGO {
    static  public void  GOTO(Context current_activity, Class next_activity){
        Intent intent = new Intent(current_activity,next_activity);
        current_activity.startActivity(intent);
    }
}
