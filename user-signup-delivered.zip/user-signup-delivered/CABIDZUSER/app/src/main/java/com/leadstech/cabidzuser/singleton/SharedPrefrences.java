package com.leadstech.cabidzuser.singleton;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefrences extends Activity{
    public static final String MY_PREFS_NAME = "CABIDZ";
    public static void SetBool(String key, Boolean value, Context context){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME,MODE_PRIVATE).edit();
        editor.putBoolean(key, value);
        editor.commit();
    }
    public static Boolean getBool(String key, Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        return  prefs.getBoolean(key,false);
    }

    public static void SetString(String key, String  value, Context context){
        SharedPreferences.Editor editor = context.getSharedPreferences(MY_PREFS_NAME,MODE_PRIVATE).edit();
        editor.putString(key, value);
        editor.commit();
    }
    public static String  getString(String key, Context context){
        SharedPreferences prefs = context.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        return  prefs.getString(key,"null");
    }
}
