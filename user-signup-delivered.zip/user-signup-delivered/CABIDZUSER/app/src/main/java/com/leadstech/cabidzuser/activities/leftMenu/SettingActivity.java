package com.leadstech.cabidzuser.activities.leftMenu;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.baoyz.actionsheet.ActionSheet;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.login.SignupSecondStep;
import com.leadstech.cabidzuser.activities.login.SignupStepOne;
import com.leadstech.cabidzuser.cloud_apis.JsonAPICall;
import com.leadstech.cabidzuser.cloud_apis.MakeAPICall;
import com.leadstech.cabidzuser.cloud_apis.UploadImageAPICall;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;
import com.leadstech.cabidzuser.singleton.URLs;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static com.leadstech.cabidzuser.activities.Home.HomeScreen.isImageupload;
import static com.leadstech.cabidzuser.activities.login.Login.login_parm;
import static com.leadstech.cabidzuser.activities.login.SignupStepOne.BITMAP_RESIZER;
import static com.leadstech.cabidzuser.singleton.APIActions.ApiActions.update_payment;
import static com.leadstech.cabidzuser.singleton.APIActions.ApiActions.upload_img;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.PostMethod;
public class SettingActivity extends AppCompatActivity implements APIResponseListner ,ActionSheet.ActionSheetListener{
    Button UPDATE;
    ImageView BACK;
    ImageView Profile;
    String[] filePathColumn;
    Uri selectedImage;
    EditText First_Name,Last_Name,_PH,_Email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        Profile = (ImageView) findViewById(R.id.profile_img);
        getDefaultImg();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            SetPermissions();
        }
        First_Name = (EditText) findViewById(R.id.firstname_txt);
        Last_Name = (EditText) findViewById(R.id.lastname_text);
        _PH = (EditText) findViewById(R.id.phone_number_txt);
        _Email = (EditText) findViewById(R.id.email_txt);
        UPDATE = (Button) findViewById(R.id.update);
        UPDATE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(First_Name.getText().length()== 0 ||
                        Last_Name.getText().length()== 0 ||
                        _Email.getText().length()== 0 ||
                        _PH.getText().length()== 0){
                    Toast.makeText(getApplicationContext(),"all fields are required!",Toast.LENGTH_SHORT).show();
                    if(_Email.getText().length() == 0){
                        _Email.setError("required");
                    }
                    if(_PH.getText().length() == 0){
                        _PH.setError("required");
                    }
                }else {
                   // update call
                     login_parm.put("first_name",First_Name.getText().toString());
                     login_parm.put("last_name" ,Last_Name.getText().toString());
                     login_parm.put("phone_number" ,_PH.getText().toString());
                    new MakeAPICall(SettingActivity.this, login_parm, PostMethod, URLs.UpdateProfiletData, update_payment, SettingActivity.this).execute();
                }
            }
        });

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        SetTest();

        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActionSheet.createBuilder(SettingActivity.this, getSupportFragmentManager())
                        .setCancelButtonTitle("Cancel")
                        .setOtherButtonTitles("Camera", "Gallery")
                        .setCancelableOnTouchOutside(true)
                        .setListener(SettingActivity.this).show();
            }
        });
    }

    @Override
    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

    }

    @Override
    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
        if (index == 0) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, 9);
        } else {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_PICK);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);
//            Intent i = new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//            startActivityForResult(i, 1);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && null != data) {
            selectedImage = data.getData();
            filePathColumn = new String[]{MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            SharedPrefrences.SetString("profile_pic", picturePath, getApplicationContext());
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(picturePath));
            roundDrawable.setCircular(true);
            Bitmap bitmapOrg = BitmapFactory.decodeFile(picturePath);
            Bitmap bitmap = BITMAP_RESIZER(bitmapOrg,60,60);
            ByteArrayOutputStream bao = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG,10, bao);
            byte [] ba = bao.toByteArray();
            String ba1= Base64.encodeToString(ba,Base64.DEFAULT);
            Log.d("bit_map_%_img" , ba1);
            ba1 = ba1.replace("\n","");
            SharedPrefrences.SetString("profile_pic_base64", ba1, getApplicationContext());
            UploadImage(ba1);
            Profile.setImageDrawable(roundDrawable);
//            Profile_IMG.setImageBitmap(BitmapFactory.decodeFile(picturePath));
        } else if (requestCode == 9 && resultCode == RESULT_OK && data != null) {
            onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 10, bytes);
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        SharedPrefrences.SetString("profile_pic", destination.getAbsolutePath(), getApplicationContext());
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), thumbnail);
        roundDrawable.setCircular(true);

        Bitmap bitmap = BITMAP_RESIZER(thumbnail,60,60);
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 10, bao);
        byte [] ba = bao.toByteArray();
        String ba1= Base64.encodeToString(ba,Base64.DEFAULT);
        ba1 = ba1.replace("\n","");
        SharedPrefrences.SetString("profile_pic_base64", ba1, getApplicationContext());
         UploadImage(ba1);
        Profile.setImageDrawable(roundDrawable);
    }
    public  void SetTest(){
        First_Name.setText(login_parm.get("first_name"));
        Last_Name.setText(login_parm.get("last_name"));
        _PH.setText(login_parm.get("phone_number"));
        _Email.setText(login_parm.get("email"));
        _Email.setEnabled(false);
        _Email.setClickable(false);
        _Email.setFocusable(false);
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(apiActions == upload_img){
             isImageupload = false;
             Log.d("img==>" , response.message  + "\n"+"test");
        }else {
            if(response.status != null && response.status.equalsIgnoreCase("true")){
                Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_LONG).show();
                finish();
            }else {
                Toast.makeText(getApplicationContext(),response.message,Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {
        Toast.makeText(getApplicationContext(),"Error Occurred while updating, tyr it again later!! ",Toast.LENGTH_SHORT).show();

    }
    public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", SettingActivity.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", SettingActivity.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
           if(decodedByte != null){
               RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
               roundDrawable.setCircular(true);
               Profile.setImageDrawable(roundDrawable);
           }
        }else if(!SharedPrefrences.getString("profile_pic", SettingActivity.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , SettingActivity.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
    }

    public void UploadImage(String base64) {
        int length = base64.length()/30;
        String data_1 = base64.substring(0,length);
        String data_2 = base64.substring((length),(length*2));
        String data_3 = base64.substring((length*2),(length*3));
        String data_4 = base64.substring((length*3),(length*4));
        String data_5 = base64.substring((length*4),(length*5));

        String data_6 = base64.substring((length*5),(length*6));
        String data_7 = base64.substring((length*6),(length*7));
        String data_8 = base64.substring((length*7),(length*8));
        String data_9 = base64.substring((length*8),(length*9));
        String data_10 = base64.substring((length*9),(length*10));

        String data_11 = base64.substring((length*10),(length*11));
        String data_12 = base64.substring((length*11),(length*12));
        String data_13 = base64.substring((length*12),(length*13));
        String data_14 = base64.substring((length*13),(length*14));
        String data_15 = base64.substring((length*14),(length*15));

        String data_16 = base64.substring((length*15),(length*16));
        String data_17 = base64.substring((length*16),(length*17));
        String data_18 = base64.substring((length*17),(length*18));
        String data_19 = base64.substring((length*18),(length*19));
        String data_20 = base64.substring((length*19),(length*20));

        String data_21 = base64.substring((length*20),(length*21));
        String data_22 = base64.substring((length*21),(length*22));
        String data_23 = base64.substring((length*22),(length*23));
        String data_24 = base64.substring((length*23),(length*24));
        String data_25 = base64.substring((length*24),(length*25));

        String data_26 = base64.substring((length*25),(length*26));
        String data_27 = base64.substring((length*26),(length*27));
        String data_28 = base64.substring((length*27),(length*28));
        String data_29 = base64.substring((length*28),(length*29));
        String data_30 = base64.substring((length*29),base64.length());

        Map<String, String> parm_img = new HashMap<>();
        parm_img.put("img_id" , login_parm.get("img_id"));
        parm_img.put("data_1" , data_1);
        parm_img.put("data_2" , data_2);
        parm_img.put("data_3" , data_3);
        parm_img.put("data_4" , data_4);
        parm_img.put("data_5" , data_5);
        parm_img.put("data_6" , data_6);
        parm_img.put("data_7" , data_7);
        parm_img.put("data_8" , data_8);
        parm_img.put("data_9" , data_9);

        parm_img.put("data_10" , data_10);
        parm_img.put("data_11" , data_11);
        parm_img.put("data_12" , data_12);
        parm_img.put("data_13" , data_13);
        parm_img.put("data_14" , data_14);
        parm_img.put("data_15" , data_15);
        parm_img.put("data_16" , data_16);
        parm_img.put("data_17" , data_17);
        parm_img.put("data_18" , data_18);
        parm_img.put("data_19" , data_19);
        parm_img.put("data_20" , data_20);

        parm_img.put("data_21" , data_21);
        parm_img.put("data_22" , data_22);
        parm_img.put("data_23" , data_23);
        parm_img.put("data_24" , data_24);
        parm_img.put("data_25" , data_25);
        parm_img.put("data_26" , data_26);
        parm_img.put("data_27" , data_27);
        parm_img.put("data_28" , data_28);
        parm_img.put("data_29" , data_29);
        parm_img.put("data_30" , data_30);
        new UploadImageAPICall(SettingActivity.this, parm_img, PostMethod, URLs.UploadImage, APIActions.ApiActions.upload_img, SettingActivity.this).execute();
    }



    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void SetPermissions() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(SettingActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(SettingActivity.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) && ActivityCompat.shouldShowRequestPermissionRationale(SettingActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(SettingActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        12);
                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 12: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


}
