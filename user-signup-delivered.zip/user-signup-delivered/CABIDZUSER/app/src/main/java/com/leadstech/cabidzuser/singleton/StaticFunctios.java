package com.leadstech.cabidzuser.singleton;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.kaopiz.kprogresshud.KProgressHUD;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import static android.content.Context.INPUT_METHOD_SERVICE;

public class StaticFunctios {
    public static String GetMethod = "GET";
    public static String PostMethod = "POST";
    public  static KProgressHUD pd;
    public static  void HideKeyboard(Context context, EditText editText){
        InputMethodManager imm = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);

    }
    public static void hideKeyboard(Activity activity) {
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View v = window.getCurrentFocus();
                if (v != null) {
                    InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm!=null){
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    }
                }
            }
        }
    }

    public static void ShowProgress(Activity activity) {
        pd = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setCancellable(false).setAnimationSpeed(1).setDimAmount(0.5F).setWindowColor(Color.parseColor("#3EC79C")).show();
    }
    public static void HideProgress() {
        if (pd.isShowing()) {
            pd.dismiss();
        }
    }

    public static  String Month(int number){
        String  month = "Jan";
        switch (number+1){
            case 1:
                month = "Jan";
                break;
            case 2:
                month = "Feb";
                break;
            case 3:
                month = "Mar";
                break;
            case 4:
                month = "Apr";
                break;
            case 5:
                month = "May";
                break;
            case 6:
                month = "June";
                break;
            case 7:
                month = "July";
                break;
            case 8:
                month = "Aug";
                break;
            case 9:
                month = "Sep";
                break;
            case 10:
                month = "Oct";
                break;
            case 11:
                month = "Nov";
                break;
            case 12:
                month = "Dec";
                break;
        }
        return month;
    }

    public static int get12Hour(int hour){
        int hur = 1;
        if(hour <= 12){
            hur = hour;
        }else{
            hur = hour%12;
        }
        return hur;
    }

    public static String getAMPMHour(int hour){
        String ampm = "AM";
        if(hour <= 12){
            ampm = "AM";
        }else{
            ampm = "PM";
        }
        return ampm;
    }

    public static ArrayList<String> getHelpTitles(){
        ArrayList<String> str = new ArrayList<>();
        str.add("Trip and fare eview");
        str.add("Account and Payment Options");
        str.add("A Guide");
        str.add("Signing Up");
        str.add("More");
        str.add("Accessibility");
        return str;
    }

    public static ArrayList<String> getHelpSubTitlesTitles(){
        ArrayList<String> str = new ArrayList<>();
        str.add("I Was involve in an accident");
        str.add("I lost an item");
        str.add("I would like a refund");
        str.add("My driver was unprofessional");
        str.add("I can't request a ride");
        str.add("I have a different issue");
        return str;
    }
}
