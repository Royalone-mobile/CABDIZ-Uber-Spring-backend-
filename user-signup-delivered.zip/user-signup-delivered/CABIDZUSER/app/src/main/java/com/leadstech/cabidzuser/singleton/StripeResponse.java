package com.leadstech.cabidzuser.singleton;

/**
 * Created by jawadali on 5/19/17.
 */

public interface StripeResponse {
    public void getResponse(boolean status);
}
