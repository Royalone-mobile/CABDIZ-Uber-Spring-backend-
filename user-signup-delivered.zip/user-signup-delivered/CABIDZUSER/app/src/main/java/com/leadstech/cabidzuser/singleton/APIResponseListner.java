package com.leadstech.cabidzuser.singleton;

import com.leadstech.cabidzuser.model.Response;

/**
 * Created by jawadali on 5/5/17.
 */

public interface APIResponseListner {
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) ;
    public void onRequestError(Response response, APIActions.ApiActions apiActions);
}
