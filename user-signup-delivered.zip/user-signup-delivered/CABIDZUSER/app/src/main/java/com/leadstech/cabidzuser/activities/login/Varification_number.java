package com.leadstech.cabidzuser.activities.login;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.Home.CarSelectionScreen;
import com.leadstech.cabidzuser.activities.Home.HomeScreen;
import com.leadstech.cabidzuser.cloud_apis.JsonAPICall;
import com.leadstech.cabidzuser.cloud_apis.MakeAPICall;
import com.leadstech.cabidzuser.model.Response;
import com.leadstech.cabidzuser.singleton.APIActions;
import com.leadstech.cabidzuser.singleton.APIResponseListner;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;
import com.leadstech.cabidzuser.singleton.URLs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.leadstech.cabidzuser.activities.login.Login.login_parm;
import static com.leadstech.cabidzuser.activities.login.SignupStepOne.parm;
import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;
import static com.leadstech.cabidzuser.singleton.SharedPrefrences.getBool;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.PostMethod;

public class Varification_number extends AppCompatActivity implements APIResponseListner {
   ImageView BACK;
    TextView Email_TXT;
    public static boolean is_update_email = false;
    EditText ONE,TWO ,THREE,FOUR;
    Button Change_Email_address , Resend_Code;
    String index_1 = "", index_2 ="",index_3="",index_4="";
    boolean isONE = false , isTWO = false , isThree = false , isFour = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_varification_number);
        Email_TXT = (TextView) findViewById(R.id.email_text);
        Email_TXT.setText(parm.get("email"));
        ONE = (EditText) findViewById(R.id.digit_one);
        TWO = (EditText) findViewById(R.id.digit_two);
        THREE = (EditText) findViewById(R.id.digit_three);
        FOUR = (EditText) findViewById(R.id.digit_four);
        ONE.requestFocus();
        ONE.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void afterTextChanged(Editable editable) {
                if(ONE.getText().length()==1){
                    index_1 = ONE.getText().toString();
                    isONE = true;
                     if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                     }
                    TWO.requestFocus();
                }else {
                    index_1 = "";
                    isONE = false;
                }
            }
        });

        FOUR.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(FOUR.getText().length()==1){
                    index_4 = FOUR.getText().toString();
                    isFour = true;
                    if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                    }

                }else {
                    index_4 = "";
                    isFour = false;
                }
            }
        });
        TWO.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(TWO.getText().length()==1){
                    index_2 = TWO.getText().toString();
                    isTWO = true;
                    if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                    }
                    THREE.requestFocus();

                }else {
                    index_2 = "";
                    isTWO = false;
                }
            }
        });
        THREE.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(THREE.getText().length()==1){
                    index_3 = THREE.getText().toString();
                    isThree = true;
                    if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                    }
                    FOUR.requestFocus();


                }else {
                    index_3 = "";
                    isThree = false;
                }
            }
        });
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Change_Email_address = (Button) findViewById(R.id.change_email_address);
        Change_Email_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                is_update_email = true;
                finish();
            }
        });

        Resend_Code = (Button) findViewById(R.id.resend_text);
        Resend_Code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                String code = String.format("%04d", random.nextInt(10000));
                parm.put("code", code);
                Log.d("codee--------" , "\n\n"+ code);
                JSONObject jsonBody = null;
                try {
                    jsonBody = new JSONObject("{\n" +
                            "\"from\":\"no-reply@cabidz.com\",\n" +
                            "\"subject\":\"Email Verification!\",\n" +
                            "\"message\":\"your verification code is = "+code+"\",\n" +
                            "\"email_where_to_send\":\""+parm.get("email")+"\"\n" +
                            "}\n");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                new JsonAPICall(Varification_number.this,jsonBody, Request.Method.POST, URLs.SendEmail,APIActions.ApiActions.send_email,Varification_number.this);
            }
        });
    }

    public  void SubmitData(){
        if(parm.get("code").equalsIgnoreCase(index_1+index_2+index_3+index_4)){
            new MakeAPICall(Varification_number.this,parm,PostMethod, URLs.SignupURL, APIActions.ApiActions.signup,Varification_number.this).execute();
        }else {
            Toast.makeText(getApplicationContext(),"Invalid Verification Code", Toast.LENGTH_SHORT).show();
            ONE.setText("");
            ONE.requestFocus();
            TWO.setText("");
            THREE.setText("");
            FOUR.setText("");
        }
    }
    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(apiActions == APIActions.ApiActions.send_email) {
            if (response.status.equalsIgnoreCase("success")) {
              Toast.makeText(getApplicationContext(),"Verification code has been send to your email address!!",Toast.LENGTH_LONG).show();
            }
        }else if (apiActions == APIActions.ApiActions.signup) {
            if (response.message != null && response.status.equalsIgnoreCase("true")) {
                Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
                if(getBool("ishomeLogin", Varification_number.this)){
                    login_parm = parm;
                    SharedPrefrences.SetBool("islogin", true, Varification_number.this);
                    Intent i = new Intent(getApplicationContext(), HomeScreen.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    finish();
                }else {
                    login_parm = parm;
                    SharedPrefrences.SetBool("islogin", true, Varification_number.this);
                    Intent i = new Intent(getApplicationContext(), CarSelectionScreen.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    finish();
                }

            }else {
                Toast.makeText(getApplicationContext(), "Error occour while registration, try again later", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }


}
