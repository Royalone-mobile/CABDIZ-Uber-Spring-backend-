package com.leadstech.cabidzuser.activities.Home;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Point;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.Projection;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.leadstech.cabidzuser.R;
import com.leadstech.cabidzuser.activities.Splash;
import com.leadstech.cabidzuser.activities.login.LoginSelection;
import com.leadstech.cabidzuser.activities.trip.TripInProgresss;
import com.leadstech.cabidzuser.custome_object.BidAcceptCallback;
import com.leadstech.cabidzuser.custome_object.JSONParse;
import com.leadstech.cabidzuser.singleton.SharedPrefrences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.leadstech.cabidzuser.R.id.driver_profile;
import static com.leadstech.cabidzuser.singleton.IntentGO.GOTO;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidzuser.singleton.StaticFunctios.ShowProgress;

public class CarSelectionScreen extends AppCompatActivity implements BidAcceptCallback, OnMapReadyCallback,LocationListener, RoutingListener {
    LinearLayout Bidders_Details_View,First_Estimatedfare;
    ListView list;
    Button Car_info_save,Car_one_info,Car_two_info,Car_three_info,Order_accepted_ok_btn,Kick_bid, ONE, TWO, THree,Four,Five, Cancel_Dialog_cancel_btn, Cancel_dialog_dont_btn,got_it;
    int Main_width, min_width;
    public static RelativeLayout Driver_Profile;
    public static ImageView Cross_profile;
    boolean is_BidInProcess = false;
    ImageView BACK;
    List<Marker> car_markers = new ArrayList<>();
    private GoogleMap mMap;
    private LocationManager locationManager = null;
    RelativeLayout Cancel_Bid_dialog,kick_bidding_info_dialog,Order_Accepted_Dialog,CarInfoDialog,ONEL,TWOL,THREEL;
    ImageView Canel_bid_dialog_icon,kick_binding_info,CarInfoDialog_icon;
    TextView Cancel_bid_dialog_title, CarinfoDialog_title, CarinfoDialog_subtitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_selection_screen);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Driver_Profile = (RelativeLayout) findViewById(driver_profile);
        Cross_profile = (ImageView) findViewById(R.id.cross_profile);
        First_Estimatedfare = (LinearLayout) findViewById(R.id.first);
        CarInfoDialog = (RelativeLayout) findViewById(R.id.car_info);
        CarInfoDialog_icon = (ImageView) findViewById(R.id.car_info_dialog_car_icon);
        CarinfoDialog_title = (TextView) findViewById(R.id.car_info_title);
        CarinfoDialog_subtitle = (TextView) findViewById(R.id.car_info_subtitle);
        kick_bidding_info_dialog = (RelativeLayout) findViewById(R.id.kick_bidding_info);
        Canel_bid_dialog_icon = (ImageView) findViewById(R.id.dialog_icon);
        Cancel_bid_dialog_title = (TextView) findViewById(R.id.dialog_title);
        Cancel_Bid_dialog = (RelativeLayout) findViewById(R.id.cancel_dialog);
        Order_Accepted_Dialog = (RelativeLayout) findViewById(R.id.order_accepted_dialog);
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (is_BidInProcess) {
                    Canel_bid_dialog_icon.setImageResource(R.mipmap.four_iconn);
                    Cancel_bid_dialog_title.setText("Change The trip?");
                    Cancel_Bid_dialog.setVisibility(View.VISIBLE);
                } else {
                    Canel_bid_dialog_icon.setImageResource(R.mipmap.csncel_ordercopy);
                    Cancel_bid_dialog_title.setText("Cancel Bidding??");
                    Cancel_Bid_dialog.setVisibility(View.VISIBLE);
                }
            }
        });
    Cross_profile.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Driver_Profile.setVisibility(View.GONE);
        }
    });

        Kick_bid = (Button) findViewById(R.id.kick_bid);
        Kick_bid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SharedPrefrences.getBool("islogin", CarSelectionScreen.this)) {
                    ShowProgress(CarSelectionScreen.this);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            HideProgress();
                            is_BidInProcess = true;
                            Kick_bid.setBackgroundResource(R.mipmap.button_one);
                            Kick_bid.setText("Bindding in progress");
                            Kick_bid.setEnabled(false);
                            Kick_bid.setTextSize(13);
                            Bidders_Details_View.setVisibility(View.VISIBLE);
                            First_Estimatedfare.setVisibility(View.GONE);
                        }
                    }, 3000);
                } else {
                    //go to login
                    SharedPrefrences.SetBool("ishomeLogin" , false , CarSelectionScreen.this);
                    GOTO(CarSelectionScreen.this, LoginSelection.class);
                }

            }
        });

        Cancel_Dialog_cancel_btn = (Button) findViewById(R.id.cancel);
        Cancel_Dialog_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowProgress(CarSelectionScreen.this);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        HideProgress();
                        Intent i = new Intent(CarSelectionScreen.this, HomeScreen.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();
                    }
                }, 2000);

            }
        });

        Cancel_dialog_dont_btn = (Button) findViewById(R.id.dont);
        Cancel_dialog_dont_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cancel_Bid_dialog.setVisibility(View.GONE);
            }
        });

        got_it = (Button) findViewById(R.id.got_it);
        got_it.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                kick_bidding_info_dialog.setVisibility(View.GONE);
            }
        });

        kick_binding_info = (ImageView) findViewById(R.id.kick_binding_info);
        kick_binding_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                kick_bidding_info_dialog.setVisibility(View.VISIBLE);
            }
        });

        list = (ListView) findViewById(R.id.list);
        list.setAdapter(new KickBiddingListAdapter(this,this));
        Bidders_Details_View = (LinearLayout) findViewById(R.id.bidders_details);
        Order_accepted_ok_btn = (Button) findViewById(R.id.order_accepted_ok);
        Order_accepted_ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GOTO(CarSelectionScreen.this, TripInProgresss.class);
                finish();
            }
        });


        ONEL = (RelativeLayout) findViewById(R.id.onel);
        TWOL = (RelativeLayout) findViewById(R.id.twol);
        THREEL = (RelativeLayout) findViewById(R.id.threel);

        ONE = (Button) findViewById(R.id.one);
        ONE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ONE.setLayoutParams(new RelativeLayout.LayoutParams(280, 265));
                TWO.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                THree.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Four.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Five.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));

                ONE.setBackgroundResource(R.mipmap.share_van_check);
                TWO.setBackgroundResource(R.mipmap.onr_four_car_unchec);
                THree.setBackgroundResource(R.mipmap.vav_8_person);
                Five.setBackgroundResource(R.mipmap.vav_8_person);
                Four.setBackgroundResource(R.mipmap.vav_8_person);



            }
        });
        TWO = (Button) findViewById(R.id.two);
        TWO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TWO.setLayoutParams(new RelativeLayout.LayoutParams(280, 265));
                ONE.setLayoutParams(new RelativeLayout.LayoutParams(210, 220));
                THree.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Four.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Five.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));

                ONE.setBackgroundResource(R.mipmap.sharing_van);
                TWO.setBackgroundResource(R.mipmap.car_selectedcopy);
                THree.setBackgroundResource(R.mipmap.vav_8_person);
                Five.setBackgroundResource(R.mipmap.vav_8_person);
                Four.setBackgroundResource(R.mipmap.vav_8_person);
            }
        });
        THree = (Button) findViewById(R.id.three);
        THree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                THree.setLayoutParams(new RelativeLayout.LayoutParams(280, 265));
                TWO.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                ONE.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Four.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Five.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));

                ONE.setBackgroundResource(R.mipmap.sharing_van);
                TWO.setBackgroundResource(R.mipmap.onr_four_car_unchec);
                THree.setBackgroundResource(R.mipmap.one_eight_csr);
                Five.setBackgroundResource(R.mipmap.vav_8_person);
                Four.setBackgroundResource(R.mipmap.vav_8_person);
            }
        });

        Four = (Button) findViewById(R.id.three33);
        Four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Four.setLayoutParams(new RelativeLayout.LayoutParams(280, 265));
                ONE.setLayoutParams(new RelativeLayout.LayoutParams(210, 220));
                THree.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                TWO.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Five.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));

                ONE.setBackgroundResource(R.mipmap.sharing_van);
                TWO.setBackgroundResource(R.mipmap.onr_four_car_unchec);
                THree.setBackgroundResource(R.mipmap.vav_8_person);
                Four.setBackgroundResource(R.mipmap.one_eight_csr);
                Five.setBackgroundResource(R.mipmap.vav_8_person);
            }
        });
        Five = (Button) findViewById(R.id.three3dd3);
        Five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Five.setLayoutParams(new RelativeLayout.LayoutParams(280, 265));
                ONE.setLayoutParams(new RelativeLayout.LayoutParams(210, 220));
                THree.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                TWO.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));
                Four.setLayoutParams(new RelativeLayout.LayoutParams(210, 210));

                ONE.setBackgroundResource(R.mipmap.sharing_van);
                TWO.setBackgroundResource(R.mipmap.onr_four_car_unchec);
                THree.setBackgroundResource(R.mipmap.vav_8_person);
                Five.setBackgroundResource(R.mipmap.one_eight_csr);
                Four.setBackgroundResource(R.mipmap.vav_8_person);
            }
        });

        Car_one_info = (Button) findViewById(R.id.car_one);
        Car_one_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarInfoDialog.setVisibility(View.VISIBLE);
                CarinfoDialog_title.setText("Honda Van");
                CarinfoDialog_subtitle.setText("1 - 8 Person shared");
                CarInfoDialog_icon.setImageResource(R.mipmap.van_shared);
            }
        });
        Car_two_info = (Button) findViewById(R.id.car_two);
        Car_two_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarInfoDialog.setVisibility(View.VISIBLE);
                CarinfoDialog_title.setText("Honda Civic");
                CarinfoDialog_subtitle.setText("1 - 4 Person");
                CarInfoDialog_icon.setImageResource(R.mipmap.pop_up_car);
            }
        });
        Car_three_info = (Button) findViewById(R.id.car_three);
        Car_three_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarInfoDialog.setVisibility(View.VISIBLE);
                CarinfoDialog_title.setText("Honda Van");
                CarinfoDialog_subtitle.setText("1 - 8 Person");
                CarInfoDialog_icon.setImageResource(R.mipmap.van_single);
            }
        });


        Car_info_save = (Button) findViewById(R.id.save_car_info);
        Car_info_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarInfoDialog.setVisibility(View.GONE);
            }
        });

        new connectAsyncTask(makeURL(-37.807608, 144.958085, -37.812381, 144.962126)).execute();
    }

    @Override
    public void AcceptBid(int id) {
        ShowProgress(this);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                HideProgress();
                Order_Accepted_Dialog.setVisibility(View.VISIBLE);
            }
        }, 1200);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
//        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000, 100, this);
        MarkerOptions marker = new MarkerOptions()
                .position(new LatLng(-37.812381, 144.962126))
                .title("Current Location")
                .alpha(1)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.current_location_pin));
        mMap.addMarker(marker);
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(
                new LatLng(-37.812381, 144.962126), 15);
        mMap.animateCamera(cameraUpdate);
        createTestCarMarkers();

    }

    @Override
    public void onLocationChanged(Location location) {
//        HideProgress();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
    public void createTestCarMarkers(){
        LatLng create_newLatlng = new LatLng(-37.813325, 144.958503);
        MarkerOptions marker = new MarkerOptions()
                .position(create_newLatlng)
                .title("Car1")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker));
        LatLng create_newLatlng5 = new LatLng(-37.816569, 144.969830);
        MarkerOptions marker5 = new MarkerOptions()
                .position(create_newLatlng5)
                .title("Car5")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker5));
        LatLng create_newLatlng1 = new LatLng(-37.809135, 144.960857);
        MarkerOptions marker1 = new MarkerOptions()
                .position(create_newLatlng1)
                .title("Car2")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker1));
        LatLng create_newLatlng4 = new LatLng(-37.816873, 144.961626);
        MarkerOptions marker4 = new MarkerOptions()
                .position(create_newLatlng4)
                .title("Car4")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker4));

        LatLng create_newLatlng3 = new LatLng(-37.816101, 144.955586);
        MarkerOptions marker3 = new MarkerOptions()
                .position(create_newLatlng3)
                .title("Car3")
                .alpha(1)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
        car_markers.add(mMap.addMarker(marker3));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                rotateMarker(car_markers.get(1),MarkerDetails.getMarkerOneEangle().get(0),0);
                animateMarker(0,MarkerDetails.getMarkerOneRoute(),MarkerDetails.getMarkerOneEangle(),MarkerDetails.getMarkerOneDuration(),false,car_markers.get(1));

                rotateMarker(car_markers.get(0),MarkerDetails.getMarkerTwoEangle().get(0),0);
                animateMarker(0,MarkerDetails.getMarkerTwoRoute(),MarkerDetails.getMarkerTwoEangle(),MarkerDetails.getMarkerTwoDuration(),false,car_markers.get(0));

                rotateMarker(car_markers.get(2),MarkerDetails.getMarkerThreeEangle().get(0),0);
                animateMarker(0,MarkerDetails.getMarkerThreeRoute(),MarkerDetails.getMarkerThreeEangle(),MarkerDetails.getMarkerThreeDuration(),false,car_markers.get(2));


                rotateMarker(car_markers.get(3),MarkerDetails.getMarkerfourEangle().get(0),0);
                animateMarker(0,MarkerDetails.getMarkerfourRoute(),MarkerDetails.getMarkerfourEangle(),MarkerDetails.getMarkerfourDuration(),false,car_markers.get(3));


                rotateMarker(car_markers.get(4),MarkerDetails.getMarkerfiveEangle().get(0),0);
                animateMarker(0,MarkerDetails.getMarkerfiveRoute(),MarkerDetails.getMarkerfiveEangle(),MarkerDetails.getMarkerfiveDuration(),false,car_markers.get(4));


            }
        }, 3500);


    }

    public void rotateMarker(final Marker marker, final float toRotation, final float st) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final float startRotation = st;
        final long duration = 105;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed / duration);
                float rot = t * toRotation + (1 - t) * startRotation;
                marker.setRotation(-rot > 180 ? rot / 2 : rot);
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                }
            }
        });
    }
    public void animateMarker(final int duration_time, final LatLng positn , final boolean hideMarke , final Marker m) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = mMap.getProjection();
        Point startPoint = proj.toScreenLocation(m.getPosition());
        final LatLng startLatLng = proj.fromScreenLocation(startPoint);
        final long duration = duration_time;
        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * positn.longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * positn.latitude + (1 - t)
                        * startLatLng.latitude;
                m.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                } else {
                    if (hideMarke) {
                        m.setVisible(false);
                    } else {
                        m.setVisible(true);
                    }
                }
            }
        });
    }


    public void animateMarker(final int x, final List<LatLng> list, final List<Integer> angle, final List<Integer> duration_t, final boolean hideMarke , final Marker m) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = mMap.getProjection();
        Point startPoint = proj.toScreenLocation(m.getPosition());
        final LatLng startLatLng = proj.fromScreenLocation(startPoint);
        final long duration = duration_t.get(x);
        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * list.get(x).longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * list.get(x).latitude + (1 - t)
                        * startLatLng.latitude;
                m.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                } else {
                    if (hideMarke) {
                        m.setVisible(false);
                    } else {
                        m.setVisible(true);
                        if(x<list.size()-1){
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    rotateMarker(m,angle.get(x+1),angle.get(x));
                                    animateMarker(x+1,list,angle,duration_t,false,m);
                                }
                            }, 100);
                        }else {
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    rotateMarker(m,angle.get(0),0);
                                    animateMarker(0,list,angle,duration_t,false,m);
                                }
                            }, 100);
                        }

                    }
                }
            }
        });
    }



    @Override
    public void onRoutingFailure() {
    }
    @Override
    public void onRoutingStart() {

    }
    @Override
    public void onRoutingSuccess(PolylineOptions polylineOptions, Route route) {
        PolylineOptions polyoptions = new PolylineOptions();
        polyoptions.color(Color.parseColor("#F2A24D"));
        polyoptions.width(12);
        polyoptions.addAll(polylineOptions.getPoints());
        mMap.addPolyline(polyoptions);
    }
    @Override
    public void onRoutingCancelled() {
    }

    //Draw Path

    private class connectAsyncTask extends AsyncTask<Void, Void, String> {

        String url;

        connectAsyncTask(String urlPass) {
            url = urlPass;
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            JSONParse jParser = new JSONParse();
            String json = jParser.getJSONFromUrl(url);
            return json;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null) {
                drawPath(result);
            }
        }
    }

    public void drawPath(String result) {
        try {
            final JSONObject json = new JSONObject(result);
            JSONArray routeArray = json.getJSONArray("routes");
            JSONObject routes = routeArray.getJSONObject(0);
            JSONObject overviewPolylines = routes.getJSONObject("overview_polyline");
            String encodedString = overviewPolylines.getString("points");
            List<LatLng> list_lat = decodePoly(encodedString);
            Routing routing = new Routing.Builder()
                    .avoid(AbstractRouting.AvoidKind.FERRIES)
                    .travelMode(Routing.TravelMode.DRIVING)
                    .withListener(CarSelectionScreen.this)
                    .waypoints(list_lat.get(list_lat.size() - 1), list_lat.get(0))
                    .build();
            routing.execute();
            mMap.addMarker(new MarkerOptions()
                    .position(list_lat.get(0))
                    .title("")
                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.destination_pin)));
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(list_lat.get(list_lat.size() - 1), 15);
            mMap.animateCamera(cameraUpdate);
        } catch (JSONException e) {
        }
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }
        return poly;
    }

    public String makeURL(double sourcelat, double sourcelog, double destlat, double destlog) {
        StringBuilder urlString = new StringBuilder();
        urlString.append("http://maps.googleapis.com/maps/api/directions/json");
        urlString.append("?origin=");// from
        urlString.append(Double.toString(sourcelat));
        urlString.append(",");
        urlString.append(Double.toString(sourcelog));
        urlString.append("&destination=");// to
        urlString.append(Double.toString(destlat));
        urlString.append(",");
        urlString.append(Double.toString(destlog));
        urlString.append("&sensor=false&mode=driving&alternatives=true");
        return urlString.toString();
    }
    public void SlideToAbove() {
        Animation slide = null;
        slide = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, -5.0f);

        slide.setDuration(400);
        slide.setFillAfter(true);
        slide.setFillEnabled(true);
        Driver_Profile.startAnimation(slide);

        slide.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {

                Driver_Profile.clearAnimation();

                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                        Driver_Profile.getWidth(), Driver_Profile.getHeight());
                // lp.setMargins(0, 0, 0, 0);
                lp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
                Driver_Profile.setLayoutParams(lp);

            }

        });

    }

    public void SlideToDown() {
        Animation slide = null;
        slide = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                0.0f, Animation.ABSOLUTE, 5.2f);
        slide.setDuration(1000);
        slide.setFillAfter(true);
        slide.setFillEnabled(true);
        Driver_Profile.startAnimation(slide);

        slide.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Driver_Profile.clearAnimation();
                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                        Driver_Profile.getWidth(), Driver_Profile.getHeight());
                lp.setMargins(0, 56, 0, 0);
                Driver_Profile.setLayoutParams(lp);
            }

        });

    }
}
