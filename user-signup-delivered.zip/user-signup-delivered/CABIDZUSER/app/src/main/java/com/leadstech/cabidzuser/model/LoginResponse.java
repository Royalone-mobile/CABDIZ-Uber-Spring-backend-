package com.leadstech.cabidzuser.model;
import java.util.List;
public class LoginResponse extends Response  {
    private String user_email;
    private LoginProperty property;

    public LoginProperty getProperty() {
        return property;
    }

    public void setProperty(LoginProperty property) {
        this.property = property;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }
}
