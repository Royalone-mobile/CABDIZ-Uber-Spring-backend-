/*
   For step-by-step instructions on connecting your Android application to this backend module,
   see "App Engine Java Endpoints Module" template documentation at
   https://github.com/GoogleCloudPlatform/gradle-appengine-templates/tree/master/HelloEndpoints
*/

package com.example.jawadali.myapplication.backend;

import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.appengine.api.datastore.Blob;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;
import org.apache.geronimo.mail.util.Base64;

import javax.inject.Named;
import java.util.List;

import sun.net.www.content.image.x_xbitmap;

/**
 * An endpoint class we are exposing
 */
@Api(
        name = "signUPApi",
        version = "v1",
        namespace = @ApiNamespace(
                ownerDomain = "backend.myapplication.jawadali.example.com",
                ownerName = "backend.myapplication.jawadali.example.com",
                packagePath = ""
        )
)
public class MyEndpoint {
    /**
     * A simple endpoint method that takes a name and says Hi back
     */
    @ApiMethod(name = "signUP")
    public User signUP(@Named("first_name") String first_name, @Named("last_name") String last_name,
                       @Named("email") String email,
                       @Named("phone_number") String phone_number,
                       @Named("password") String password,
                       @Named("card_number") String card_number,
                       @Named("card_expiry") String card_expiry,
                       @Named("card_cvc") String card_cvc,
                       @Named("image") String img) {
        User response = new User(first_name, last_name, email, phone_number, password, card_number, card_expiry, card_cvc,img);
        response.setFirstName(first_name);
        response.setLastName(last_name);
        response.setEmail(email);
        response.setPhoneNumber(phone_number);
        response.setPassword(password);
        response.setCardNumber(card_number);
        response.setCard_Expiry(card_expiry);
        response.setCard_CVC(card_cvc);
        response.setIMG(img);
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("CABIDZ_USER", email);

            Entity employee = new Entity(employeeKey);
            employee.setProperty("first_name", first_name);
            employee.setProperty("last_name", last_name);
            employee.setProperty("phone_number", phone_number);
            employee.setProperty("email", email);
            employee.setProperty("password", password);
            employee.setProperty("card_number", card_number);
            employee.setProperty("card_expiry", card_expiry);
            employee.setProperty("card_cvc", card_cvc);
            byte[] decodedByte = Base64.decode(img);
            Blob blob = new Blob(decodedByte);
            employee.setProperty("image", blob);
            datastore.put(employee);
            txn.commit();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
        }
        return response;
    }

    @ApiMethod(name = "login")
    public List<Entity> login(@Named("email") String email, @Named("password") String password) {
        Key employeeKey = KeyFactory.createKey("CABIDZ_USER", email);
        Entity employee = new Entity(employeeKey);
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        Key lastSeenKey = employee.getKey();
        Query.Filter keyFilter = new Query.FilterPredicate(Entity.KEY_RESERVED_PROPERTY, Query.FilterOperator.GREATER_THAN, lastSeenKey);
        Query q = new Query("CABIDZ_USER")
                .setFilter(Query.CompositeFilterOperator.and(
                        Query.CompositeFilterOperator.or(
                                new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email),
                                new Query.FilterPredicate("phone_number", Query.FilterOperator.EQUAL, email)),
                        new Query.FilterPredicate("password", Query.FilterOperator.EQUAL, password)));
        List<Entity> results = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
        return results;
    }
}
