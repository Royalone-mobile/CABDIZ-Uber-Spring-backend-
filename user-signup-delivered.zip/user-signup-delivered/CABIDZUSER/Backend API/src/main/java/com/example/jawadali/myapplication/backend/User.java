package com.example.jawadali.myapplication.backend;

import com.google.appengine.api.datastore.Blob;
import com.google.appengine.repackaged.com.google.api.client.util.Data;

/**
 * Created by jawadali on 5/2/17.
 */

public class User {
    private  String FirstName,LastName,PhoneNumber,Email,Password,CardNumber,Card_Expiry,Card_CVC;
    private String IMG;
   public User(String firstName, String lastName, String phoneNumber, String email, String password, String cardNumber, String card_Expiry, String card_CVC, String img){
        this.FirstName = firstName;
        this.LastName = lastName;
        this.PhoneNumber = phoneNumber;
        this.Email = email;
        this.Password = password;
        this.CardNumber = cardNumber;
        this.Card_Expiry = card_Expiry;
        this.Card_CVC = card_CVC;
        this.IMG = img;
    }
    public String getIMG() {
        return IMG;
    }

    public void setIMG(String IMG) {
        this.IMG = IMG;
    }

    public String getFirstName() {
        return FirstName;
    }


    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getCardNumber() {
        return CardNumber;
    }

    public void setCardNumber(String cardNumber) {
        CardNumber = cardNumber;
    }

    public String getCard_Expiry() {
        return Card_Expiry;
    }

    public void setCard_Expiry(String card_Expiry) {
        Card_Expiry = card_Expiry;
    }

    public String getCard_CVC() {
        return Card_CVC;
    }

    public void setCard_CVC(String card_CVC) {
        Card_CVC = card_CVC;
    }
}
