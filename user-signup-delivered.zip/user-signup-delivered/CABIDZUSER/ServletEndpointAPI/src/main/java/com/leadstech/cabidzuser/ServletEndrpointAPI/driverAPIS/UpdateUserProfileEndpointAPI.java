package com.leadstech.cabidzuser.ServletEndrpointAPI.driverAPIS;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Transaction;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by jawadali on 5/9/17.
 */

public class UpdateUserProfileEndpointAPI  extends HttpServlet {
    private String stripe_id,img_id,first_name, last_name, phone_number, email, password, address, city, state, postal_code, device_token;
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    private String successJSON = "";

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        //Firs_TableDATA (Driver Personal Details)
        device_token = req.getParameter("device_token");
        first_name = req.getParameter("first_name");
        last_name = req.getParameter("last_name");
        phone_number = req.getParameter("phone_number");
        email = req.getParameter("email");
        password = req.getParameter("password");
        stripe_id = req.getParameter("stripe_id");
        address = req.getParameter("address");
        city = req.getParameter("city");
        state = req.getParameter("state");
        img_id = req.getParameter("img_id");
        postal_code = req.getParameter("postal_code");
        if (!(postal_code.length() <= 0 &&
                first_name.length() <= 0 &&
                last_name.length() <= 0 &&
                address.length() <= 0 &&
                phone_number.length() <= 0 &&
                city.length() <= 0 &&
                state.length() <= 0
        )) {
            if (emailValidator(email)) {
                    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                    UploadData(datastore);
            } else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        } else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public void UploadData(DatastoreService datastore) {
        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("CABIDZ_DRIVER", email);
            Entity employee = new Entity(employeeKey);
            employee.setProperty("device_token", device_token);
            employee.setProperty("first_name", first_name);
            employee.setProperty("last_name", last_name);
            employee.setProperty("phone_number", phone_number);
            employee.setProperty("email", email);
            employee.setProperty("password", password);
            employee.setProperty("address", address);
            employee.setProperty("city", city);
            employee.setProperty("state", state);
            employee.setProperty("img_id",img_id );
            employee.setProperty("stripe_id",stripe_id );
            employee.setProperty("postal_code", postal_code);
            datastore.put(employee);
            txn.commit();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
            successJSON = "{\"status\":\"true\",\"message\":\"" + "User Profile Update Successfully!!" + "\"}";
        }
    }
}
