package com.leadstech.cabidzuser.ServletEndrpointAPI;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateProfileDataEndpointAPI extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
     private String successJSON = "";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String first_name = req.getParameter("first_name");
        String last_name = req.getParameter("last_name");
        String phone_number = req.getParameter("phone_number");
        if(!(first_name.length() <= 0 && last_name.length() <= 0 && phone_number.length() <= 0)){
            if(emailValidator(email)){
                if(password.length() > 7){
                    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                    Query q = new Query("CABIDZ_USER")
                            .setFilter(Query.CompositeFilterOperator.and(new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email),new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email) ));
                    List<Entity> user_data = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
                    if(user_data.size() >0){
                        Transaction txn = datastore.beginTransaction();
                        try {
                            Key employeeKey = KeyFactory.createKey("CABIDZ_USER", email);
                            Entity employee = new Entity(employeeKey);
                            employee.setProperty("first_name", first_name);
                            employee.setProperty("last_name", last_name);
                            employee.setProperty("phone_number", phone_number);
                            employee.setProperty("email", user_data.get(0).getProperty("email"));
                            employee.setProperty("password", password);
                            employee.setProperty("postal_code",  user_data.get(0).getProperty("postal_code"));
                            employee.setProperty("stripe_id", user_data.get(0).getProperty("stripe_id"));
                            employee.setProperty("card_expiry",  user_data.get(0).getProperty("card_expiry"));
                            employee.setProperty("img_id", user_data.get(0).getProperty("img_id"));
                            datastore.put(employee);
                            txn.commit();
                        } finally {
                            if (txn.isActive()) {
                                txn.rollback();
                            }
                            successJSON = "{\"status\":\"true\",\"message\":\"" + "Record has been updated successfully!!" + "\"}";
                        }
                    }else {
                        successJSON = "{\"status\":\"false\",\"message\":\"" + "Email address not exist!!" + "\"}";
                    }
                }else {
                    successJSON = "{\"status\":\"false\",\"message\":\"" + "password is too short, must be grater then 7 character!" + "\"}";
                }
            }else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
