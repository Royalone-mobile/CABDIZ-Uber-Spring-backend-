package com.leadstech.cabidzuser.ServletEndrpointAPI;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Query;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Logger;
import com.google.appengine.api.datastore.Blob;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;
import com.google.appengine.repackaged.com.google.gson.JsonObject;

import javax.servlet.http.*;
public class RetrieveImage extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String img_id = req.getParameter("img_id");
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        Query q = new Query("UPLOAD") .setFilter(Query.CompositeFilterOperator.and(
                        new Query.FilterPredicate("img_id", Query.FilterOperator.EQUAL, img_id),
                        new Query.FilterPredicate("img_id", Query.FilterOperator.EQUAL, img_id)));
        List<Entity> results = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
        String successJSON = "";
        if(results.size() > 0){
            successJSON = "{\"status\":\"true\",\"message\":\"" + "image retrieve successfully" + "\",\"img_data\":\""+
                    results.get(0).getProperty("data_1")+
                    results.get(0).getProperty("data_2")+
                    results.get(0).getProperty("data_3")+
                    results.get(0).getProperty("data_4")+
                    results.get(0).getProperty("data_5")+
                    results.get(0).getProperty("data_6")+
                    results.get(0).getProperty("data_7")+
                    results.get(0).getProperty("data_8")+
                    results.get(0).getProperty("data_9")+
                    results.get(0).getProperty("data_10")+
                    results.get(0).getProperty("data_11")+
                    results.get(0).getProperty("data_12")+
                    results.get(0).getProperty("data_13")+
                    results.get(0).getProperty("data_14")+
                    results.get(0).getProperty("data_15")+
                    results.get(0).getProperty("data_16")+
                    results.get(0).getProperty("data_17")+
                    results.get(0).getProperty("data_18")+
                    results.get(0).getProperty("data_19")+
                    results.get(0).getProperty("data_20")+
                    results.get(0).getProperty("data_21")+
                    results.get(0).getProperty("data_22")+
                    results.get(0).getProperty("data_23")+
                    results.get(0).getProperty("data_24")+
                    results.get(0).getProperty("data_25")+
                    results.get(0).getProperty("data_26")+
                    results.get(0).getProperty("data_27")+
                    results.get(0).getProperty("data_28")+
                    results.get(0).getProperty("data_29")+
                    results.get(0).getProperty("data_30")
                    +"\"}";

        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "no image found!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }
}
