package com.leadstech.cabidzuser.ServletEndrpointAPI.driverAPIS;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Query;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmailVerification extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String successJSON = "";
        String email = req.getParameter("email");
        if(!(email.length() <= 0 )){
            if(emailValidator(email)){
                    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                    Query q = new Query("CABIDZ_DRIVER")
                            .setFilter(Query.CompositeFilterOperator.and(new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email.toLowerCase()),new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email.toLowerCase()) ));
                    List<Entity> user_data = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
                    if(user_data.size() > 0){
                        successJSON = "{\"status\":\"false\",\"message\":\"" + "Email address already exist!!" + "\"}";
                    }else {
                        successJSON = "{\"status\":\"true\",\"message\":\"" + "Email is available" + "\"}";
                    }
            }else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }
    private boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
