package com.leadstech.cabidzuser.ServletEndrpointAPI.driverAPIS;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Transaction;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateUserCarEndpointAPI extends HttpServlet {
    private String first_name, last_name, phone_number, email, password, address, city, state, postal_code, bank_account_number, account_holder_name, BSB, driver_license_expiry, driver_license_doc_ID, driver_license_status, RMS_driver_history,
            RMS_doc_ID, RMS_doc_status, driver_authority_card, driver_authority_card_doc_ID, driver_authority_card_status,
            driver_proof_ID, driver_proof_doc_ID, driver_proof_doc_status, driver_license_backdoc_ID, driver_license_back_doc_Status, vehicle, category, number_plate, texi_company, additional_information, device_token;
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    private String successJSON = "";

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        email = req.getParameter("email");
        vehicle = req.getParameter("vehicle");
        category = req.getParameter("category");
        number_plate = req.getParameter("number_plate");
        texi_company = req.getParameter("texi_company");
        additional_information = req.getParameter("additional_information");

        if (!( email.length() <= 0 &&
                vehicle.length() <= 0 &&
                category.length() <= 0 &&
                number_plate.length() <= 0 &&
                texi_company.length() <= 0 &&
                additional_information.length() <= 0
        )) {
            if (emailValidator(email)) {
                    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                    UploadData(datastore);
            } else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        } else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public void UploadData(DatastoreService datastore) {
        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("CABIDZ_DRIVER_CAR_DETAILS", email);
            Entity employee = new Entity(employeeKey);
            employee.setProperty("driverID", email);
            employee.setProperty("vehicle", vehicle);
            employee.setProperty("category", category);
            employee.setProperty("number_plate", number_plate);
            employee.setProperty("texi_company", texi_company);
            employee.setProperty("additional_information", additional_information);
            datastore.put(employee);
            txn.commit();
        } catch (Exception e){
            successJSON = "{\"status\":\"false\",\"message\":\"" + "Record updating Failed!!!" + "\"}";

        } finally{
            if (txn.isActive()) {
                txn.rollback();
            }
            successJSON = "{\"status\":\"true\",\"message\":\"" + "Record has been updated successfully!!" + "\"}";

        }
    }
}
