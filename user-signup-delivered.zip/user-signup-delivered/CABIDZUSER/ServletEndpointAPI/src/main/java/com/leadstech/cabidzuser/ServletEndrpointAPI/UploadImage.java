package com.leadstech.cabidzuser.ServletEndrpointAPI;

import com.google.appengine.api.blobstore.BlobKey;
import com.google.appengine.api.blobstore.BlobstoreService;
import com.google.appengine.api.blobstore.BlobstoreServiceFactory;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Transaction;
import com.google.appengine.api.images.ImagesService;
import com.google.appengine.api.images.ImagesServiceFactory;
import com.google.appengine.api.images.ServingUrlOptions;
import com.google.appengine.repackaged.com.google.gson.JsonObject;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class UploadImage extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    private String successJSON = "";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        String img_id = req.getParameter("img_id");
      String data_1 = req.getParameter("data_1");
      String data_2 = req.getParameter("data_2");
      String data_3 = req.getParameter("data_3");
      String data_4 = req.getParameter("data_4");
      String data_5 = req.getParameter("data_5");

      String data_6 = req.getParameter("data_6");
      String data_7 = req.getParameter("data_7");
      String data_8 = req.getParameter("data_8");
      String data_9 = req.getParameter("data_9");
      String data_10 = req.getParameter("data_10");

      String data_11 = req.getParameter("data_11");
      String data_12 = req.getParameter("data_12");
      String data_13 = req.getParameter("data_13");
      String data_14 = req.getParameter("data_14");
      String data_15 = req.getParameter("data_15");

      String data_16 = req.getParameter("data_16");
      String data_17 = req.getParameter("data_17");
      String data_18 = req.getParameter("data_18");
      String data_19 = req.getParameter("data_19");
      String data_20 = req.getParameter("data_20");

      String data_21 = req.getParameter("data_21");
      String data_22 = req.getParameter("data_22");
      String data_23 = req.getParameter("data_23");
      String data_24 = req.getParameter("data_24");
      String data_25 = req.getParameter("data_25");

      String data_26 = req.getParameter("data_26");
      String data_27 = req.getParameter("data_27");
      String data_28 = req.getParameter("data_28");
      String data_29 = req.getParameter("data_29");
      String data_30 = req.getParameter("data_30");


        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("UPLOAD", img_id);
            Entity employee = new Entity(employeeKey);
            employee.setProperty("img_id", img_id);
            employee.setProperty("data_1", data_1);
            employee.setProperty("data_2", data_2);
            employee.setProperty("data_3", data_3);
            employee.setProperty("data_4", data_4);
            employee.setProperty("data_5", data_5);
            employee.setProperty("data_6", data_6);
            employee.setProperty("data_7", data_7);
            employee.setProperty("data_8", data_8);
            employee.setProperty("data_9", data_9);

            employee.setProperty("data_10", data_10);
            employee.setProperty("data_11", data_11);
            employee.setProperty("data_12", data_12);
            employee.setProperty("data_13", data_13);
            employee.setProperty("data_14", data_14);
            employee.setProperty("data_15", data_15);
            employee.setProperty("data_16", data_16);
            employee.setProperty("data_17", data_17);
            employee.setProperty("data_18", data_18);
            employee.setProperty("data_19", data_19);
            employee.setProperty("data_20", data_20);

            employee.setProperty("data_21", data_21);
            employee.setProperty("data_22", data_22);
            employee.setProperty("data_23", data_23);
            employee.setProperty("data_24", data_24);
            employee.setProperty("data_25", data_25);
            employee.setProperty("data_26", data_26);
            employee.setProperty("data_27", data_27);
            employee.setProperty("data_28", data_28);
            employee.setProperty("data_29", data_29);
            employee.setProperty("data_30", data_30);
            datastore.put(employee);
            txn.commit();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
            successJSON = "{\"status\":\"true\",\"message\":\"" + "image has been uploaded successfully!!"+ "\"}";
        }
      resp.setContentType(JSON_CONTENT_TYPE);
      resp.getWriter().println(successJSON);
    }
//    public String getImageUrl(HttpServletRequest req, HttpServletResponse resp,
//                              final String bucket) throws IOException, ServletException {
//        Part filePart = req.getPart("file");
//        final String fileName = filePart.getSubmittedFileName();
//        String imageUrl = req.getParameter("imageUrl");
//        // Check extension of file
//        if (fileName != null && !fileName.isEmpty() && fileName.contains(".")) {
//            final String extension = fileName.substring(fileName.lastIndexOf('.') + 1);
//            String[] allowedExt = { "jpg", "jpeg", "png", "gif" };
//            for (String s : allowedExt) {
//                if (extension.equals(s)) {
//                    return this.uploadFile(filePart, bucket);
//                }
//            }
//            throw new ServletException("file must be an image");
//        }
//        return imageUrl;
//    }
}