/*
   For step-by-step instructions on connecting your Android application to this backend module,
   see "App Engine Java Servlet Module" template documentation at
   https://github.com/GoogleCloudPlatform/gradle-appengine-templates/tree/master/HelloWorld
*/

package com.leadstech.cabidzuser.ServletEndrpointAPI.driverAPIS;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Query;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.leadstech.cabidzuser.ServletEndrpointAPI.LoginEndpointAPI.md5;

public class LoginEndpointAPI extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String email = req.getParameter("email");
        String password = md5(req.getParameter("password"));
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        Query q = new Query("CABIDZ_DRIVER")
                .setFilter(Query.CompositeFilterOperator.and(
                        Query.CompositeFilterOperator.or(
                                new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email.toLowerCase()),
                                new Query.FilterPredicate("phone_number", Query.FilterOperator.EQUAL, email.toLowerCase())),
                        new Query.FilterPredicate("password", Query.FilterOperator.EQUAL, password)));
        List<Entity> results = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
        String successJSON = "";
        if(results.size() > 0){
            Query second_query = new Query("CABIDZ_DRIVER_DOCUMENT_DETAILS")
                    .setFilter(Query.CompositeFilterOperator.and(
                                      new Query.FilterPredicate("driverID", Query.FilterOperator.EQUAL, email),
                                    new Query.FilterPredicate("driverID", Query.FilterOperator.EQUAL, email)));
            List<Entity> driver_document_details = datastore.prepare(second_query.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());

            Query third_query = new Query("CABIDZ_DRIVER_CAR_DETAILS")
                    .setFilter(Query.CompositeFilterOperator.and( new Query.FilterPredicate("driverID", Query.FilterOperator.EQUAL, email),
                                    new Query.FilterPredicate("driverID", Query.FilterOperator.EQUAL, email)));
            List<Entity> driver_car_details = datastore.prepare(third_query.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
            successJSON = "{\"status\": \"true\",\"message\": \"Login Success\",\"user_email\": \" "+email+" \",\"device_token\": \" " + results.get(0).getProperty("device_token") + " \",\"property\": {" +
                    "\"first_name\": \""+results.get(0).getProperty("first_name")+"\"," +
                    "\"last_name\": \""+results.get(0).getProperty("last_name")+"\"," +
                    "\"phone_number\": \""+results.get(0).getProperty("phone_number")+"\"," +
                    "\"email\": \""+results.get(0).getProperty("email")+"\"," +
                    "\"password\": \""+results.get(0).getProperty("password")+"\"," +
                    "\"address\": \""+results.get(0).getProperty("address")+"\"," +
                    "\"stripe_id\": \""+results.get(0).getProperty("stripe_id")+"\"," +
                    "\"city\": \""+results.get(0).getProperty("city")+"\"," +
                    "\"state\": \""+results.get(0).getProperty("state")+"\"," +
                    "\"postal_code\": \""+results.get(0).getProperty("postal_code")+"\"," +
                    "\"img_id\": \""+results.get(0).getProperty("img_id")+"\"," +
                    "\"driver_license_expiry\": \""+driver_document_details.get(0).getProperty("driver_license_expiry")+"\"," +
                    "\"driver_license_doc_ID\": \""+driver_document_details.get(0).getProperty("driver_license_doc_ID")+"\"," +
                    "\"driver_license_status\": \""+driver_document_details.get(0).getProperty("driver_license_status")+"\"," +
                    "\"RMS_driver_history\": \""+driver_document_details.get(0).getProperty("RMS_driver_history")+"\"," +
                    "\"RMS_doc_ID\": \""+driver_document_details.get(0).getProperty("RMS_doc_ID")+"\"," +
                    "\"RMS_doc_status\": \""+driver_document_details.get(0).getProperty("RMS_doc_status")+"\"," +
                    "\"driver_authority_card\": \""+driver_document_details.get(0).getProperty("driver_authority_card")+"\"," +
                    "\"driver_authority_card_doc_ID\": \""+driver_document_details.get(0).getProperty("driver_authority_card_doc_ID")+"\"," +
                    "\"driver_authority_card_status\": \""+driver_document_details.get(0).getProperty("driver_authority_card_status")+"\"," +
                    "\"driver_proof_ID\": \""+driver_document_details.get(0).getProperty("driver_proof_ID")+"\"," +
                    "\"driver_proof_doc_ID\": \""+driver_document_details.get(0).getProperty("driver_proof_doc_ID")+"\"," +
                    "\"driver_proof_doc_status\": \""+driver_document_details.get(0).getProperty("driver_proof_doc_status")+"\"," +
                    "\"driver_license_backdoc_ID\": \""+driver_document_details.get(0).getProperty("driver_license_backdoc_ID")+"\"," +
                    "\"driver_license_back_doc_Status\": \""+driver_document_details.get(0).getProperty("driver_license_back_doc_Status")+"\"," +
                    "\"vehicle\": \""+driver_car_details.get(0).getProperty("vehicle")+"\"," +
                    "\"category\": \""+driver_car_details.get(0).getProperty("category")+"\"," +
                    "\"number_plate\": \""+driver_car_details.get(0).getProperty("number_plate")+"\"," +
                    "\"texi_company\": \""+driver_car_details.get(0).getProperty("texi_company")+"\"," +
                    "\"additional_information\": \""+driver_car_details.get(0).getProperty("additional_information")+"\"" +
                    "}" +
                    "}";
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "wrong username or password" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

}
