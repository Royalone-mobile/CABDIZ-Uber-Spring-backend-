package com.leadstech.cabidzuser.ServletEndrpointAPI.driverAPIS;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.leadstech.cabidzuser.ServletEndrpointAPI.LoginEndpointAPI.md5;

public class ResetPasswordAPI extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String successJSON = "";
        String email = req.getParameter("email");
        String password = md5(req.getParameter("password"));
        if(!(email.length() <= 0 && password.length() <= 0)){
            if(emailValidator(email)){
                if(password.length() > 7){
                    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                    Query q = new Query("CABIDZ_DRIVER")
                            .setFilter(Query.CompositeFilterOperator.and(new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email),new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email) ));
                    List<Entity> user_data = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
                    if(user_data.size() >0){
                        Transaction txn = datastore.beginTransaction();
                        try {
                            Key employeeKey = KeyFactory.createKey("CABIDZ_DRIVER", email);
                            Entity employee = new Entity(employeeKey);
                            employee.setProperty("device_token", user_data.get(0).getProperty("device_token"));
                            employee.setProperty("first_name", user_data.get(0).getProperty("first_name"));
                            employee.setProperty("last_name", user_data.get(0).getProperty("last_name"));
                            employee.setProperty("phone_number", user_data.get(0).getProperty("phone_number"));
                            employee.setProperty("email", email);
                            employee.setProperty("password", password);
                            employee.setProperty("address", user_data.get(0).getProperty("address"));
                            employee.setProperty("img_id", user_data.get(0).getProperty("img_id"));
                            employee.setProperty("stripe_id", user_data.get(0).getProperty("stripe_id"));
                            employee.setProperty("city", user_data.get(0).getProperty("city"));
                            employee.setProperty("state", user_data.get(0).getProperty("state"));
                            employee.setProperty("postal_code", user_data.get(0).getProperty("postal_code"));
                            datastore.put(employee);
                            txn.commit();
                        } finally {
                            if (txn.isActive()) {
                                txn.rollback();
                            }
                            successJSON = "{\"status\": \"true\",\"message\": \"password updated successfully!!\",\"user_email\": \" "+email + "\"}";
                        }
                    }else {
                        successJSON = "{\"status\":\"false\",\"message\":\"" + "Email address not exist!!" + "\"}";
                    }
                }else {
                    successJSON = "{\"status\":\"false\",\"message\":\"" + "password is too short, must be grater then 7 character!" + "\"}";
                }
            }else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
