package com.leadstech.cabidzuser.ServletEndrpointAPI;
import com.google.appengine.api.datastore.Blob;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

import org.apache.geronimo.mail.util.Base64;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.leadstech.cabidzuser.ServletEndrpointAPI.LoginEndpointAPI.md5;

public class SignUpEndpointAPI extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    private String successJSON = "";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String email = req.getParameter("email");
        String password = md5(req.getParameter("password"));
        String first_name = req.getParameter("first_name");
        String last_name = req.getParameter("last_name");
        String phone_number = req.getParameter("phone_number");
        String card_expiry = req.getParameter("card_expiry");
        String img_id = req.getParameter("img_id");
        String stripe_id = req.getParameter("stripe_id");
        String postal_code = req.getParameter("postal_code");

        if(!( stripe_id.length() <= 0 &&  postal_code.length() <= 0 && email.length() <= 0 && password.length() <= 0 && first_name.length() <= 0 && last_name.length() <= 0 && phone_number.length() <= 0 &&  card_expiry.length() <= 0 &&  img_id.length() <= 0)){
            if(emailValidator(email)){
                 if(password.length() > 7){
                     DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                     Transaction txn = datastore.beginTransaction();
                     try {
                         Key employeeKey = KeyFactory.createKey("CABIDZ_USER", email);
                         Entity employee = new Entity(employeeKey);
                         employee.setProperty("first_name", first_name);
                         employee.setProperty("last_name", last_name);
                         employee.setProperty("phone_number", phone_number);
                         employee.setProperty("email", email.toLowerCase());
                         employee.setProperty("password", password);
                         employee.setProperty("card_expiry", card_expiry);
                         employee.setProperty("img_id", img_id);
                         employee.setProperty("stripe_id", stripe_id);
                         employee.setProperty("postal_code", postal_code);
                         datastore.put(employee);
                         txn.commit();
                     } finally {
                         if (txn.isActive()) {
                             txn.rollback();
                         }
                         successJSON = "{\"status\": \"true\",\"message\": \"User Registered Successfully\",\"user_email\": \" "+email+" \",\"property\": {" +
                                 "\"first_name\": \""+first_name+"\"," +
                                 "\"card_expiry\": \""+card_expiry+"\"," +
                                 "\"phone_number\": \""+phone_number+"\"," +
                                 "\"email\": \""+email.toLowerCase()+"\"," +
                                 "\"last_name\": \""+last_name+"\"," +
                                 "\"img_id\": \""+img_id+"\"," +
                                 "\"stripe_id\": \""+stripe_id+"\"," +
                                 "\"password\": \""+password+"\"," +
                                 "\"postal_code\": \""+postal_code+"\"" +
                                 "}" + "}";
                     }
                 }else {
                     successJSON = "{\"status\":\"false\",\"message\":\"" + "password is too short, must be grater then 7 character!" + "\"}";
                 }
            }else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
