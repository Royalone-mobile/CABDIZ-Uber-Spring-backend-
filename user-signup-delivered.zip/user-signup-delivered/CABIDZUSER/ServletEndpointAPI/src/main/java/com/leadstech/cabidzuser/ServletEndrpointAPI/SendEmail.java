package com.leadstech.cabidzuser.ServletEndrpointAPI;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SendEmail extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    private String successJSON = "";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String email = req.getParameter("email");
        String name = req.getParameter("name");
        String subject = req.getParameter("subject");
        String text = req.getParameter("text");
        if(!( email.length() <= 0 && name.length() <= 0 && subject.length() <= 0 && text.length() <= 0 )){
            if(text.equalsIgnoreCase("user_ios_call")){
                text = "Please use the following link to reset your password! <a href='https://0-dot-massive-amulet-153623.appspot.com/forgot_password.html'> <h1> Rest Password </h1> </a>";
            } else if (text.equalsIgnoreCase("driver_ios_call")) {
                text = "Please use the following link to reset your password! <a href='https://0-dot-massive-amulet-153623.appspot.com/Driver_forgot_password.html'> <h1> Rest Password </h1> </a>";
            }
            sendSimpleMail(email,name,subject,text);
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\" parameters are missing!!\"}";
        }

        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

 private void sendSimpleMail(String Email , String Name, String Subject, String Text) {
        Properties props = new Properties();
        Session session = Session.getDefaultInstance(props, null);
        try {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress("jawadali1008@gmail.com", "CABIDZ"));
            msg.addRecipient(Message.RecipientType.TO,
                    new InternetAddress(Email, "USER"));
            msg.setSubject(Subject);
            msg.setContent(Text, "text/html; charset=utf-8");
//            msg.setText(Text);
            Transport.send(msg);
            successJSON = "{\"status\":\"true\",\"message\":\"" + "email has been sent successfully!!" + "\"}";
        } catch (MessagingException | UnsupportedEncodingException e) {
            successJSON = "{\"status\":\"false\",\"message\":\"" + e.getMessage() + "\"}";

        }
    }
}
