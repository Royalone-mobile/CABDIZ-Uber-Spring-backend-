/*
   For step-by-step instructions on connecting your Android application to this backend module,
   see "App Engine Java Servlet Module" template documentation at
   https://github.com/GoogleCloudPlatform/gradle-appengine-templates/tree/master/HelloWorld
*/

package com.leadstech.cabidzuser.ServletEndrpointAPI;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Logger;
import com.google.appengine.api.datastore.Blob;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;
import com.google.appengine.repackaged.com.google.gson.JsonObject;

import javax.servlet.http.*;

public class LoginEndpointAPI extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String name = req.getParameter("email");
        String password = md5(req.getParameter("password"));
        DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        Query q = new Query("CABIDZ_USER")
                .setFilter(Query.CompositeFilterOperator.and(
                        Query.CompositeFilterOperator.or(
                                new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, name.toLowerCase()),
                                new Query.FilterPredicate("phone_number", Query.FilterOperator.EQUAL, name.toLowerCase())),
                        new Query.FilterPredicate("password", Query.FilterOperator.EQUAL, password)));
        List<Entity> results = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
        String successJSON = "";
        if(results.size() > 0){
            successJSON = "{\"status\": \"true\",\"message\": \"Login Success\",\"user_email\": \" "+name+" \",\"property\": {" +
                    "\"first_name\": \""+results.get(0).getProperty("first_name")+"\"," +
                    "\"card_expiry\": \""+results.get(0).getProperty("card_expiry")+"\"," +
                    "\"phone_number\": \""+results.get(0).getProperty("phone_number")+"\"," +
                    "\"email\": \""+results.get(0).getProperty("email").toString().toLowerCase()+"\"," +
                    "\"last_name\": \""+results.get(0).getProperty("last_name")+"\"," +
                    "\"postal_code\": \""+results.get(0).getProperty("postal_code")+"\"," +
                    "\"img_id\": \""+results.get(0).getProperty("img_id")+"\"," +
                    "\"stripe_id\": \""+results.get(0).getProperty("stripe_id")+"\"," +
                    "\"password\": \""+results.get(0).getProperty("password")+"\"" +
                    "}" +
                    "}";
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "wrong username or password" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }
    public static final String md5(final String s) {
        final String MD5 = "MD5";
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest
                    .getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
}
