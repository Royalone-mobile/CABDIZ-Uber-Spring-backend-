package com.leadstech.cabidzuser.ServletEndrpointAPI.driverAPIS;

import com.google.appengine.api.datastore.Blob;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

import org.apache.geronimo.mail.util.Base64;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.leadstech.cabidzuser.ServletEndrpointAPI.LoginEndpointAPI.md5;

public class SignUpEndpointAPI extends HttpServlet {
    private String stripe_id,img_id,first_name, last_name, phone_number, email, password, address, city, state, postal_code, driver_license_expiry, driver_license_doc_ID, driver_license_status, RMS_driver_history,
            RMS_doc_ID, RMS_doc_status, driver_authority_card, driver_authority_card_doc_ID, driver_authority_card_status,
            driver_proof_ID, driver_proof_doc_ID, driver_proof_doc_status, driver_license_backdoc_ID, driver_license_back_doc_Status, vehicle, category, number_plate, texi_company, additional_information, device_token;
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    private String successJSON = "";

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        //Firs_TableDATA (Driver Personal Details)
        device_token = req.getParameter("device_token");
        img_id = req.getParameter("img_id");
        first_name = req.getParameter("first_name");
        last_name = req.getParameter("last_name");
        phone_number = req.getParameter("phone_number");
        email = req.getParameter("email");
        password = md5(req.getParameter("password"));
        stripe_id = req.getParameter("stripe_id");
        address = req.getParameter("address");
        city = req.getParameter("city");
        state = req.getParameter("state");
        postal_code = req.getParameter("postal_code");

        //Second Table Data  (Driver Document Details)

        driver_license_expiry = req.getParameter("driver_license_expiry");
        driver_license_doc_ID = req.getParameter("driver_license_doc_ID");
        driver_license_status = req.getParameter("driver_license_status");

        RMS_driver_history = req.getParameter("RMS_driver_history");
        RMS_doc_ID = req.getParameter("RMS_doc_ID");
        RMS_doc_status = req.getParameter("RMS_doc_status");

        driver_authority_card = req.getParameter("driver_authority_card");
        driver_authority_card_doc_ID = req.getParameter("driver_authority_card_doc_ID");
        driver_authority_card_status = req.getParameter("driver_authority_card_status");

        driver_proof_ID = req.getParameter("driver_proof_ID");
        driver_proof_doc_ID = req.getParameter("driver_proof_doc_ID");
        driver_proof_doc_status = req.getParameter("driver_proof_doc_status");

        driver_license_backdoc_ID = req.getParameter("driver_license_backdoc_ID");
        driver_license_back_doc_Status = req.getParameter("driver_license_back_doc_Status");

        //Third Table Data  (Driver Car Details)
        vehicle = req.getParameter("vehicle");
        category = req.getParameter("category");
        number_plate = req.getParameter("number_plate");
        texi_company = req.getParameter("texi_company");
        additional_information = req.getParameter("additional_information");

        if (!(postal_code.length() <= 0 &&
                img_id.length() <= 0
                && email.length() <= 0 &&
                password.length() <= 0 &&
                first_name.length() <= 0 &&
                last_name.length() <= 0 &&
                address.length() <= 0 &&
                phone_number.length() <= 0 &&
                city.length() <= 0 &&
                state.length() <= 0 &&
                stripe_id.length() <= 0 &&

                driver_license_expiry.length() <= 0 &&
                driver_license_doc_ID.length() <= 0 &&
                driver_license_status.length() <= 0 &&
                RMS_driver_history.length() <= 0 &&
                RMS_doc_ID.length() <= 0 &&
                RMS_doc_status.length() <= 0 &&
                driver_authority_card.length() <= 0 &&
                driver_authority_card_doc_ID.length() <= 0 &&
                driver_authority_card_status.length() <= 0 &&
                driver_proof_ID.length() <= 0 &&
                driver_proof_doc_ID.length() <= 0 &&
                driver_proof_doc_status.length() <= 0 &&
                driver_license_backdoc_ID.length() <= 0 &&
                driver_license_back_doc_Status.length() <= 0 &&

                vehicle.length() <= 0 &&
                category.length() <= 0 &&
                number_plate.length() <= 0 &&
                texi_company.length() <= 0 &&
                additional_information.length() <= 0
        )) {
            if (emailValidator(email)) {
                if (password.length() > 7) {
                    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                     UploadData(datastore);
                } else {
                    successJSON = "{\"status\":\"false\",\"message\":\"" + "password is too short, must be grater then 7 character!" + "\"}";
                }
            } else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        } else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public void UploadData(DatastoreService datastore) {
        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("CABIDZ_DRIVER", email);
            Entity employee = new Entity(employeeKey);
            employee.setProperty("device_token", device_token);
            employee.setProperty("first_name", first_name);
            employee.setProperty("last_name", last_name);
            employee.setProperty("phone_number", phone_number);
            employee.setProperty("email", email.toLowerCase());
            employee.setProperty("password", password);
            employee.setProperty("address", address);
            employee.setProperty("city", city);
            employee.setProperty("state", state);
            employee.setProperty("img_id", img_id);
            employee.setProperty("postal_code", postal_code);
            employee.setProperty("stripe_id", stripe_id);
            datastore.put(employee);
            txn.commit();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
            // upload document detail
            UploadDocumentData(datastore);
        }
    }

    public void UploadDocumentData( DatastoreService datastore) {
        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("CABIDZ_DRIVER_DOCUMENT_DETAILS", email);
            Entity employee = new Entity(employeeKey);
            employee.setProperty("driverID", email);
            employee.setProperty("driver_license_expiry", driver_license_expiry);
            employee.setProperty("driver_license_doc_ID", driver_license_doc_ID);
            employee.setProperty("driver_license_status", driver_license_status);
            employee.setProperty("RMS_driver_history", RMS_driver_history);
            employee.setProperty("RMS_doc_ID", RMS_doc_ID);
            employee.setProperty("RMS_doc_status", RMS_doc_status);
            employee.setProperty("driver_authority_card", driver_authority_card);
            employee.setProperty("driver_authority_card_doc_ID", driver_authority_card_doc_ID);
            employee.setProperty("driver_authority_card_status", driver_authority_card_status);
            employee.setProperty("driver_proof_ID", driver_proof_ID);
            employee.setProperty("driver_proof_doc_ID", driver_proof_doc_ID);
            employee.setProperty("driver_proof_doc_status", driver_proof_doc_status);
            employee.setProperty("driver_license_backdoc_ID", driver_license_backdoc_ID);
            employee.setProperty("driver_license_back_doc_Status", driver_license_back_doc_Status);
            datastore.put(employee);
            txn.commit();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
            // upload Car detail
            uploadCarDetails(datastore);
        }
    }

    public void uploadCarDetails( DatastoreService datastore) {
        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("CABIDZ_DRIVER_CAR_DETAILS", email);
            Entity employee = new Entity(employeeKey);
            employee.setProperty("driverID", email);
            employee.setProperty("vehicle", vehicle);
            employee.setProperty("category", category);
            employee.setProperty("number_plate", number_plate);
            employee.setProperty("texi_company", texi_company);
            employee.setProperty("additional_information", additional_information);
            datastore.put(employee);
            txn.commit();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
            // print Response;
            successJSON = "{\"status\": \"true\",\"message\": \"User Registered Successfully\",\"user_email\": \""+email+"\",\"device_token\": \""+ device_token + "\",\"property\": {" +
                    "\"first_name\": \""+first_name+"\"," +
                    "\"last_name\": \""+last_name+"\"," +
                    "\"phone_number\": \""+phone_number+"\"," +
                    "\"email\": \""+email+"\"," +
                    "\"password\": \""+password+"\"," +
                    "\"address\": \""+address+"\"," +
                    "\"city\": \""+city+"\"," +
                    "\"state\": \""+state+"\"," +
                    "\"postal_code\": \""+postal_code+"\"," +
                    "\"stripe_id\": \""+stripe_id+"\"," +
                    "\"img_id\": \""+img_id+"\"," +
                    "\"driver_license_expiry\": \""+driver_license_expiry+"\"," +
                    "\"driver_license_doc_ID\": \""+driver_license_doc_ID+"\"," +
                    "\"driver_license_status\": \""+driver_license_status+"\"," +
                    "\"RMS_driver_history\": \""+RMS_driver_history+"\"," +
                    "\"RMS_doc_ID\": \""+RMS_doc_ID+"\"," +
                    "\"RMS_doc_status\": \""+RMS_doc_status+"\"," +
                    "\"driver_authority_card\": \""+driver_authority_card+"\"," +
                    "\"driver_authority_card_doc_ID\": \""+driver_authority_card_doc_ID+"\"," +
                    "\"driver_authority_card_status\": \""+driver_authority_card_status+"\"," +
                    "\"driver_proof_ID\": \""+driver_proof_ID+"\"," +
                    "\"driver_proof_doc_ID\": \""+driver_proof_doc_ID+"\"," +
                    "\"driver_proof_doc_status\": \""+driver_proof_doc_status+"\"," +
                    "\"driver_license_backdoc_ID\": \""+driver_license_backdoc_ID+"\"," +
                    "\"driver_license_back_doc_Status\": \""+driver_license_back_doc_Status+"\"," +
                    "\"vehicle\": \""+vehicle+"\"," +
                    "\"category\": \""+category+"\"," +
                    "\"number_plate\": \""+number_plate+"\"," +
                    "\"texi_company\": \""+texi_company+"\"," +
                    "\"additional_information\": \""+additional_information+"\"," +
                    "\"device_token\": \""+device_token+"\"" +
                    "}" +
                    "}";
        }
    }
}
