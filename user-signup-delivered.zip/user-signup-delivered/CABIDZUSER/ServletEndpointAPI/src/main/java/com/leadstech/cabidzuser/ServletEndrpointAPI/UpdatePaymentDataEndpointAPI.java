package com.leadstech.cabidzuser.ServletEndrpointAPI;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdatePaymentDataEndpointAPI extends HttpServlet {
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String successJSON = "";
        String email = req.getParameter("email");
        String card_number = req.getParameter("card_number");
        String card_expiry = req.getParameter("card_expiry");
        String card_cvc = req.getParameter("card_cvc");
        if(!(card_number.length() <= 0 && card_expiry.length() <= 0 && card_cvc.length() <= 0)){
            if(emailValidator(email)){
                    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                    Query q = new Query("CABIDZ_USER")
                            .setFilter(Query.CompositeFilterOperator.and(new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email),new Query.FilterPredicate("email", Query.FilterOperator.EQUAL, email) ));
                    List<Entity> user_data = datastore.prepare(q.clearKeysOnly()).asList(FetchOptions.Builder.withDefaults());
                    if(user_data.size() >0){
                        Transaction txn = datastore.beginTransaction();
                        try {
                            Key employeeKey = KeyFactory.createKey("CABIDZ_USER", email);
                            Entity employee = new Entity(employeeKey);
                            employee.setProperty("first_name", user_data.get(0).getProperty("first_name"));
                            employee.setProperty("last_name", user_data.get(0).getProperty("last_name"));
                            employee.setProperty("phone_number", user_data.get(0).getProperty("phone_number"));
                            employee.setProperty("email", email);
                            employee.setProperty("password", user_data.get(0).getProperty("password"));
                            employee.setProperty("card_expiry", card_expiry);
                            employee.setProperty("postal_code", user_data.get(0).getProperty("postal_code"));
                            employee.setProperty("img_id", user_data.get(0).getProperty("img_id"));
                            datastore.put(employee);
                            txn.commit();
                        } finally {
                            if (txn.isActive()) {
                                txn.rollback();
                            }
                            successJSON = "{\"status\": \"true\",\"message\": \"Record has been updated successfully!!\",\"user_email\": \" "+email + "\"}";
                        }
                    }else {
                        successJSON = "{\"status\":\"false\",\"message\":\"" + "Email address not exist!!" + "\"}";
                    }

            }else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        }else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
