package com.leadstech.cabidzuser.ServletEndrpointAPI.driverAPIS;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Transaction;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class UpdateDecumentEndPointAPI extends HttpServlet {
    private String  email ,driver_license_expiry, driver_license_doc_ID, driver_license_status, RMS_driver_history,
            RMS_doc_ID, RMS_doc_status, driver_authority_card, driver_authority_card_doc_ID, driver_authority_card_status,
            driver_proof_ID, driver_proof_doc_ID, driver_proof_doc_status, driver_license_backdoc_ID, driver_license_back_doc_Status;
    private static final String JSON_CONTENT_TYPE = "application/json; charset=UTF-8";
    private String successJSON = "";
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        email = req.getParameter("email");
        driver_license_expiry = req.getParameter("driver_license_expiry");
        driver_license_doc_ID = req.getParameter("driver_license_doc_ID");
        driver_license_status = req.getParameter("driver_license_status");

        RMS_driver_history = req.getParameter("RMS_driver_history");
        RMS_doc_ID = req.getParameter("RMS_doc_ID");
        RMS_doc_status = req.getParameter("RMS_doc_status");

        driver_authority_card = req.getParameter("driver_authority_card");
        driver_authority_card_doc_ID = req.getParameter("driver_authority_card_doc_ID");
        driver_authority_card_status = req.getParameter("driver_authority_card_status");

        driver_proof_ID = req.getParameter("driver_proof_ID");
        driver_proof_doc_ID = req.getParameter("driver_proof_doc_ID");
        driver_proof_doc_status = req.getParameter("driver_proof_doc_status");

        driver_license_backdoc_ID = req.getParameter("driver_license_backdoc_ID");
        driver_license_back_doc_Status = req.getParameter("driver_license_back_doc_Status");

        if (!(email.length() <= 0 &&
                driver_license_expiry.length() <= 0 &&
                driver_license_doc_ID.length() <= 0 &&
                driver_license_status.length() <= 0 &&
                RMS_driver_history.length() <= 0 &&
                RMS_doc_ID.length() <= 0 &&
                RMS_doc_status.length() <= 0 &&
                driver_authority_card.length() <= 0 &&
                driver_authority_card_doc_ID.length() <= 0 &&
                driver_authority_card_status.length() <= 0 &&
                driver_proof_ID.length() <= 0 &&
                driver_proof_doc_ID.length() <= 0 &&
                driver_proof_doc_status.length() <= 0 &&
                driver_license_backdoc_ID.length() <= 0 &&
                driver_license_back_doc_Status.length() <= 0)) {
            if (emailValidator(email)) {
                DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
                 UploadDocumentData(datastore);
            } else {
                successJSON = "{\"status\":\"false\",\"message\":\"" + "email is not correct!!" + "\"}";
            }
        } else {
            successJSON = "{\"status\":\"false\",\"message\":\"" + "some parameters are missing!!" + "\"}";
        }
        resp.setContentType(JSON_CONTENT_TYPE);
        resp.getWriter().println(successJSON);
    }

    private boolean emailValidator(String email) {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private void UploadDocumentData(DatastoreService datastore) {
        Transaction txn = datastore.beginTransaction();
        try {
            Key employeeKey = KeyFactory.createKey("CABIDZ_DRIVER_DOCUMENT_DETAILS", email);
            Entity employee = new Entity(employeeKey);
            employee.setProperty("driverID", email);
            employee.setProperty("driver_license_expiry", driver_license_expiry);
            employee.setProperty("driver_license_doc_ID", driver_license_doc_ID);
            employee.setProperty("driver_license_status", driver_license_status);
            employee.setProperty("RMS_driver_history", RMS_driver_history);
            employee.setProperty("RMS_doc_ID", RMS_doc_ID);
            employee.setProperty("RMS_doc_status", RMS_doc_status);
            employee.setProperty("driver_authority_card", driver_authority_card);
            employee.setProperty("driver_authority_card_doc_ID", driver_authority_card_doc_ID);
            employee.setProperty("driver_authority_card_status", driver_authority_card_status);
            employee.setProperty("driver_proof_ID", driver_proof_ID);
            employee.setProperty("driver_proof_doc_ID", driver_proof_doc_ID);
            employee.setProperty("driver_proof_doc_status", driver_proof_doc_status);
            employee.setProperty("driver_license_backdoc_ID", driver_license_backdoc_ID);
            employee.setProperty("driver_license_back_doc_Status", driver_license_back_doc_Status);
            datastore.put(employee);
            txn.commit();
        }catch (Exception e){
            successJSON = "{\"status\":\"false\",\"message\":\"" + "error occourr!!" + "\"}";
        }finally {
            if (txn.isActive()) {
                txn.rollback();
            }
            successJSON = "{\"status\":\"true\",\"message\":\"" + "Record has been updated successfully!!" + "\"}";
        }
    }
}
