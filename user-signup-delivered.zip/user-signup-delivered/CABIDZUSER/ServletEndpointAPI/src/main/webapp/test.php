
<!DOCTYPE html>
<html>
<head>
    <title>Hello, App Engine!</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet"
          href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css">
</head>
<body role="document" style="padding-top: 70px;">

<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
                <li><a href="">Cabidz User</a></li>
            </ul>
        </div>
    </div>
</div>

<div class="container theme-showcase" role="main">
    <div class="jumbotron">
        <div class="row">
            <div class="col-lg-12">
                <h1>Forgot Password!</h1>
                <p>Enter your password and confirm password to reset <code>Password</code>.</p>

                <form action="/User/ResetPasswordAPI" method="POST">
                    <div class="form-group">
                        <label for="email">Register Email:</label>
                        <input type="email" name="email" class="input-lg form-control" id="email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" name="password" class="input-lg form-control" id="password">
                    </div>
                    <div class="form-group">
                        <label for="confirmpassword">Confirm Password:</label>
                        <input type="password" class="input-lg form-control" id="confirmpassword">
                    </div>
                    <button type="submit" class="btn btn-default">Reset Now</button>
                </form>
                <br/>
            </div>
        </div>
    </div>
</div>

</body>
</html>
