package com.leadstech.cabidz.model;

/**
 * Created by jawadali on 5/5/17.
 */

public class Response {
    public String response_data;
    public String status;
    public String error;
    public String returnType;
    public String token;
    public String img_data;
    public String message;
    public String Id;
}
