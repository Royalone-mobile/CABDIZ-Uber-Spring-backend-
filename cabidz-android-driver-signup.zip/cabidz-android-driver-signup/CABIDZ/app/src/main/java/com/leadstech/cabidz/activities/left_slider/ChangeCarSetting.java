package com.leadstech.cabidz.activities.left_slider;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.actionsheet.ActionSheet;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.signup.Signup_StepOne;
import com.leadstech.cabidz.activities.signup.Signup_final_step;
import com.leadstech.cabidz.activities.signup.Signup_fourth_step;
import com.leadstech.cabidz.cloud_apis.MakeAPICall;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.URLs;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import static com.leadstech.cabidz.activities.Login.login_parm;
import static com.leadstech.cabidz.activities.signup.Signup_StepOne.parm;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class ChangeCarSetting extends AppCompatActivity implements APIResponseListner ,ActionSheet.ActionSheetListener{
    ImageView BACK;
    Button UPDATE;
    EditText NumberPate, TexiCompany , Additonal_1 , Additonal_2;
    String Car = "" , carCategory = "";
    Spinner CAR,Category;
    TextView Car_Name ,Car_plate;
    ImageView CAR_IMG;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_car_setting);
        CAR = (Spinner) findViewById(R.id.select_car);
        Category = (Spinner) findViewById(R.id.category);
        Car_Name = (TextView) findViewById(R.id.car_name);
        Car_plate = (TextView) findViewById(R.id.car_plate);
        CAR_IMG = (ImageView) findViewById(R.id.car_image);
        NumberPate = (EditText) findViewById(R.id.number_plate);
        TexiCompany = (EditText) findViewById(R.id.texi_compny);
        Additonal_1 = (EditText) findViewById(R.id.additonal);
        Additonal_2 = (EditText) findViewById(R.id.additional_second);

        if(!SharedPrefrences.getString("car_img", ChangeCarSetting.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("car_img" , ChangeCarSetting.this)));
            roundDrawable.setCircular(true);
            CAR_IMG.setImageDrawable(roundDrawable);
        }

        SetData();
        CAR.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(i>0){
                    Car = adapterView.getItemAtPosition(i).toString();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Car = "Honda City";
            }
        });

        Category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                carCategory = adapterView.getItemAtPosition(i).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                carCategory = "Texi";
            }
        });
        UPDATE = (Button) findViewById(R.id.update);
        UPDATE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Car.length() > 0 && carCategory.length() > 0
                        && NumberPate.getText().length() > 0
                        && TexiCompany.getText().length() > 0){
                    if(Additonal_1.getText().length() > 0){
                        login_parm.put("additional_information" , Additonal_1.getText().toString() +" " + Additonal_2.getText().toString());
                    }else {
                        login_parm.put("additional_information" , "null");
                    }
                    login_parm.put("vehicle" , Car);
                    login_parm.put("category" , carCategory);
                    login_parm.put("number_plate" , NumberPate.getText().toString());
                    login_parm.put("texi_company" , TexiCompany.getText().toString());
                    new MakeAPICall(ChangeCarSetting.this, login_parm, PostMethod, URLs.UpdateUserCar, APIActions.ApiActions.document_update, ChangeCarSetting.this).execute();
                }else {
                    Toast.makeText(getApplicationContext(),"required fields are empty" , Toast.LENGTH_LONG).show();
                }

            }
        });
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        CAR_IMG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActionSheet.createBuilder(ChangeCarSetting.this, getSupportFragmentManager())
                        .setCancelButtonTitle("Cancel")
                        .setOtherButtonTitles("Camera", "Gallery")
                        .setCancelableOnTouchOutside(true)
                        .setListener(ChangeCarSetting.this).show();
            }
        });
    }

    @Override
    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {
    }

    @Override
    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
        if (index == 0) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, 9);
        } else {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(i, 1);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = new String[]{MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            SharedPrefrences.SetString("car_img", picturePath, getApplicationContext());
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(picturePath));
            roundDrawable.setCircular(true);
            CAR_IMG.setImageDrawable(roundDrawable);
        } else if (requestCode == 9 && resultCode == RESULT_OK && data != null) {
            onCaptureImageResult(data);
        }
    }
    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        SharedPrefrences.SetString("car_img", destination.getAbsolutePath(), getApplicationContext());
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), thumbnail);
        roundDrawable.setCircular(true);
        CAR_IMG.setImageDrawable(roundDrawable);
    }
    public void  SetData(){
       Car = login_parm.get("vehicle");
       carCategory = login_parm.get("category");
       Additonal_1.setText(login_parm.get("additional_information"));
       NumberPate.setText(login_parm.get("number_plate"));
       TexiCompany.setText(login_parm.get("texi_company"));
       Car_Name.setText(login_parm.get("vehicle"));
       Car_plate.setText(login_parm.get("number_plate"));
   }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if (response.status != null) {
            if (response.status.equalsIgnoreCase("true")) {
                Toast.makeText(getApplicationContext(), response.message ,Toast.LENGTH_LONG).show();
                finish();
            }else {
                Toast.makeText(getApplicationContext(), response.message ,Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {
        Toast.makeText(getApplicationContext(), "Error occurs,please try it again later!!" ,Toast.LENGTH_LONG).show();
    }
}
