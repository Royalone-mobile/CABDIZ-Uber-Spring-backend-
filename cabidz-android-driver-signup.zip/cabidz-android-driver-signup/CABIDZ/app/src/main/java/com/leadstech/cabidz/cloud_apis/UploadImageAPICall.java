package com.leadstech.cabidz.cloud_apis;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Pair;

import com.google.gson.Gson;
import com.leadstech.cabidz.model.LoginResponse;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class UploadImageAPICall extends AsyncTask<Pair<Context, String>, Void, Response> {
    private Context context;
    private Map<String, String> nameValuePairs;
    private String Method;
    private String URL;
    private APIActions.ApiActions serviceAction;
    private APIResponseListner apiResponseListner;

    public UploadImageAPICall(Context context, Map<String, String> pairameters, String method, String url , APIActions.ApiActions service_action, APIResponseListner apiResponseListner ) {
        this.nameValuePairs = pairameters;
        this.Method = method;
        this.URL = url;
        this.context = context;
        this.apiResponseListner =  apiResponseListner;
        this.serviceAction = service_action;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Response doInBackground(Pair<Context, String>... params) {
        try {
            // Set up the request
            java.net.URL url = new URL(this.URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(this.Method);
//            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            // Build nam data request params
            String postParams = buildPostDataString(this.nameValuePairs);
            // Execute HTTP Post
            OutputStream outputStream = connection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            writer.write(postParams);
            writer.flush();
            writer.close();
            outputStream.close();
            connection.connect();
            // Read response
            int responseCode = connection.getResponseCode();
            StringBuilder response = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            if (responseCode == HttpsURLConnection.HTTP_OK) {
                Response resp =  genrateResponse(response.toString(),serviceAction);
//                resp.response_data = response.toString();
                return resp;
            }
            Gson mGson = new Gson();
            Response resp = mGson.fromJson(response.toString(), Response.class );
            resp.response_data = response.toString();
            return resp;

        } catch (IOException e) {
            Response resp = new Response();
            resp.error = e.getMessage();
            resp.status = "failed";
            return resp;
        }
    }

    private String buildPostDataString(Map<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first) {
                first = false;
            } else {
                result.append("&");
            }
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        return result.toString();
    }
    @Override
    protected void onPostExecute(Response result) {
        if (apiResponseListner != null && result != null) {
            apiResponseListner.onRequestSuccess(result, serviceAction);
        } else if (apiResponseListner != null) {
            apiResponseListner.onRequestError(result, serviceAction);
        }
    }
    private Response genrateResponse(String response, APIActions.ApiActions actions){
        Gson mGson = new Gson();
        switch (actions){
            case upload_img:
                return  mGson.fromJson(response, LoginResponse.class );
            default:
                return mGson.fromJson(response, Response.class );
        }
    }
}