package com.leadstech.cabidz.activities.past_trip;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import com.leadstech.cabidz.R;

import java.util.ArrayList;

public class PastTrips extends AppCompatActivity {
    ListView list;
    ImageView BACK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_past_trips);
        list = (ListView) findViewById(R.id.list_view);
        list.setAdapter(new PastTripAdapter(PastTrips.this,new ArrayList<String>()));

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
