package com.leadstech.cabidz.singleton;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.kaopiz.kprogresshud.KProgressHUD;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.content.Context.INPUT_METHOD_SERVICE;
public class StaticFunctios {
    public static String GetMethod = "GET";
    public static String PostMethod = "POST";
    public  static KProgressHUD pd;
    public static  void HideKeyboard(Context context, EditText editText){
        InputMethodManager imm = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);

    }
    public static void hideKeyboard(Activity activity) {
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View v = window.getCurrentFocus();
                if (v != null) {
                    InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm!=null){
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    }
                }
            }
        }
    }

    public static ArrayList<String> getHelpTitles(){
        ArrayList<String> str = new ArrayList<>();
        str.add("Trip and fare eview");
        str.add("Account and Payment Options");
        str.add("A Guide");
        str.add("Signing Up");
        str.add("More");
        str.add("Accessibility");
        return str;
    }

    public static ArrayList<String> getHelpSubTitlesTitles(){
        ArrayList<String> str = new ArrayList<>();
        str.add("I Was involve in an accident");
        str.add("I lost an item");
        str.add("I would like a refund");
        str.add("My driver was unprofessional");
        str.add("I can't request a ride");
        str.add("I have a different issue");
        return str;
    }

    public static void ShowProgress(Activity activity) {
        pd = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setCancellable(false).setAnimationSpeed(1).setDimAmount(0.5F).setWindowColor(Color.parseColor("#3EC79C")).show();
    }
    public static void HideProgress() {
        if (pd.isShowing()) {
            pd.dismiss();
        }
    }
    public static boolean emailValidator(String email)
    {
        Pattern pattern;
        Matcher matcher;
        final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
