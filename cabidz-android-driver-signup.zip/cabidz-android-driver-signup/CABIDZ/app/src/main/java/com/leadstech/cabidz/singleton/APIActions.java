package com.leadstech.cabidz.singleton;

/**
 * Created by jawadali on 5/5/17.
 */

public class APIActions {
    public static enum ApiActions{
        retrive_img,upload_img,place,document_update,log_in,signup,porgot_password,send_email,email_verfication,credit_card_verfication
    };
}
