package com.leadstech.cabidz.activities.incoming_job;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.leadstech.cabidz.R;
import com.pascalwelsch.holocircularprogressbar.HoloCircularProgressBar;

import static com.leadstech.cabidz.singleton.IntentGO.GOTO;

public class IncommingJob extends AppCompatActivity {
    Button Accept, Rejct;
    private HoloCircularProgressBar mHoloCircularProgressBar;
    private ObjectAnimator mProgressBarAnimator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incomming_job);
        mHoloCircularProgressBar = (HoloCircularProgressBar) findViewById(R.id.holoCircularProgressBar);
        if (mProgressBarAnimator != null) {
            mProgressBarAnimator.cancel();
        }
        mHoloCircularProgressBar.setProgressBackgroundColor(Color.parseColor("#00000000"));
        mHoloCircularProgressBar.setProgressColor(R.color.home_screen);
        animate(mHoloCircularProgressBar, null, 0f, 16000);
        mHoloCircularProgressBar.setMarkerProgress(1f);


        Accept  = (Button) findViewById(R.id.accept);
        Accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GOTO(IncommingJob.this, AcceptIncomingJob.class);
                finish();
            }
        });
        Rejct = (Button) findViewById(R.id.reject);
        Rejct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void animate(final HoloCircularProgressBar progressBar, final Animator.AnimatorListener listener,
                         final float progress, final int duration) {
        mProgressBarAnimator = ObjectAnimator.ofFloat(progressBar, "progress", progress);
        mProgressBarAnimator.setDuration(duration);

        mProgressBarAnimator.addListener(new Animator.AnimatorListener() {

            @Override
            public void onAnimationCancel(final Animator animation) {
            }

            @Override
            public void onAnimationEnd(final Animator animation) {
                progressBar.setProgress(progress);
                finish();
            }

            @Override
            public void onAnimationRepeat(final Animator animation) {
            }

            @Override
            public void onAnimationStart(final Animator animation) {
            }
        });
        if (listener != null) {
            mProgressBarAnimator.addListener(listener);
        }
        mProgressBarAnimator.reverse();
        mProgressBarAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

            @Override
            public void onAnimationUpdate(final ValueAnimator animation) {
            }
        });
        progressBar.setMarkerProgress(progress);
        mProgressBarAnimator.start();
    }
}
