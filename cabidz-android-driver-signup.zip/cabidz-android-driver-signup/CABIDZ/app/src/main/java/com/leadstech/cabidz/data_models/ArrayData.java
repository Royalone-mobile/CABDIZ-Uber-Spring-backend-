package com.leadstech.cabidz.data_models;

import com.leadstech.cabidz.R;

import java.util.ArrayList;

/**
 * Created by dany on 04/04/2017.
 */

public class ArrayData {

    public static ArrayList<UserAccountListData> getUserAccountList(){
       ArrayList<UserAccountListData> useraccount_datalist = new ArrayList<>();
        useraccount_datalist.add(new UserAccountListData("Past Trips", R.mipmap.past_trip));
        useraccount_datalist.add(new UserAccountListData("Upcoming Trips", R.mipmap.upcomming_trip));
        useraccount_datalist.add(new UserAccountListData("Documents", R.mipmap.doc));
        useraccount_datalist.add(new UserAccountListData("Help", R.mipmap.help));
        useraccount_datalist.add(new UserAccountListData("Settings", R.mipmap.setting));
        useraccount_datalist.add(new UserAccountListData("Find Jobs", R.mipmap.find));
        useraccount_datalist.add(new UserAccountListData("Announcement", R.mipmap.announce));
        return useraccount_datalist;
    }

}
