package com.leadstech.cabidz.model;

import java.util.List;

/**
 * Created by jawadali on 5/12/17.
 */

public class PlaceResponse extends Response{
    private List<Places> results;

    public List<Places> getResults() {
        return results;
    }

    public void setResults(List<Places> results) {
        this.results = results;
    }
}
