package com.leadstech.cabidz.activities.signup;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.home.Home;
import com.leadstech.cabidz.singleton.SharedPrefrences;

import static com.leadstech.cabidz.activities.signup.Signup_StepOne.parm;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class Signup_fourth_step extends AppCompatActivity {
    Button NEXT;
    ImageView BACK;
    EditText  NumberPate, TexiCompany , Additonal_1 , Additonal_2;
    String Car = "" , carCategory = "";
    Spinner CAR,Category;
    ImageView Profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_fourth_step);
        CAR = (Spinner) findViewById(R.id.select_car);
        Category = (Spinner) findViewById(R.id.category);
        NumberPate = (EditText) findViewById(R.id.number_plate);
        TexiCompany = (EditText) findViewById(R.id.texi_compny);
        Additonal_1 = (EditText) findViewById(R.id.additonal);
        Additonal_2 = (EditText) findViewById(R.id.additional_second);

        Profile = (ImageView) findViewById(R.id.profile_img);
         getDefaultImg();

        CAR.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(i>0){
                    Car = adapterView.getItemAtPosition(i).toString();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Car = "Honda City";
            }
        });

        Category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    carCategory = adapterView.getItemAtPosition(i).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                carCategory = "Texi";
            }
        });

        NEXT = (Button) findViewById(R.id.next);
        NEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Car.length() > 0 && carCategory.length() > 0
                        && NumberPate.getText().length() > 0
                        && TexiCompany.getText().length() > 0){

                    if(Additonal_1.getText().length() > 0){
                        parm.put("additional_information" , Additonal_1.getText().toString() +" " + Additonal_2.getText().toString());
                    }else {
                        parm.put("additional_information" , "null");
                    }
                    parm.put("vehicle" , Car);
                    parm.put("category" , carCategory);
                    parm.put("number_plate" , NumberPate.getText().toString());
                    parm.put("texi_company" , TexiCompany.getText().toString());
                    GOTO(Signup_fourth_step.this,Signup_final_step.class);
                }else {
                    Toast.makeText(getApplicationContext(),"required fields are empty" , Toast.LENGTH_LONG).show();
                }

            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideKeyboard(Signup_fourth_step.this);
            }
        }, 200);

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", Signup_fourth_step.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", Signup_fourth_step.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if(decodedByte != null){
                SharedPrefrences.SetString("profile_pic_base64", SharedPrefrences.getString("profile_pic_base64", Signup_fourth_step.this), getApplicationContext());
                RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                roundDrawable.setCircular(true);
                Profile.setImageDrawable(roundDrawable);
                Log.d("image", SharedPrefrences.getString("profile_pic_base64", Signup_fourth_step.this));
            }
        }else if(!SharedPrefrences.getString("profile_pic", Signup_fourth_step.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , Signup_fourth_step.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
    }
}
