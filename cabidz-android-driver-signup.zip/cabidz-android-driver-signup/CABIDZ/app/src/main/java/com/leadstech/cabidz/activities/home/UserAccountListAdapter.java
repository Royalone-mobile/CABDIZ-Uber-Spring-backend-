package com.leadstech.cabidz.activities.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.data_models.UserAccountListData;

import java.util.ArrayList;


public class UserAccountListAdapter extends BaseAdapter {
   Context context;
    LayoutInflater inflater;
    ArrayList<UserAccountListData> data = new ArrayList<>();
     UserAccountListAdapter(Context context, ArrayList<UserAccountListData> list){
         this.context =  context;
         this.data= list;
        inflater = (LayoutInflater) context
                 .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
     }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
        if(convertView == null){
             rowView = inflater.inflate(R.layout.user_account_list_item, parent, false);
            final TextView title = (TextView) rowView.findViewById(R.id.title);
            final ImageView img = (ImageView) rowView.findViewById(R.id.img);
            title.setText(data.get(position).getTitle());
            img.setImageResource(data.get(position).getPic());
        }else {
            rowView = convertView;
        }
        return rowView;
    }
}
