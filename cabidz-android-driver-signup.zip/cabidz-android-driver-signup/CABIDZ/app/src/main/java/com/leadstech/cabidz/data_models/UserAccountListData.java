package com.leadstech.cabidz.data_models;

/**
 * Created by dany on 04/04/2017.
 */

public class UserAccountListData {
    String Title;
    int Pic;
    UserAccountListData(String title, int pic){
        this.Title = title;
        this.Pic = pic;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public int getPic() {
        return Pic;
    }

    public void setPic(int pic) {
        Pic = pic;
    }
}
