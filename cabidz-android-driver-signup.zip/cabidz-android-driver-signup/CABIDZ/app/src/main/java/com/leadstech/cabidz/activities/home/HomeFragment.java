package com.leadstech.cabidz.activities.home;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Point;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.Projection;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.custom_objects.JSONParse;
import com.leadstech.cabidz.singleton.SharedPrefrences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements OnMapReadyCallback, LocationListener,RoutingListener {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private GoogleMap mMap;
    private String mParam1;
    private String mParam2;
    LatLng CurrentPosition;
    private LocationManager locationManager = null;
    Marker marker_car = null;
    public HomeFragment() {
        // Required empty public constructor
    }
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        SupportMapFragment mGoogleMap = ((SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map));
        mGoogleMap.getMapAsync(this);
        final RelativeLayout dialog = (RelativeLayout) view.findViewById(R.id.dialog);
        final RelativeLayout dialog_menue = (RelativeLayout) view.findViewById(R.id.dialog_menue);
        final RelativeLayout dialog_Main = (RelativeLayout) view.findViewById(R.id.dialog_main);
        final Switch is_online = (Switch) view.findViewById(R.id.online_switch);
        final TextView title = (TextView) view.findViewById(R.id.title);
        final ImageView Cross_btn = (ImageView) view.findViewById(R.id.cross);
        final ImageView MENU = (ImageView) view.findViewById(R.id.menue);

        MENU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Home.drawerLayout.openDrawer(Gravity.START);
            }
        });
        if(SharedPrefrences.getBool("is_active_first_time",getContext())){
            dialog.setVisibility(View.GONE);
            dialog_menue.setVisibility(View.GONE);
            dialog_Main.setVisibility(View.VISIBLE);
        }else {
            dialog.setVisibility(View.VISIBLE);
            dialog_menue.setVisibility(View.VISIBLE);
            dialog_Main.setVisibility(View.GONE);
        }
        Cross_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 getActivity().finish();
            }
        });
        final Button SAVE = (Button) view.findViewById(R.id.save);
        SAVE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPrefrences.SetBool("is_active_first_time",true,getContext());
               dialog.setVisibility(View.GONE);
                dialog_menue.setVisibility(View.GONE);
                dialog_Main.setVisibility(View.VISIBLE);
            }
        });
        is_online.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    title.setText("Online");
                }else {
                    title.setText("Offline");
                }
            }
        });
        return view;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
//        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,10, 1000, this);
    }
    @Override
    public void onLocationChanged(Location location) {
        if(CurrentPosition == null ){
            CurrentPosition = new LatLng(location.getLatitude(),location.getLongitude());
            MarkerOptions marker = new MarkerOptions()
                    .position(CurrentPosition)
                    .title("Current Location")
                    .flat(true)
                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.map_car_small));
            marker_car =  mMap.addMarker(marker);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(CurrentPosition, 15);
            mMap.animateCamera(cameraUpdate);
            new connectAsyncTask(makeURL(location.getLatitude()+0.01823,location.getLongitude()+0.0073,location.getLatitude(),location.getLongitude())).execute();
        }else {
            CurrentPosition = new LatLng(location.getLatitude(),location.getLongitude());
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(CurrentPosition, 12);
            mMap.animateCamera(cameraUpdate);
            animateMarker(0,new LatLng(location.getLatitude(),location.getLongitude()),false,marker_car);
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
    public void rotateMarker(final Marker marker, final double toRotation, final double st) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final float startRotation = (float) st;
        final long duration = 10;
        float new_f_angle = (float) toRotation;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed / duration);
                float rot = t * (float)toRotation + (1 - t) * startRotation;
                marker.setRotation(-rot > 180 ? rot / 2 : rot);
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                }
            }
        });
    }
    public void animateMarker(final int x, final LatLng positn , final boolean hideMarke , final Marker m) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = mMap.getProjection();
        Point startPoint = proj.toScreenLocation(m.getPosition());
        final LatLng startLatLng = proj.fromScreenLocation(startPoint);
        final long duration = 600000;
        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * positn.longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * positn.latitude + (1 - t)
                        * startLatLng.latitude;
                m.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                } else {
                    if (hideMarke) {
                        m.setVisible(false);
                    } else {
                        m.setVisible(true);
                    }
                }
            }
        });
    }

    public void animateMarker(final int x, final List<LatLng> list, final boolean hideMarke , final Marker m, final double previous_engle) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = mMap.getProjection();
        Point startPoint = proj.toScreenLocation(m.getPosition());
        final LatLng startLatLng = proj.fromScreenLocation(startPoint);
        final long duration = 1000;
        final Interpolator interpolator = new LinearInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * list.get(x).longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * list.get(x).latitude + (1 - t)
                        * startLatLng.latitude;
                m.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                } else {
                    if (hideMarke) {
                        m.setVisible(false);
                    } else {
                        m.setVisible(true);
                        if(x<list.size()-1){
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if(GetBearing(list.get(x),list.get(x+1)) > 05){
                                        rotateMarker(m,GetBearing(list.get(x),list.get(x+1)),previous_engle);
                                    }
                                    animateMarker(x+1,list,false,m,GetBearing(list.get(x),list.get(x+1)));
                                }
                            }, 100);
                        }

                    }
                }
            }
        });
    }


    @Override
    public void onRoutingFailure() {
    }
    @Override
    public void onRoutingStart() {

    }
    @Override
    public void onRoutingSuccess(final PolylineOptions polylineOptions, Route route) {
        PolylineOptions polyoptions = new PolylineOptions();
        polyoptions.color(Color.parseColor("#F2A24D"));
        polyoptions.width(12);
        polyoptions.addAll(polylineOptions.getPoints());
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                rotateMarker(marker_car,180,0);
                animateMarker(0,polylineOptions.getPoints(),false,marker_car ,0);
            }
        },1000);
        mMap.addPolyline(polyoptions);
    }
    @Override
    public void onRoutingCancelled() {

    }

    //Draw Path

    private class connectAsyncTask extends AsyncTask<Void, Void, String> {

        String url;

        connectAsyncTask(String urlPass) {
            url = urlPass;
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            JSONParse jParser = new JSONParse();
            String json = jParser.getJSONFromUrl(url);
            return json;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null) {
                drawPath(result);
            }
        }
    }

    public void drawPath(String result) {
        try {
            final JSONObject json = new JSONObject(result);
            JSONArray routeArray = json.getJSONArray("routes");
            JSONObject routes = routeArray.getJSONObject(0);
            JSONObject overviewPolylines = routes.getJSONObject("overview_polyline");
            String encodedString = overviewPolylines.getString("points");
            final List<LatLng> list_lat = decodePoly(encodedString);
            Routing routing = new Routing.Builder()
                    .avoid(AbstractRouting.AvoidKind.FERRIES)
                    .travelMode(Routing.TravelMode.DRIVING)
                    .withListener(this)
                    .waypoints(list_lat.get(list_lat.size() - 1), list_lat.get(0))
                    .build();
            routing.execute();
            mMap.addMarker(new MarkerOptions()
                    .position(list_lat.get(0))
                    .title("")
                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.destination_pin)));
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(list_lat.get(list_lat.size() - 1), 15);
            mMap.animateCamera(cameraUpdate);
        } catch (JSONException e) {
        }
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }
        return poly;
    }

    public String makeURL(double sourcelat, double sourcelog, double destlat, double destlog) {
        StringBuilder urlString = new StringBuilder();
        urlString.append("http://maps.googleapis.com/maps/api/directions/json");
        urlString.append("?origin=");// from
        urlString.append(Double.toString(sourcelat));
        urlString.append(",");
        urlString.append(Double.toString(sourcelog));
        urlString.append("&destination=");// to
        urlString.append(Double.toString(destlat));
        urlString.append(",");
        urlString.append(Double.toString(destlog));
        urlString.append("&sensor=false&mode=driving&alternatives=true");
        return urlString.toString();
    }
    private double GetBearing(LatLng from, LatLng to) {
        double lat1 = from.latitude * Math.PI / 180.0;
        double lon1 = from.longitude * Math.PI / 180.0;
        double lat2 = to.latitude * Math.PI / 180.0;
        double lon2 = to.longitude * Math.PI / 180.0;

        // Compute the angle.
        double angle = -Math.atan2(Math.sin(lon1 - lon2) * Math.cos(lat2), Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(lon1 - lon2));

        if (angle < 0.0)
            angle += Math.PI * 2.0;

        // And convert result to degrees.
        angle = Math.toDegrees(angle);

        return angle;
    }
}
