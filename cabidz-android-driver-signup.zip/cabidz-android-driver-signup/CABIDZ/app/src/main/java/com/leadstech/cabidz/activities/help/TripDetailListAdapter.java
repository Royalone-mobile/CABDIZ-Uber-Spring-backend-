package com.leadstech.cabidz.activities.help;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.leadstech.cabidz.R;

import java.util.ArrayList;

/**
 * Created by jawadali on 4/13/17.
 */

public class TripDetailListAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    ArrayList<String> data = new ArrayList<>();
    TripDetailListAdapter(Context context, ArrayList<String> list){
        this.context =  context;
        this.data= list;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount()
    {
        return this.data.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
        if(convertView == null){
            rowView = inflater.inflate(R.layout.trip_detail_list_item, parent, false);
            final TextView title = (TextView) rowView.findViewById(R.id.list_title);
            title.setText(this.data.get(position));
        }else {
            rowView = convertView;
        }
        return rowView;
    }
}