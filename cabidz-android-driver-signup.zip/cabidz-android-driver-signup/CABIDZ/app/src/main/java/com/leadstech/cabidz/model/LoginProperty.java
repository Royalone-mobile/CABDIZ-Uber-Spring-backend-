package com.leadstech.cabidz.model;

public class LoginProperty {
    private String  first_name;
    private String  last_name;
    private String  phone_number;
    private String  email;
    private String  password;
    private String  address;
    private String  city;
    private String  state;
    private String  stripe_id;
    private String  postal_code;
    private String  image;
    private String  img_id;
    private String  driver_license_expiry;
    private String  driver_license_doc_ID;
    private String  driver_license_status;
    private String  RMS_driver_history;
    private String  RMS_doc_ID;
    private String  RMS_doc_status;
    private String  driver_authority_card;
    private String  driver_authority_card_doc_ID;
    private String  driver_authority_card_status;
    private String  driver_proof_ID;
    private String  driver_proof_doc_ID;
    private String  driver_proof_doc_status;
    private String  driver_license_back_doc_Status;
    private String  driver_license_backdoc_ID;
    private String  vehicle;
    private String  category;
    private String  texi_company;
    private String  additional_information;
    private String  device_token;
    private String  number_plate;

    public String getFirst_name() {
        return first_name;
    }

    public String getStripe_id() {
        return stripe_id;
    }

    public void setStripe_id(String stripe_id) {
        this.stripe_id = stripe_id;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getImg_id() {
        return img_id;
    }

    public void setImg_id(String img_id) {
        this.img_id = img_id;
    }

    public String getDriver_license_expiry() {
        return driver_license_expiry;
    }

    public void setDriver_license_expiry(String driver_license_expiry) {
        this.driver_license_expiry = driver_license_expiry;
    }

    public String getDriver_license_doc_ID() {
        return driver_license_doc_ID;
    }

    public void setDriver_license_doc_ID(String driver_license_doc_ID) {
        this.driver_license_doc_ID = driver_license_doc_ID;
    }

    public String getDriver_license_status() {
        return driver_license_status;
    }

    public void setDriver_license_status(String driver_license_status) {
        this.driver_license_status = driver_license_status;
    }

    public String getRMS_driver_history() {
        return RMS_driver_history;
    }

    public void setRMS_driver_history(String RMS_driver_history) {
        this.RMS_driver_history = RMS_driver_history;
    }

    public String getRMS_doc_ID() {
        return RMS_doc_ID;
    }

    public void setRMS_doc_ID(String RMS_doc_ID) {
        this.RMS_doc_ID = RMS_doc_ID;
    }

    public String getRMS_doc_status() {
        return RMS_doc_status;
    }

    public void setRMS_doc_status(String RMS_doc_status) {
        this.RMS_doc_status = RMS_doc_status;
    }

    public String getDriver_authority_card() {
        return driver_authority_card;
    }

    public void setDriver_authority_card(String driver_authority_card) {
        this.driver_authority_card = driver_authority_card;
    }

    public String getDriver_authority_card_doc_ID() {
        return driver_authority_card_doc_ID;
    }

    public void setDriver_authority_card_doc_ID(String driver_authority_card_doc_ID) {
        this.driver_authority_card_doc_ID = driver_authority_card_doc_ID;
    }

    public String getDriver_authority_card_status() {
        return driver_authority_card_status;
    }

    public void setDriver_authority_card_status(String driver_authority_card_status) {
        this.driver_authority_card_status = driver_authority_card_status;
    }

    public String getDriver_proof_ID() {
        return driver_proof_ID;
    }

    public void setDriver_proof_ID(String driver_proof_ID) {
        this.driver_proof_ID = driver_proof_ID;
    }

    public String getDriver_proof_doc_ID() {
        return driver_proof_doc_ID;
    }

    public void setDriver_proof_doc_ID(String driver_proof_doc_ID) {
        this.driver_proof_doc_ID = driver_proof_doc_ID;
    }

    public String getDriver_proof_doc_status() {
        return driver_proof_doc_status;
    }

    public void setDriver_proof_doc_status(String driver_proof_doc_status) {
        this.driver_proof_doc_status = driver_proof_doc_status;
    }

    public String getDriver_license_back_doc_Status() {
        return driver_license_back_doc_Status;
    }

    public void setDriver_license_back_doc_Status(String driver_license_back_doc_Status) {
        this.driver_license_back_doc_Status = driver_license_back_doc_Status;
    }

    public String getDriver_license_backdoc_ID() {
        return driver_license_backdoc_ID;
    }

    public void setDriver_license_backdoc_ID(String driver_license_backdoc_ID) {
        this.driver_license_backdoc_ID = driver_license_backdoc_ID;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getNumber_plate() {
        return number_plate;
    }

    public void setNumber_plate(String number_plate) {
        this.number_plate = number_plate;
    }

    public String getTexi_company() {
        return texi_company;
    }

    public void setTexi_company(String texi_company) {
        this.texi_company = texi_company;
    }

    public String getAdditional_information() {
        return additional_information;
    }

    public void setAdditional_information(String additional_information) {
        this.additional_information = additional_information;
    }

    public String getDevice_token() {
        return device_token;
    }

    public void setDevice_token(String device_token) {
        this.device_token = device_token;
    }

}
