package com.leadstech.cabidz.activities.find_new_job;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.data_models.UserAccountListData;

import java.util.ArrayList;

public class JobsDestinationListAdapter  extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    JobsDestinationListAdapter(Context context){
        this.context =  context;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return 10;
    }
    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
        if(convertView == null){
            rowView = inflater.inflate(R.layout.jobs_destination_list_item, parent, false);
            final LinearLayout now_layout = (LinearLayout) rowView.findViewById(R.id.now);
            if(position== 0){
                now_layout.setVisibility(View.VISIBLE);
            }
        }else {
            rowView = convertView;
        }
        return rowView;
    }
}
