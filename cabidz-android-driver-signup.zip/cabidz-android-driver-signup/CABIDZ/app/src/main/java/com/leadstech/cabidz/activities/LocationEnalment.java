package com.leadstech.cabidz.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.home.Home;

import static com.leadstech.cabidz.singleton.IntentGO.GOTO;

public class LocationEnalment extends AppCompatActivity {
    Button Location_btn, PickUp;
    final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 998;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_enalment);
        Location_btn = (Button) findViewById(R.id.location);
        PickUp = (Button) findViewById(R.id.pickup);
        Location_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GOTO(LocationEnalment.this, Home.class);
            }
        });
        PickUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GOTO(LocationEnalment.this, Home.class);
            }
        });
        SetPermissions();
    }
    public void SetPermissions(){
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(LocationEnalment.this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(LocationEnalment.this,
                    Manifest.permission.ACCESS_FINE_LOCATION) && ActivityCompat.shouldShowRequestPermissionRationale(LocationEnalment.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(LocationEnalment.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION , Manifest.permission.ACCESS_COARSE_LOCATION },
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
}
