package com.leadstech.cabidz.activities.help;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.singleton.StaticFunctios;

public class TripHelp extends AppCompatActivity {
    ListView list;
    LinearLayout LastTripLabel;
    ImageView BACK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_help);
        LastTripLabel = (LinearLayout) findViewById(R.id.last_trip);
            LastTripLabel.setVisibility(View.VISIBLE);
        list = (ListView) findViewById(R.id.list_view);
        list.setAdapter(new TripHelpAdapter(TripHelp.this, StaticFunctios.getHelpTitles()));

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent help = new Intent(TripHelp.this,TripHelpDetails.class);
                help.putExtra("title" , StaticFunctios.getHelpTitles().get(i));
                startActivity(help);
            }
        });

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
