package com.leadstech.cabidz.activities.signup;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.baoyz.actionsheet.ActionSheet;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.home.Home;
import com.leadstech.cabidz.cloud_apis.UploadImageAPICall;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.URLs;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static com.leadstech.cabidz.activities.signup.Signup_StepOne.BITMAP_RESIZER;
import static com.leadstech.cabidz.activities.signup.Signup_StepOne.parm;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class Signup_third_step extends AppCompatActivity implements ActionSheet.ActionSheetListener, APIResponseListner {
    Button NEXT;
    ImageView BACK;
    ImageView Profile;
    String upload_img_id = "";
    int idd = 1;
    boolean isLicense = false, isRMS = false, isAuthroidty = false, isProofID = false, isLicenseBack = false;
    EditText Driver_license, RMS, Authority_card, Proof_ID, License_Back;
    Button Upload_Driver_license, Upload_RMS, Upload_Authority_card, Upload_Proof_ID, Upload_License_Back;
    Button Pendding_Driver_license, Pendding_RMS, Pendding_Authority_card, Pendding_Proof_ID, Pendding_License_Back;
    Button Missing_Driver_license, Missing_RMS, Missing_Authority_card, Missing_Proof_ID, Missing_License_Back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_third_step);
        Init();
        Log.d("param", parm + "");
        NEXT = (Button) findViewById(R.id.next);
        NEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLicenseBack && isLicense && isProofID && isAuthroidty &&
                        Driver_license.getText().length() > 0 && Authority_card.getText().length() > 0
                        && Proof_ID.getText().length() > 0) {
                    parm.put("driver_license_expiry", Driver_license.getText().toString());
                    parm.put("driver_license_status", "Pending");
                    if (RMS.getText().length() > 0) {
                        parm.put("RMS_driver_history", RMS.getText().toString());
                    } else {
                        parm.put("RMS_driver_history", "null");
                    }
                    if(isRMS){
                        parm.put("RMS_doc_status", "Pending");
                    }else {
                        parm.put("RMS_doc_ID", "null");
                        parm.put("RMS_doc_status", "missing");
                    }

                    parm.put("driver_authority_card", Authority_card.getText().toString());
                    parm.put("driver_authority_card_status", "Pending");

                    parm.put("driver_proof_ID", Proof_ID.getText().toString());
                    parm.put("driver_proof_doc_status", "Pending");

                    parm.put("driver_license_back_doc_Status", "Pending");
                    GOTO(Signup_third_step.this, Signup_fourth_step.class);
                } else {
                    if (!isProofID) {
                        Missing_Proof_ID.setVisibility(View.VISIBLE);
                    }

                    if (!isLicense) {
                        Missing_Driver_license.setVisibility(View.VISIBLE);
                    }

                    if (!isRMS) {
                        Missing_RMS.setVisibility(View.VISIBLE);
                    }

                    if (!isAuthroidty) {
                        Missing_Authority_card.setVisibility(View.VISIBLE);
                    }

                    if (!isLicenseBack) {
                        Missing_License_Back.setVisibility(View.VISIBLE);
                    }

                    Toast.makeText(getApplicationContext(), "required fields are missing!!", Toast.LENGTH_LONG).show();
                }
            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideKeyboard(Signup_third_step.this);
            }
        }, 200);

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        Upload_Driver_license.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                parm.put("driver_license_doc_ID", String.format("%07d", random.nextInt(10000)));
                uploadFile(1 , parm.get("driver_license_doc_ID"));
            }
        });
        Upload_RMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                parm.put("RMS_doc_ID", String.format("%07d", random.nextInt(10000)));
                uploadFile(2 ,parm.get("RMS_doc_ID") );
            }
        });
        Upload_Authority_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                parm.put("driver_authority_card_doc_ID", String.format("%07d", random.nextInt(10000)));
                uploadFile(3 ,parm.get("driver_authority_card_doc_ID") );
            }
        });
        Upload_Proof_ID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                parm.put("driver_proof_doc_ID", String.format("%07d", random.nextInt(10000)));

                uploadFile(4,parm.get("driver_proof_doc_ID") );
            }
        });
        Upload_License_Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                parm.put("driver_license_backdoc_ID", String.format("%07d", random.nextInt(10000)));
                uploadFile(5,parm.get("driver_license_backdoc_ID") );
            }
        });
    }

    public void Init() {
        Driver_license = (EditText) findViewById(R.id.driver_licesnse);
        RMS = (EditText) findViewById(R.id.rms);
        Authority_card = (EditText) findViewById(R.id.driver_authority_card);
        Proof_ID = (EditText) findViewById(R.id.proof_id);
        License_Back = (EditText) findViewById(R.id.license_back);

        Upload_Driver_license = (Button) findViewById(R.id.upload_driver_license);
        Upload_RMS = (Button) findViewById(R.id.upload_rms);
        Upload_Authority_card = (Button) findViewById(R.id.upload_driver_authority_card);
        Upload_Proof_ID = (Button) findViewById(R.id.upload_proof_id);
        Upload_License_Back = (Button) findViewById(R.id.upload_driver_license_back);


        Pendding_Driver_license = (Button) findViewById(R.id.license_pendding);
        Pendding_Authority_card = (Button) findViewById(R.id.authority_card_pendding);
        Pendding_RMS = (Button) findViewById(R.id.rms_pendding);
        Pendding_Proof_ID = (Button) findViewById(R.id.proof_id_pendding);
        Pendding_License_Back = (Button) findViewById(R.id.driver_back_pendding);

        Missing_Driver_license = (Button) findViewById(R.id.license_missing);
        Missing_Authority_card = (Button) findViewById(R.id.authority_card_missing);
        Missing_RMS = (Button) findViewById(R.id.rms_missing);
        Missing_Proof_ID = (Button) findViewById(R.id.prrof_id_missing);
        Missing_License_Back = (Button) findViewById(R.id.driver_license_back_missing);

        Profile = (ImageView) findViewById(R.id.profile_img);
       getDefaultImg();
    }

    public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", Signup_third_step.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", Signup_third_step.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if(decodedByte != null){
                SharedPrefrences.SetString("profile_pic_base64", SharedPrefrences.getString("profile_pic_base64", Signup_third_step.this), getApplicationContext());
                RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                roundDrawable.setCircular(true);
                Profile.setImageDrawable(roundDrawable);
                Log.d("image", SharedPrefrences.getString("profile_pic_base64", Signup_third_step.this));
            }
        }else if(!SharedPrefrences.getString("profile_pic", Signup_third_step.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , Signup_third_step.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
    }
    public void uploadFile(int id , String img_id) {
        idd = id;
        upload_img_id = img_id;
        ActionSheet.createBuilder(this, getSupportFragmentManager())
                .setCancelButtonTitle("Cancel")
                .setOtherButtonTitles("Camera", "Gallery")
                .setCancelableOnTouchOutside(true)
                .setListener(this).show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && null != data) {
            isLicense = true;
            Pendding_Driver_license.setVisibility(View.VISIBLE);
            Missing_Driver_license.setVisibility(View.GONE);
            UploadGalleryImg(data);
        } else if (requestCode == 2 && resultCode == RESULT_OK && null != data) {
            isRMS = true;
            Pendding_RMS.setVisibility(View.VISIBLE);
            Missing_RMS.setVisibility(View.GONE);
            UploadGalleryImg(data);
        } else if (requestCode == 3 && resultCode == RESULT_OK && null != data) {
            isAuthroidty = true;
            Pendding_Authority_card.setVisibility(View.VISIBLE);
            Missing_Authority_card.setVisibility(View.GONE);
            UploadGalleryImg(data);
        } else if (requestCode == 4 && resultCode == RESULT_OK && null != data) {
            isProofID = true;
            Pendding_Proof_ID.setVisibility(View.VISIBLE);
            Missing_Proof_ID.setVisibility(View.GONE);
            UploadGalleryImg(data);
        } else if (requestCode == 5 && resultCode == RESULT_OK && null != data) {
            isLicenseBack = true;
            Pendding_License_Back.setVisibility(View.VISIBLE);
            Missing_License_Back.setVisibility(View.GONE);
            UploadGalleryImg(data);
        }else if (requestCode == 11 && resultCode == RESULT_OK && null != data) {
            isLicense = true;
            Pendding_Driver_license.setVisibility(View.VISIBLE);
            Missing_Driver_license.setVisibility(View.GONE);
            onCaptureImageResult(data);
        } else if (requestCode == 12 && resultCode == RESULT_OK && null != data) {
            isRMS = true;
            Pendding_RMS.setVisibility(View.VISIBLE);
            Missing_RMS.setVisibility(View.GONE);
            onCaptureImageResult(data);
        } else if (requestCode == 13 && resultCode == RESULT_OK && null != data) {
            isAuthroidty = true;
            Pendding_Authority_card.setVisibility(View.VISIBLE);
            Missing_Authority_card.setVisibility(View.GONE);
            onCaptureImageResult(data);
        } else if (requestCode == 14 && resultCode == RESULT_OK && null != data) {
            isProofID = true;
            Pendding_Proof_ID.setVisibility(View.VISIBLE);
            Missing_Proof_ID.setVisibility(View.GONE);
            onCaptureImageResult(data);
        } else if (requestCode == 15 && resultCode == RESULT_OK && null != data) {
            isLicenseBack = true;
            Pendding_License_Back.setVisibility(View.VISIBLE);
            Missing_License_Back.setVisibility(View.GONE);
            onCaptureImageResult(data);
        }

    }

    public void UploadGalleryImg( Intent data){
        String[] filePathColumn;
        Uri selectedImage;
        selectedImage = data.getData();
        filePathColumn = new String[]{MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String picturePath = cursor.getString(columnIndex);
        cursor.close();
        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(picturePath));
        roundDrawable.setCircular(true);
        Bitmap bitmapOrg = BitmapFactory.decodeFile(picturePath);
        Bitmap bitmap = BITMAP_RESIZER(bitmapOrg, 80, 80);
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 30, bao);
        byte[] ba = bao.toByteArray();
        String ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
        UploadImage(ba1 ,upload_img_id);
    }
    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), thumbnail);
        roundDrawable.setCircular(true);

        Bitmap bitmap = BITMAP_RESIZER(thumbnail, 80, 80);
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 30, bao);
        byte[] ba = bao.toByteArray();
        String ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
        UploadImage(ba1 , upload_img_id);

    }
    public void UploadImage(String base64 , String upload_img_id) {
        int length = base64.length()/30;
        String data_1 = base64.substring(0,length);
        String data_2 = base64.substring((length),(length*2));
        String data_3 = base64.substring((length*2),(length*3));
        String data_4 = base64.substring((length*3),(length*4));
        String data_5 = base64.substring((length*4),(length*5));

        String data_6 = base64.substring((length*5),(length*6));
        String data_7 = base64.substring((length*6),(length*7));
        String data_8 = base64.substring((length*7),(length*8));
        String data_9 = base64.substring((length*8),(length*9));
        String data_10 = base64.substring((length*9),(length*10));

        String data_11 = base64.substring((length*10),(length*11));
        String data_12 = base64.substring((length*11),(length*12));
        String data_13 = base64.substring((length*12),(length*13));
        String data_14 = base64.substring((length*13),(length*14));
        String data_15 = base64.substring((length*14),(length*15));

        String data_16 = base64.substring((length*15),(length*16));
        String data_17 = base64.substring((length*16),(length*17));
        String data_18 = base64.substring((length*17),(length*18));
        String data_19 = base64.substring((length*18),(length*19));
        String data_20 = base64.substring((length*19),(length*20));

        String data_21 = base64.substring((length*20),(length*21));
        String data_22 = base64.substring((length*21),(length*22));
        String data_23 = base64.substring((length*22),(length*23));
        String data_24 = base64.substring((length*23),(length*24));
        String data_25 = base64.substring((length*24),(length*25));

        String data_26 = base64.substring((length*25),(length*26));
        String data_27 = base64.substring((length*26),(length*27));
        String data_28 = base64.substring((length*27),(length*28));
        String data_29 = base64.substring((length*28),(length*29));
        String data_30 = base64.substring((length*29),base64.length()-1);

        Map<String, String> parm_img = new HashMap<>();
        parm_img.put("img_id" , upload_img_id);
        parm_img.put("data_1" , data_1);
        parm_img.put("data_2" , data_2);
        parm_img.put("data_3" , data_3);
        parm_img.put("data_4" , data_4);
        parm_img.put("data_5" , data_5);
        parm_img.put("data_6" , data_6);
        parm_img.put("data_7" , data_7);
        parm_img.put("data_8" , data_8);
        parm_img.put("data_9" , data_9);

        parm_img.put("data_10" , data_10);
        parm_img.put("data_11" , data_11);
        parm_img.put("data_12" , data_12);
        parm_img.put("data_13" , data_13);
        parm_img.put("data_14" , data_14);
        parm_img.put("data_15" , data_15);
        parm_img.put("data_16" , data_16);
        parm_img.put("data_17" , data_17);
        parm_img.put("data_18" , data_18);
        parm_img.put("data_19" , data_19);
        parm_img.put("data_20" , data_20);

        parm_img.put("data_21" , data_21);
        parm_img.put("data_22" , data_22);
        parm_img.put("data_23" , data_23);
        parm_img.put("data_24" , data_24);
        parm_img.put("data_25" , data_25);
        parm_img.put("data_26" , data_26);
        parm_img.put("data_27" , data_27);
        parm_img.put("data_28" , data_28);
        parm_img.put("data_29" , data_29);
        parm_img.put("data_30" , data_30);
        new UploadImageAPICall(Signup_third_step.this, parm_img, PostMethod, URLs.UploadImage, APIActions.ApiActions.upload_img, Signup_third_step.this).execute();
    }
    @Override
    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {
        actionSheet.dismiss();
    }

    @Override
    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
        if (index == 0) {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, idd+10);
        } else {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(i, idd);
        }
    }
    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        Log.d("response" , response.message +"t");
    }
    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }
}
