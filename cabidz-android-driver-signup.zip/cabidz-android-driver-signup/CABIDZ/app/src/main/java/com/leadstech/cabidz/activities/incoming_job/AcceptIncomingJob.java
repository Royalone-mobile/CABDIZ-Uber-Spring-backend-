package com.leadstech.cabidz.activities.incoming_job;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.find_new_job.KickBidding;
import com.leadstech.cabidz.activities.find_new_job.KickBiddingListAdapter;
import com.leadstech.cabidz.custom_objects.DrawRoute;
import com.leadstech.cabidz.custom_objects.JSONParse;
import com.leadstech.cabidz.singleton.StaticFunctios;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.HideKeyboard;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class AcceptIncomingJob extends AppCompatActivity  {
    ListView list;
    Button PlaceBid;
    EditText bid_amount;
    ImageView BACK;
    Button OK ;
    RelativeLayout Dialog;
    DrawRoute route;
    private GoogleMap mMap;
    private LocationManager locationManager = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accept_incoming_job);
        list = (ListView) findViewById(R.id.list);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        route = new DrawRoute(AcceptIncomingJob.this,mMap,mapFragment);
        route.CallDrawPathClass();
        Dialog = (RelativeLayout) findViewById(R.id.dialog);
        Dialog.setVisibility(View.GONE);

        list.setAdapter(new KickBiddingListAdapter(this));
        bid_amount = (EditText) findViewById(R.id.enter_amount);
        PlaceBid = (Button) findViewById(R.id.place_bid);
        PlaceBid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StaticFunctios.ShowProgress(AcceptIncomingJob.this);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Dialog.setVisibility(View.VISIBLE);
                        StaticFunctios.HideProgress();
                    }
                }, 5000);
            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                PlaceBid.findFocus();
                PlaceBid.clearFocus();
                hideKeyboard(AcceptIncomingJob.this);
            }
        }, 200);

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        OK = (Button) findViewById(R.id.ok);
        OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GOTO(AcceptIncomingJob.this, StartTrip.class);
                Dialog.setVisibility(View.GONE);
            }
        });
    }
}


