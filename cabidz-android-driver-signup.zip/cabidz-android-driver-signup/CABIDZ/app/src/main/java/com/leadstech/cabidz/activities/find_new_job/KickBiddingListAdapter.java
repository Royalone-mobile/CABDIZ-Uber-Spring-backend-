package com.leadstech.cabidz.activities.find_new_job;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import com.leadstech.cabidz.R;
public class KickBiddingListAdapter  extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    public KickBiddingListAdapter(Context context){
        this.context =  context;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return 3;
    }
    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView;
        if(convertView == null){
            rowView = inflater.inflate(R.layout.kick_bidding_list_item, parent, false);
        }else {
            rowView = convertView;
        }
        return rowView;
    }
}
