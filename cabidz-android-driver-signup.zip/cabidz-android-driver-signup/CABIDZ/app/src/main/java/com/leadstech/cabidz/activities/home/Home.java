package com.leadstech.cabidz.activities.home;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationViewPager;
import com.aurelhubert.ahbottomnavigation.notification.AHNotification;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.Login;
import com.leadstech.cabidz.activities.find_new_job.ListOFJobsToDestination;
import com.leadstech.cabidz.activities.help.TripHelp;
import com.leadstech.cabidz.activities.incoming_job.AcceptIncomingJob;
import com.leadstech.cabidz.activities.incoming_job.IncommingJob;
import com.leadstech.cabidz.activities.left_slider.ChangeCarSetting;
import com.leadstech.cabidz.activities.left_slider.DocumentUpload;
import com.leadstech.cabidz.activities.left_slider.SettingActivity;
import com.leadstech.cabidz.activities.past_trip.PastTrips;
import com.leadstech.cabidz.activities.signup.Signup_final_step;
import com.leadstech.cabidz.activities.upcoming_trip.UpcomingTrip;
import com.leadstech.cabidz.cloud_apis.MakeAPICall;
import com.leadstech.cabidz.custom_objects.DrawerListAdapter;
import com.leadstech.cabidz.custom_objects.ViewPagerPositionChangeListner;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.StaticFunctios;
import com.leadstech.cabidz.singleton.URLs;

import java.util.HashMap;
import java.util.Map;

import static com.leadstech.cabidz.activities.Login.login_parm;
import static com.leadstech.cabidz.data_models.ArrayData.getUserAccountList;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class Home extends AppCompatActivity implements ViewPagerPositionChangeListner, APIResponseListner {
    TextView Car_Name ,Car_plate , Profile_NAME;
    ImageView CAR_IMG,Profile_Img;
    private AHBottomNavigationViewPager viewPager;
    private AHBottomNavigation bottomNavigation;
    Fragment currentFragment;
    ImageView Logout;
    public static DrawerLayout drawerLayout;
    private CustomViewPagerAdapter adapter;
    RelativeLayout FindNewJobDialog,Earning_Dialog;
    ImageView Cancel_FindNewJob,Exit_Drawer;
    Button Set_Destination,Cros_Earning;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                GOTO(Home.this, IncommingJob.class);
            }
        }, 10000);
        InitTabs();
        new UserAccountFragment(this);
        Logout = (ImageView) findViewById(R.id.exit);
        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawer(Gravity.START);
                StaticFunctios.ShowProgress(Home.this);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        StaticFunctios.HideProgress();
                       GOTO(Home.this, Login.class);
                        finish();
                    }
                }, 1000);
            }
        });
        Earning_Dialog = (RelativeLayout) findViewById(R.id.earning_dialog);
        FindNewJobDialog = (RelativeLayout) findViewById(R.id.find_new_job_dialog);
        Cros_Earning = (Button) findViewById(R.id.cros_earning);
        Cros_Earning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Earning_Dialog.setVisibility(View.GONE);
            }
        });
        Cancel_FindNewJob = (ImageView) findViewById(R.id.cross);
        Cancel_FindNewJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FindNewJobDialog.setVisibility(View.GONE);
            }
        });
        Set_Destination = (Button) findViewById(R.id.set_destination);
        Set_Destination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FindNewJobDialog.setVisibility(View.GONE);
                GOTO(Home.this, ListOFJobsToDestination.class);
            }
        });
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
         Exit_Drawer = (ImageView) findViewById(R.id.exit_menue);
         Exit_Drawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawer(Gravity.START);
            }
        });
        drawerLayout = (DrawerLayout) findViewById(R.id.my_drawer_layout);
        drawerLayout.setDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

            }

            @Override
            public void onDrawerOpened(View drawerView) {

            }

            @Override
            public void onDrawerClosed(View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });

        final ListView list = (ListView) findViewById(R.id.list_view);
        list.setAdapter(new DrawerListAdapter(this,getUserAccountList()));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                drawerLayout.closeDrawer(Gravity.START);
                if(position == 5){
                    FindNewJobDialog.setVisibility(View.VISIBLE);
                }else if(position == 3){
                    GOTO(Home.this, TripHelp.class);
                }else if (position == 0){
                    GOTO(Home.this, PastTrips.class);
                }else if (position == 1){
                    GOTO(Home.this, UpcomingTrip.class);
                }else if (position == 2){
                    GOTO(Home.this, DocumentUpload.class);
                }else if (position == 4){
                    GOTO(Home.this, SettingActivity.class);
                }
            }
        });
        final Button Edit_profile = (Button) findViewById(R.id.edit_pr);
        final Button Edit_Car = (Button) findViewById(R.id.chng_cr);
        Edit_Car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawer(Gravity.START);
                GOTO(Home.this, ChangeCarSetting.class);
            }
        });
        Edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawer(Gravity.START);
                GOTO(Home.this, SettingActivity.class);
            }
        });
        Car_Name = (TextView) findViewById(R.id.car_name);
        Car_plate = (TextView) findViewById(R.id.car_plate);
        CAR_IMG = (ImageView) findViewById(R.id.car_image);

        if(!SharedPrefrences.getString("car_img", Home.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("car_img" , Home.this)));
            roundDrawable.setCircular(true);
            CAR_IMG.setImageDrawable(roundDrawable);
        }
        if(login_parm.get("vehicle") != null || login_parm.get("vehicle").length() == 0 || login_parm.get("vehicle") != "null" ){
            Car_Name.setText(login_parm.get("vehicle"));
        }


        if(login_parm.get("number_plate") != null || login_parm.get("number_plate").length() == 0 || login_parm.get("number_plate") != "null" ){
            Car_plate.setText(login_parm.get("number_plate"));
        }

         Profile_NAME = (TextView) findViewById(R.id.profile_name);
        if(login_parm.get("first_name") != null || login_parm.get("first_name").length() == 0 || login_parm.get("first_name") != "null" || login_parm.get("last_name") != null || login_parm.get("last_name").length() == 0 || login_parm.get("last_name") != "null" ){
            Profile_NAME.setText(login_parm.get("first_name")+" "+login_parm.get("last_name"));
        }
         Profile_Img = (ImageView) findViewById(R.id.profile_img);
        if(!SharedPrefrences.getString("profile_pic", Home.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , Home.this)));
            roundDrawable.setCircular(true);
            Profile_Img.setImageDrawable(roundDrawable);
        }

        Map<String, String> parm = new HashMap<String, String>();
        parm.put("img_id", login_parm.get("img_id"));
        new MakeAPICall(Home.this, parm, PostMethod, URLs.RetrieveImage, APIActions.ApiActions.retrive_img, Home.this).execute();
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    public void InitTabs() {
        viewPager = (AHBottomNavigationViewPager) findViewById(R.id.view_pager);
        bottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);
        AHBottomNavigationItem item1 = new AHBottomNavigationItem(R.string.tab_1, R.mipmap.tab_home, R.color.location_enlatment);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem(R.string.tab_2, R.mipmap.tab_cash, R.color.location_enlatment);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem(R.string.tab_3, R.mipmap.tab_rate, R.color.location_enlatment);
        AHBottomNavigationItem item4 = new AHBottomNavigationItem(R.string.tab_4, R.mipmap.tab_user, R.color.location_enlatment);
        // Add items
        bottomNavigation.addItem(item1);
        bottomNavigation.addItem(item2);
        bottomNavigation.addItem(item3);
        bottomNavigation.addItem(item4);
        // Set background color
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#2D323B"));
        // Set active state color
        bottomNavigation.setAccentColor(Color.parseColor("#00CEA0"));
        // Set in active state  color
        bottomNavigation.setInactiveColor(Color.parseColor("#878C97"));
        // Manage titles
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_SHOW);
        bottomNavigation.setCurrentItem(0);

        // Customize notification (title, background, typeface)
        bottomNavigation.setNotificationBackgroundColor(Color.parseColor("#F63D2B"));
        AHNotification notification = new AHNotification.Builder()
                .setText("1")
                .setBackgroundColor(ContextCompat.getColor(Home.this, R.color.notificatio_bg))
                .setTextColor(ContextCompat.getColor(Home.this, R.color.colorPrimary))
                .build();
       bottomNavigation.setNotification(notification, 3);
         // Set listeners
        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                // Do something cool here...
                if(position==1){
                    Earning_Dialog.setVisibility(View.VISIBLE);
                }else {
                    Earning_Dialog.setVisibility(View.GONE);
                    viewPager.setCurrentItem(position, false);
                    currentFragment = adapter.getItem(position);
                }
                return true;
            }
        });
        bottomNavigation.setOnNavigationPositionListener(new AHBottomNavigation.OnNavigationPositionListener() {
            @Override
            public void onPositionChange(int y) {
                // Manage the new y position
            }
        });
        viewPager.setOffscreenPageLimit(4);
        adapter = new CustomViewPagerAdapter(getSupportFragmentManager(),this);
        viewPager.setAdapter(adapter);
    }
    @Override
    public void updatePosition(int position) {
        viewPager.setCurrentItem(position, false);
        currentFragment = adapter.getItem(position);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                FindNewJobDialog.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        hideKeyboard(Home.this);
                    }
                }, 200);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(!SharedPrefrences.getString("car_img", Home.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("car_img" , Home.this)));
            roundDrawable.setCircular(true);
            CAR_IMG.setImageDrawable(roundDrawable);
        }
        if(login_parm.get("vehicle") != null || login_parm.get("vehicle").length() == 0 || login_parm.get("vehicle") != "null" ){
            Car_Name.setText(login_parm.get("vehicle"));
        }


        if(login_parm.get("number_plate") != null || login_parm.get("number_plate").length() == 0 || login_parm.get("number_plate") != "null" ){
            Car_plate.setText(login_parm.get("number_plate"));
        }

        if(login_parm.get("first_name") != null || login_parm.get("first_name").length() == 0 || login_parm.get("first_name") != "null" || login_parm.get("last_name") != null || login_parm.get("last_name").length() == 0 || login_parm.get("last_name") != "null" ){
            Profile_NAME.setText(login_parm.get("first_name")+" "+login_parm.get("last_name"));
        }
        getDefaultImg();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if(!SharedPrefrences.getString("car_img", Home.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("car_img" , Home.this)));
            roundDrawable.setCircular(true);
            CAR_IMG.setImageDrawable(roundDrawable);
        }
        if(login_parm.get("vehicle") != null || login_parm.get("vehicle").length() == 0 || login_parm.get("vehicle") != "null" ){
            Car_Name.setText(login_parm.get("vehicle"));
        }


        if(login_parm.get("number_plate") != null || login_parm.get("number_plate").length() == 0 || login_parm.get("number_plate") != "null" ){
            Car_plate.setText(login_parm.get("number_plate"));
        }

        if(login_parm.get("first_name") != null || login_parm.get("first_name").length() == 0 || login_parm.get("first_name") != "null" || login_parm.get("last_name") != null || login_parm.get("last_name").length() == 0 || login_parm.get("last_name") != "null" ){
            Profile_NAME.setText(login_parm.get("first_name")+" "+login_parm.get("last_name"));
        }

        getDefaultImg();
    }

  public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", Home.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", Home.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if(decodedByte != null){
                SharedPrefrences.SetString("profile_pic_base64", SharedPrefrences.getString("profile_pic_base64", Home.this), getApplicationContext());
                RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                roundDrawable.setCircular(true);
                Profile_Img.setImageDrawable(roundDrawable);
                Log.d("image", SharedPrefrences.getString("profile_pic_base64", Home.this));
            }
        }else if(!SharedPrefrences.getString("profile_pic", Home.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , Home.this)));
            roundDrawable.setCircular(true);
            Profile_Img.setImageDrawable(roundDrawable);
        }
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(response != null){
            if(response.status.equalsIgnoreCase("true")){
                try {
                    String base_64 = response.img_data;
                    base_64 = base_64.replace(" " , "+");
                    Log.d("bit_map_%_img" , base_64);
                    byte[] decodedString = Base64.decode(base_64, 0);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    if(decodedByte != null){
                        SharedPrefrences.SetString("profile_pic_base64",base_64, getApplicationContext());
                        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                        roundDrawable.setCircular(true);
                        Profile_Img.setImageDrawable(roundDrawable);
                        Log.d("image", base_64);
                    }else {
                        getDefaultImg();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            } else {
                getDefaultImg();
            }
        }else {
            getDefaultImg();
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }
}
