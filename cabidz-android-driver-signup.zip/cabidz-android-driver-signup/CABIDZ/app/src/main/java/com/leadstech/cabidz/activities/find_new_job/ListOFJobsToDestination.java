package com.leadstech.cabidz.activities.find_new_job;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

import com.leadstech.cabidz.R;

import static com.leadstech.cabidz.singleton.IntentGO.GOTO;

public class ListOFJobsToDestination extends AppCompatActivity {
  ListView list;
    ImageView BACK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_ofjobs_to_destination);
        list = (ListView) findViewById(R.id.list);
        list.setAdapter(new JobsDestinationListAdapter(this));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               GOTO(ListOFJobsToDestination.this,JobsDestinationDetails.class);
            }});

        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });
    }
}
