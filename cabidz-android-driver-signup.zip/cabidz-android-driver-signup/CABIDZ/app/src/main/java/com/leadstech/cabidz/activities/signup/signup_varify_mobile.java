package com.leadstech.cabidz.activities.signup;

import android.content.Intent;
import android.os.Handler;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.cloud_apis.JsonAPICall;
import com.leadstech.cabidz.cloud_apis.MakeAPICall;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.URLs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.leadstech.cabidz.activities.signup.Signup_StepOne.parm;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;

public class signup_varify_mobile extends AppCompatActivity implements APIResponseListner {
    ImageView BACK;
    TextView Email_TXT;
    EditText ONE,TWO ,THREE,FOUR;
   public static boolean is_update_email = false;
    Button Change_Email_address , Resend_Code;
    String index_1 = "", index_2 ="",index_3="",index_4="";
    boolean isONE = false , isTWO = false , isThree = false , isFour = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_varify_mobile);
        Email_TXT = (TextView) findViewById(R.id.email_text);
        Email_TXT.setText(parm.get("email"));
        ONE = (EditText) findViewById(R.id.digit_one);
        TWO = (EditText) findViewById(R.id.digit_two);
        THREE = (EditText) findViewById(R.id.digit_three);
        FOUR = (EditText) findViewById(R.id.digit_four);
        ONE.requestFocus();
        ONE.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void afterTextChanged(Editable editable) {
                if(ONE.getText().length()==1){
                    index_1 = ONE.getText().toString();
                    isONE = true;
                    if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                    }
                    TWO.requestFocus();
                }else {
                    index_1 = "";
                    isONE = false;
                }
            }
        });

        FOUR.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(FOUR.getText().length()==1){
                    index_4 = FOUR.getText().toString();
                    isFour = true;
                    if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                    }

                }else {
                    index_4 = "";
                    isFour = false;
                }
            }
        });
        TWO.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(TWO.getText().length()==1){
                    index_2 = TWO.getText().toString();
                    isTWO = true;
                    if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                    }
                    THREE.requestFocus();

                }else {
                    index_2 = "";
                    isTWO = false;
                }
            }
        });
        THREE.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(THREE.getText().length()==1){
                    index_3 = THREE.getText().toString();
                    isThree = true;
                    if(isONE && isThree && isTWO && isFour){
                        SubmitData();
                    }
                    FOUR.requestFocus();


                }else {
                    index_3 = "";
                    isThree = false;
                }
            }
        });
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Change_Email_address = (Button) findViewById(R.id.change_email_address);
        Change_Email_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                is_update_email = true;
                finish();
            }
        });

        Resend_Code = (Button) findViewById(R.id.resend_text);
        Resend_Code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random = new Random();
                String code = String.format("%04d", random.nextInt(10000));
                parm.put("code", code);
                Log.d("codee--------" , "\n\n"+ code);
                JSONObject jsonBody = null;
                try {
                    jsonBody = new JSONObject("{\n" +
                            "\"from\":\"no-reply@cabidz.com\",\n" +
                            "\"subject\":\"Email Verification!\",\n" +
                            "\"message\":\"your verification code is = "+code+"\",\n" +
                            "\"email_where_to_send\":\""+parm.get("email")+"\"\n" +
                            "}\n");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                new JsonAPICall(signup_varify_mobile.this,jsonBody, Request.Method.POST, URLs.SendEmail,APIActions.ApiActions.send_email,signup_varify_mobile.this);
            }
        });
    }

    public void SubmitData(){
        if(parm.get("code").equalsIgnoreCase(index_1+index_2+index_3+index_4)){
           Intent i = new Intent(signup_varify_mobile.this, Signup_third_step.class);
            startActivity(i);
            finish();
        }else {
            Toast.makeText(getApplicationContext(),"Invalid Verification Code", Toast.LENGTH_SHORT).show();
            ONE.setText("");
            ONE.requestFocus();
            TWO.setText("");
            THREE.setText("");
            FOUR.setText("");
        }
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if (apiActions == APIActions.ApiActions.send_email) {
            if (response.status.equalsIgnoreCase("success")) {
                Toast.makeText(getApplicationContext(), "New code has been send to you email address successfully!", Toast.LENGTH_SHORT).show();
            } else {
                if (response.message == null) {
                    Toast.makeText(getApplicationContext(), "Email verification failed try again later!!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }
}
