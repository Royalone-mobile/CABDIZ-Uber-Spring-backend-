package com.leadstech.cabidz.singleton;

import com.leadstech.cabidz.model.Response;

public interface APIResponseListner {
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) ;
    public void onRequestError(Response response, APIActions.ApiActions apiActions);
}
