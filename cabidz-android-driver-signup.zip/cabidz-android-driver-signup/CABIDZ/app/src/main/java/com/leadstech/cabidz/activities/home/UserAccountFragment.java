package com.leadstech.cabidz.activities.home;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.Login;
import com.leadstech.cabidz.activities.help.TripHelp;
import com.leadstech.cabidz.activities.left_slider.ChangeCarSetting;
import com.leadstech.cabidz.activities.left_slider.DocumentUpload;
import com.leadstech.cabidz.activities.left_slider.SettingActivity;
import com.leadstech.cabidz.activities.past_trip.PastTrips;
import com.leadstech.cabidz.activities.upcoming_trip.UpcomingTrip;
import com.leadstech.cabidz.custom_objects.ViewPagerPositionChangeListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.StaticFunctios;

import static com.leadstech.cabidz.activities.Login.login_parm;
import static com.leadstech.cabidz.data_models.ArrayData.getUserAccountList;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;

public class UserAccountFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    ViewPagerPositionChangeListner callback ;
    @SuppressLint("ValidFragment")
    public UserAccountFragment(ViewPagerPositionChangeListner callback) {
        // Required empty public constructor
        this.callback = callback;

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment UserAccountFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static UserAccountFragment newInstance(String param1, String param2, ViewPagerPositionChangeListner calback) {
        UserAccountFragment fragment = new UserAccountFragment(calback);
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_user_account, container, false);
        final ListView list = (ListView) view.findViewById(R.id.list_view);
        final ImageView MENU = (ImageView) view.findViewById(R.id.menue);
        final Button Edit_profile = (Button) view.findViewById(R.id.edit_profile);
        final Button Edit_Car = (Button) view.findViewById(R.id.change_car);
        Edit_Car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GOTO(getActivity(), ChangeCarSetting.class);
            }
        });
        Edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GOTO(getActivity(), SettingActivity.class);
            }
        });

        MENU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Home.drawerLayout.openDrawer(Gravity.START);
            }
        });

       final ImageView Logout = (ImageView) view.findViewById(R.id.exit);
        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Home.drawerLayout.closeDrawer(Gravity.START);
                StaticFunctios.ShowProgress(getActivity());
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        StaticFunctios.HideProgress();
                        GOTO(getActivity(), Login.class);
                        getActivity().finish();
                    }
                }, 1000);
            }
        });
        list.setAdapter(new UserAccountListAdapter(getContext(),getUserAccountList()));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                new Thread(new Runnable(){
                    public void run(){
                        if(position == 5){
                            callback.updatePosition(0);
                        }else if(position == 3){
                            GOTO(getActivity(), TripHelp.class);
                        }else if (position == 0){
                            GOTO(getActivity(), PastTrips.class);
                        }else if (position == 1){
                            GOTO(getActivity(), UpcomingTrip.class);
                        }else if (position == 2){
                            GOTO(getActivity(), DocumentUpload.class);
                        }else if (position == 4){
                            GOTO(getActivity(), SettingActivity.class);
                        }
                    }
                }).start();
            }
        });

        final ImageView CAR_IMG = (ImageView) view.findViewById(R.id.car_image);
        final ImageView Profile_Img = (ImageView) view.findViewById(R.id.profile_img);

        if(!SharedPrefrences.getString("car_img",getContext()).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("car_img" , getContext())));
            roundDrawable.setCircular(true);
            CAR_IMG.setImageDrawable(roundDrawable);
        }
        if(!SharedPrefrences.getString("profile_pic_base64", getContext()).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", getContext()), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if(decodedByte != null){
                SharedPrefrences.SetString("profile_pic_base64", SharedPrefrences.getString("profile_pic_base64",getContext()), getContext());
                RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                roundDrawable.setCircular(true);
                Profile_Img.setImageDrawable(roundDrawable);
                Log.d("image", SharedPrefrences.getString("profile_pic_base64",getContext()));
            }
        }else if(!SharedPrefrences.getString("profile_pic", getContext()).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" ,getContext())));
            roundDrawable.setCircular(true);
            Profile_Img.setImageDrawable(roundDrawable);
        }

       final TextView Profile_NAME = (TextView) view.findViewById(R.id.profile_name);
        final TextView Car_Name = (TextView) view.findViewById(R.id.car_name);
        final TextView Car_plate = (TextView) view.findViewById(R.id.car_plate);
        if(login_parm.get("vehicle") != null || login_parm.get("vehicle").length() == 0 || login_parm.get("vehicle") != "null" ){
            Car_Name.setText(login_parm.get("vehicle"));
        }


        if(login_parm.get("number_plate") != null || login_parm.get("number_plate").length() == 0 || login_parm.get("number_plate") != "null" ){
            Car_plate.setText(login_parm.get("number_plate"));
        }

        if(login_parm.get("first_name") != null || login_parm.get("first_name").length() == 0 || login_parm.get("first_name") != "null" || login_parm.get("last_name") != null || login_parm.get("last_name").length() == 0 || login_parm.get("last_name") != "null" ){
            Profile_NAME.setText(login_parm.get("first_name")+" "+login_parm.get("last_name"));
        }


        return view;
    }

}
