package com.leadstech.cabidz.singleton;
public class URLs {
    public static String BaseURL = "https://0-dot-massive-amulet-153623.appspot.com/Driver";
    public static String LoginURL = BaseURL+"/LoginEndpointAPI";
    public static String EmailVerfication = BaseURL+"/EmailVerification";
    public static String SignupURL = BaseURL+"/SignUpEndpointAPI";
    public static String UpdateDocument = BaseURL+"/UpdateDecumentEndPointAPI";
    public static String UpdateUserProfile = BaseURL+"/UpdateUserProfileEndpointAPI";
    public static String UpdateUserCar = BaseURL+"/UpdateUserCarEndpointAPI";
//    public static String SendEmail = "http://fitnessapp.staffdevelopers.com/services/SendEmail";
     public static String SendEmail = "https://0-dot-massive-amulet-153623.appspot.com/Email/SendEmail";

    public static String CreditCardVerification = "http://fitnessapp.staffdevelopers.com/services/ValidateCreditCard";
    public static String PlaceAPI = "http://maps.google.com/maps/api/geocode/json?address=";
    public static String RetrieveImage = "https://0-dot-massive-amulet-153623.appspot.com/Upload/RetrieveImage";
    public static String UploadImage = "https://0-dot-massive-amulet-153623.appspot.com/Upload/UploadImage";

}
