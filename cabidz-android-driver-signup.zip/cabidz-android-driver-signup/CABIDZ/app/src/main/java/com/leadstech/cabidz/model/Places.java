package com.leadstech.cabidz.model;

/**
 * Created by jawadali on 5/12/17.
 */

public class Places {
    private  String formatted_address;

    public String getFormatted_address() {
        return formatted_address;
    }

    public void setFormatted_address(String formatted_address) {
        this.formatted_address = formatted_address;
    }
}
