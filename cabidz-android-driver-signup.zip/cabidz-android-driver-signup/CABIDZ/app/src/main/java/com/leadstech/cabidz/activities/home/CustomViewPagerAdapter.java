package com.leadstech.cabidz.activities.home;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.leadstech.cabidz.custom_objects.ViewPagerPositionChangeListner;

/**
 * Created by dany on 04/04/2017.
 */

public class CustomViewPagerAdapter extends FragmentPagerAdapter {
    private static int NUM_ITEMS = 4;
    ViewPagerPositionChangeListner callback;
    public CustomViewPagerAdapter(FragmentManager fragmentManager,ViewPagerPositionChangeListner cal) {
        super(fragmentManager);
        this.callback =cal;
    }
    // Returns total number of pages
    @Override
    public int getCount() {
        return NUM_ITEMS;
    }

    // Returns the fragment to display for that page
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0: // Fragment # 0 - This will show FirstFragment
                return  HomeFragment.newInstance("1","1");
            case 1: // Fragment # 0 - This will show FirstFragment different title
                return HomeFragment.newInstance("2","2");
            case 2: // Fragment # 1 - This will show SecondFragment
//                return RattingFragment.newInstance("1","1");
                return HomeFragment.newInstance("3","3");
            case 3: // Fragment # 1 - This will show SecondFragment
                return UserAccountFragment.newInstance("1","1",callback);
            default:
                return null;
        }
    }
    // Returns the page title for the top indicator
    @Override
    public CharSequence getPageTitle(int position) {
        return "Page " + position;
    }
}