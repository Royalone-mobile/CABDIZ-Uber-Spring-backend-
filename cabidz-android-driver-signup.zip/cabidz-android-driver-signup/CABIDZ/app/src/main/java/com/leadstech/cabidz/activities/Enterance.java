package com.leadstech.cabidz.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.signup.Signup_StepOne;
import com.leadstech.cabidz.activities.signup.Signup_final_step;
import com.leadstech.cabidz.singleton.StripeResponse;
import com.stripe.android.Stripe;
import com.stripe.android.TokenCallback;
import com.stripe.android.model.BankAccount;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;
import com.stripe.exception.APIConnectionException;
import com.stripe.exception.APIException;
import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.exception.InvalidRequestException;
import com.stripe.model.Account;
import com.stripe.model.Charge;
import com.stripe.model.Customer;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidz.singleton.StaticFunctios.ShowProgress;

public class Enterance extends AppCompatActivity {
    Button btn_Login, Signup;
    final int MY_PERMISSIONS_REQUEST_SEND_SMS =98;
    private static final String FUNCTIONAL_SOURCE_PUBLISHABLE_KEY =
            "pk_test_vOo1umqsYxSrP5UXfOeL3ecm";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enterance);
        btn_Login = (Button) findViewById(R.id.login);
        Signup = (Button) findViewById(R.id.signup);
        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                sendSMSMessage();
                GOTO(Enterance.this,Login.class);
            }
        });
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GOTO(Enterance.this, Signup_StepOne.class);
            }
        });
    }


  public void CreateAccount(){
      Thread thread = new Thread() {
          @Override
          public void run() {
              com.stripe.Stripe.apiKey = "sk_test_n8hO8g8giswb1pE1OOpDliSC";
              Map<String, Object> accountParams = new HashMap<String, Object>();
              accountParams.put("country", "AU");
              accountParams.put("managed", true);
              try {
                  Account ac = Account.create(accountParams);
                  Log.d("create", "crea" + ac.getId());
              } catch (AuthenticationException e) {
                  e.printStackTrace();
              } catch (InvalidRequestException e) {
                  e.printStackTrace();
              } catch (APIConnectionException e) {
                  e.printStackTrace();
              } catch (CardException e) {
                  e.printStackTrace();
              } catch (APIException e) {
                  e.printStackTrace();
              }
          }
      };
      thread.start();
  }
}
