package com.leadstech.cabidz.activities.signup;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.android.volley.Request;
import com.baoyz.actionsheet.ActionSheet;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.Enterance;
import com.leadstech.cabidz.activities.MainActivity;
import com.leadstech.cabidz.activities.PlaceArrayAdapter;
import com.leadstech.cabidz.activities.Splash;
import com.leadstech.cabidz.activities.home.Home;
import com.leadstech.cabidz.cloud_apis.JsonAPICall;
import com.leadstech.cabidz.cloud_apis.MakeAPICall;
import com.leadstech.cabidz.cloud_apis.UploadImageAPICall;
import com.leadstech.cabidz.model.PlaceResponse;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.StaticFunctios;
import com.leadstech.cabidz.singleton.URLs;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import static com.leadstech.cabidz.activities.Login.login_parm;
import static com.leadstech.cabidz.activities.signup.signup_varify_mobile.is_update_email;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.GetMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.emailValidator;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class Signup_StepOne extends AppCompatActivity implements APIResponseListner, ActionSheet.ActionSheetListener , GoogleApiClient.OnConnectionFailedListener,
        GoogleApiClient.ConnectionCallbacks {
    Button NEXT;
    ArrayAdapter<String> adapter;
    private GoogleApiClient mGoogleApiClient;
    private static final String LOG_TAG = "MainActivity";
    private static final int GOOGLE_API_CLIENT_ID = 0;
    int EditTextID = 0;
    boolean isImageSelced = false;
    int PLACE_AUTOCOMPLETE_REQUEST_CODE = 19;
    String Address = "";
    PlaceAutocompleteFragment autocompleteFragment;
    String[] filePathColumn;
    Uri selectedImage;
    String State_txt = "", City_txt = "";
    public static Map<String, String> parm = new HashMap<>();
    ImageView Profile_IMG, BACK;
    String TAG = "Cabidz";
    AutoCompleteTextView ADDRESS, City, State;
    EditText  First_name, Last_name, Email, Password, Phone_number, Postal_Code;
    List<String> adress_list = new ArrayList<>();
    private PlaceArrayAdapter mPlaceArrayAdapter;
    private static final LatLngBounds BOUNDS_MOUNTAIN_VIEW = new LatLngBounds(new LatLng(23.63936, 68.14712), new LatLng(28.20453, 97.34466));
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup__step_one);
        First_name = (EditText) findViewById(R.id.first_name);
        Last_name = (EditText) findViewById(R.id.last_name);
        Email = (EditText) findViewById(R.id.email);
        Password = (EditText) findViewById(R.id.password);
        Phone_number = (EditText) findViewById(R.id.phone_number);
        City = (AutoCompleteTextView) findViewById(R.id.city);
        State = (AutoCompleteTextView) findViewById(R.id.state);
        mGoogleApiClient = new GoogleApiClient.Builder(Signup_StepOne.this)
                .addApi(Places.GEO_DATA_API)
                .enableAutoManage(this, GOOGLE_API_CLIENT_ID, this)
                .addConnectionCallbacks(this)
                .build();
        Random random = new Random();
        parm.put("img_id", String.format("%07d", random.nextInt(10000)));
        ADDRESS = (AutoCompleteTextView) findViewById(R.id.address_e);
        Postal_Code = (EditText) findViewById(R.id.postal_code);
        City.setThreshold(1);
        ADDRESS.setThreshold(1);
        State.setThreshold(1);
        ADDRESS.setOnItemClickListener(mAutocompleteClickListener);
        City.setOnItemClickListener(mAutocompleteClickListener);
        State.setOnItemClickListener(mAutocompleteClickListener);
        AutocompleteFilter filter = new AutocompleteFilter.Builder().setCountry("AU").build();
        mPlaceArrayAdapter = new PlaceArrayAdapter(this, android.R.layout.simple_list_item_1,
                null, filter);
        ADDRESS.setAdapter(mPlaceArrayAdapter);
        City.setAdapter(mPlaceArrayAdapter);
        State.setAdapter(mPlaceArrayAdapter);
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            SetPermissions();
        }
        Profile_IMG = (ImageView) findViewById(R.id.profile_item);
        NEXT = (Button) findViewById(R.id.next);
        NEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (First_name.getText().length() > 0 &&
                        Last_name.getText().length() > 0 &&
                        Email.getText().length() > 0 &&
                        Password.getText().length() > 0 &&
                        Phone_number.getText().length() > 0 &&
                        ADDRESS.getText().toString().length() > 0 &&
                        isImageSelced){
                    if (emailValidator(Email.getText().toString())) {
                        Map<String, String> parm = new HashMap<String, String>();
                        parm.put("email", Email.getText().toString());
                        new MakeAPICall(Signup_StepOne.this, parm, PostMethod, URLs.EmailVerfication, APIActions.ApiActions.email_verfication, Signup_StepOne.this).execute();
                    } else {
                        Email.requestFocus();
                        Email.setText("");
                        Toast.makeText(getApplicationContext(), "Email is not valid!!", Toast.LENGTH_SHORT).show();
                        Email.setError("invalid eamil");
                    }
                } else {
                    if(!isImageSelced){
                        Toast.makeText(getApplicationContext(), "Select profile picture!", Toast.LENGTH_LONG).show();
                    }
                    Toast.makeText(getApplicationContext(), "all fields are required", Toast.LENGTH_SHORT).show();
                }
            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideKeyboard(Signup_StepOne.this);
            }
        }, 200);
        Profile_IMG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActionSheet.createBuilder(Signup_StepOne.this, getSupportFragmentManager())
                        .setCancelButtonTitle("Cancel")
                        .setOtherButtonTitles("Camera", "Gallery")
                        .setCancelableOnTouchOutside(true)
                        .setListener(Signup_StepOne.this).show();
            }
        });
    }
    private AdapterView.OnItemClickListener mAutocompleteClickListener
            = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            final PlaceArrayAdapter.PlaceAutocomplete item = mPlaceArrayAdapter.getItem(position);
            final String placeId = String.valueOf(item.placeId);
            Log.i(LOG_TAG, "Selected: " + item.description);
            PendingResult<PlaceBuffer> placeResult = Places.GeoDataApi
                    .getPlaceById(mGoogleApiClient, placeId);
            placeResult.setResultCallback(mUpdatePlaceDetailsCallback);
            Log.i(LOG_TAG, "Fetching details for ID: " + item.placeId);
        }
    };

    private ResultCallback<PlaceBuffer> mUpdatePlaceDetailsCallback
            = new ResultCallback<PlaceBuffer>() {
        @Override
        public void onResult(PlaceBuffer places) {
            if (!places.getStatus().isSuccess()) {
                Log.e(LOG_TAG, "Place query did not complete. Error: " +
                        places.getStatus().toString());
                return;
            }
            // Selecting the first object buffer.
            final Place place = places.get(0);
                if (ADDRESS.isFocused()) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                  List<Address> addresses = getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude);
                                City.setText(addresses.get(0).getLocality());
                                Postal_Code.setText(addresses.get(0).getPostalCode());
                                State.setText(addresses.get(0).getAdminArea());
                                Log.d("State Test",State.getText().toString());
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }, 100);
                }
        }
    };

    @Override
    public void onConnected(Bundle bundle) {
        mPlaceArrayAdapter.setGoogleApiClient(mGoogleApiClient);
        Log.i(LOG_TAG, "Google Places API connected.");

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.e(LOG_TAG, "Google Places API connection failed with error code: "
                + connectionResult.getErrorCode());

        Toast.makeText(this,
                "Google Places API connection failed with error code:" +
                        connectionResult.getErrorCode(),
                Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConnectionSuspended(int i) {
        mPlaceArrayAdapter.setGoogleApiClient(null);
        Log.e(LOG_TAG, "Google Places API connection suspended.");
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && null != data) {
            selectedImage = data.getData();
            filePathColumn = new String[]{MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            SharedPrefrences.SetString("profile_pic", picturePath, getApplicationContext());
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(picturePath));
            roundDrawable.setCircular(true);


            Bitmap bitmapOrg = BitmapFactory.decodeFile(picturePath);
            Bitmap bitmap = BITMAP_RESIZER(bitmapOrg, 80, 80);
            ByteArrayOutputStream bao = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 30, bao);
            byte[] ba = bao.toByteArray();
            String ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
            ba1 = ba1.replace("\n","");
            SharedPrefrences.SetString("profile_pic_base64", ba1, getApplicationContext());
            UploadImage(ba1);

            Profile_IMG.setImageDrawable(roundDrawable);
//            Profile_IMG.setImageBitmap(BitmapFactory.decodeFile(picturePath));
        } else if (requestCode == 9 && resultCode == RESULT_OK && data != null) {
            onCaptureImageResult(data);
        } else if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                final Place place = PlaceAutocomplete.getPlace(this, data);
                        Address =  ADDRESS.getText().toString();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    City.setText(getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude).get(0).getLocality());
                                    Postal_Code.setText(getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude).get(0).getPostalCode());
                                    State.setText(getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude).get(0).getAdminArea());
                                   Log.d("State Test",State.getText().toString());

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, 100);
                Log.i(TAG, "Place: " + place.getName());
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                // TODO: Handle the error.
                Log.i(TAG, status.getStatusMessage());

            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void SetPermissions() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(Signup_StepOne.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(Signup_StepOne.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) && ActivityCompat.shouldShowRequestPermissionRationale(Signup_StepOne.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(Signup_StepOne.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        12);
                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 12: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(apiActions == APIActions.ApiActions.upload_img){
            Log.d("img==>",response.message + "\n"+"test");
        }else  if (apiActions == APIActions.ApiActions.email_verfication) {
            if (response.status.equalsIgnoreCase("true")) {
                Random random = new Random();
                String code = String.format("%04d", random.nextInt(10000));
                parm.put("code", code);
                Log.d("codee--------", "\n\n" + code);
                Map<String, String> parm = new HashMap<String, String>();
                parm.put("email", Email.getText().toString());
                parm.put("name", "User");
                parm.put("subject", "Email Verification!");
                parm.put("text", "your verification code is = <h2>" + code + " </h2>");
                new MakeAPICall(Signup_StepOne.this, parm, PostMethod, URLs.SendEmail, APIActions.ApiActions.send_email, Signup_StepOne.this).execute();
            } else {
                Email.setText("");
                Email.setError("already exist");
                Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
            }
        } else if (apiActions == APIActions.ApiActions.send_email) {
            if(response !=  null){
                if (response.status.equalsIgnoreCase("true")) {
                    String android_id = Settings.Secure.getString(getApplicationContext().getContentResolver(),
                            Settings.Secure.ANDROID_ID);
                    parm.put("device_token", android_id);
                    parm.put("first_name", First_name.getText().toString());
                    parm.put("last_name", Last_name.getText().toString());
                    parm.put("phone_number", Phone_number.getText().toString());
                    parm.put("email", Email.getText().toString());
                    parm.put("password", Password.getText().toString());
                    parm.put("address", ADDRESS.getText().toString());
                    parm.put("city", City.getText().toString());
                    parm.put("state", State.getText().toString());
                    parm.put("postal_code", Postal_Code.getText().toString());
                    GOTO(Signup_StepOne.this, signup_varify_mobile.class);
                } else {
                    if (response.message == null) {
                        Toast.makeText(getApplicationContext(), "Email verification failed try again later!!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } else if (apiActions == APIActions.ApiActions.place) {
            PlaceResponse resp = (PlaceResponse) response;
            for (int x = 0; x < resp.getResults().size(); x++) {
                adress_list.add(resp.getResults().get(x).getFormatted_address());
            }
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("countries.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (is_update_email) {
            Email.setText("");
            Email.requestFocus();
        }

        Log.d("path", SharedPrefrences.getString("profile_pic", Signup_StepOne.this));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!SharedPrefrences.getString("profile_pic", Signup_StepOne.this).equalsIgnoreCase("null")) {
                    RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic", Signup_StepOne.this)));
                    roundDrawable.setCircular(true);
                    Profile_IMG.setImageDrawable(roundDrawable);
                }
            }
        }, 1000);

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (is_update_email) {
            Email.setText("");
            Email.requestFocus();
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!SharedPrefrences.getString("profile_pic", Signup_StepOne.this).equalsIgnoreCase("null")) {
                    RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic", Signup_StepOne.this)));
                    roundDrawable.setCircular(true);
                    Profile_IMG.setImageDrawable(roundDrawable);
                }
            }
        }, 1000);

    }

    @Override
    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

    }

    @Override
    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
        if (index == 0) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, 9);
        } else {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_PICK);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);
//            Intent i = new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//            startActivityForResult(i, 1);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        SharedPrefrences.SetString("profile_pic", destination.getAbsolutePath(), getApplicationContext());
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), thumbnail);
        roundDrawable.setCircular(true);

        Bitmap bitmap = BITMAP_RESIZER(thumbnail, 80, 80);
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 30, bao);
        byte[] ba = bao.toByteArray();
        String ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
        ba1 = ba1.replace("\n","");
        SharedPrefrences.SetString("profile_pic_base64", ba1, getApplicationContext());
        UploadImage(ba1);


        Profile_IMG.setImageDrawable(roundDrawable);
    }

    public void Auto() {
//         autocompleteFragment = (PlaceAutocompleteFragment)
//                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
//        autocompleteFragment.setHint("Address");
//        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
//            @Override
//            public void onPlaceSelected(Place place) {
//                Address = place.getAddress().toString();
//                try {
//                    City.setText(getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude).get(0).getLocality());
//                    Postal_Code.setText(getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude).get(0).getPostalCode());
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
////                State.setText(place.getAttributions().toString());
//                // TODO: Get info about the selected place.
//                Log.i(TAG, "Place: " + place.getName());
//            }
//
//            @Override
//            public void onError(Status status) {
//                // TODO: Handle the error.
//                Log.i(TAG, "An error occurred: " + status);
//            }
//        });
    }
    public void SetPlaceIntent() {
        try {
            Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                            .build(this);
            startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
        } catch (GooglePlayServicesRepairableException e) {
            // TODO: Handle the error.
        } catch (GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }
    }

    private List<android.location.Address> getCityNameByCoordinates(double lat, double lon) throws IOException {
        Geocoder mGeocoder = new Geocoder(Signup_StepOne.this, Locale.getDefault());
        List<android.location.Address> addresses = mGeocoder.getFromLocation(lat, lon, 1);
        if (addresses != null && addresses.size() > 0) {
            Log.d("city" , addresses.get(0).getLocality());
            Log.d("state" , addresses.get(0).getAdminArea());
            Log.d("postal" , addresses.get(0).getPostalCode());
            return addresses;
        }
        return null;
    }

    public void UploadImage(String base64) {
        isImageSelced = true;
        int length = base64.length()/30;
        String data_1 = base64.substring(0,length);
        String data_2 = base64.substring((length),(length*2));
        String data_3 = base64.substring((length*2),(length*3));
        String data_4 = base64.substring((length*3),(length*4));
        String data_5 = base64.substring((length*4),(length*5));

        String data_6 = base64.substring((length*5),(length*6));
        String data_7 = base64.substring((length*6),(length*7));
        String data_8 = base64.substring((length*7),(length*8));
        String data_9 = base64.substring((length*8),(length*9));
        String data_10 = base64.substring((length*9),(length*10));

        String data_11 = base64.substring((length*10),(length*11));
        String data_12 = base64.substring((length*11),(length*12));
        String data_13 = base64.substring((length*12),(length*13));
        String data_14 = base64.substring((length*13),(length*14));
        String data_15 = base64.substring((length*14),(length*15));

        String data_16 = base64.substring((length*15),(length*16));
        String data_17 = base64.substring((length*16),(length*17));
        String data_18 = base64.substring((length*17),(length*18));
        String data_19 = base64.substring((length*18),(length*19));
        String data_20 = base64.substring((length*19),(length*20));

        String data_21 = base64.substring((length*20),(length*21));
        String data_22 = base64.substring((length*21),(length*22));
        String data_23 = base64.substring((length*22),(length*23));
        String data_24 = base64.substring((length*23),(length*24));
        String data_25 = base64.substring((length*24),(length*25));

        String data_26 = base64.substring((length*25),(length*26));
        String data_27 = base64.substring((length*26),(length*27));
        String data_28 = base64.substring((length*27),(length*28));
        String data_29 = base64.substring((length*28),(length*29));
        String data_30 = base64.substring((length*29),base64.length());

        Map<String, String> parm_img = new HashMap<>();
        parm_img.put("img_id" , parm.get("img_id"));
        parm_img.put("data_1" , data_1);
        parm_img.put("data_2" , data_2);
        parm_img.put("data_3" , data_3);
        parm_img.put("data_4" , data_4);
        parm_img.put("data_5" , data_5);
        parm_img.put("data_6" , data_6);
        parm_img.put("data_7" , data_7);
        parm_img.put("data_8" , data_8);
        parm_img.put("data_9" , data_9);

        parm_img.put("data_10" , data_10);
        parm_img.put("data_11" , data_11);
        parm_img.put("data_12" , data_12);
        parm_img.put("data_13" , data_13);
        parm_img.put("data_14" , data_14);
        parm_img.put("data_15" , data_15);
        parm_img.put("data_16" , data_16);
        parm_img.put("data_17" , data_17);
        parm_img.put("data_18" , data_18);
        parm_img.put("data_19" , data_19);
        parm_img.put("data_20" , data_20);

        parm_img.put("data_21" , data_21);
        parm_img.put("data_22" , data_22);
        parm_img.put("data_23" , data_23);
        parm_img.put("data_24" , data_24);
        parm_img.put("data_25" , data_25);
        parm_img.put("data_26" , data_26);
        parm_img.put("data_27" , data_27);
        parm_img.put("data_28" , data_28);
        parm_img.put("data_29" , data_29);
        parm_img.put("data_30" , data_30);
        new UploadImageAPICall(Signup_StepOne.this, parm_img, PostMethod, URLs.UploadImage, APIActions.ApiActions.upload_img, Signup_StepOne.this).execute();
    }

    public static Bitmap BITMAP_RESIZER(Bitmap bitmap, int newWidth, int newHeight) {
        Bitmap scaledBitmap = Bitmap.createBitmap(newWidth, newHeight, Bitmap.Config.ARGB_8888);
        float ratioX = newWidth / (float) bitmap.getWidth();
        float ratioY = newHeight / (float) bitmap.getHeight();
        float middleX = newWidth / 2.0f;
        float middleY = newHeight / 2.0f;
        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);
        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bitmap, middleX - bitmap.getWidth() / 2, middleY - bitmap.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));
        return scaledBitmap;

    }

}
