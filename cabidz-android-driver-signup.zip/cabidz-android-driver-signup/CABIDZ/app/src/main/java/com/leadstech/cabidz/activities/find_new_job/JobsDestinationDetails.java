package com.leadstech.cabidz.activities.find_new_job;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.incoming_job.StartTrip;
import com.leadstech.cabidz.custom_objects.DrawRoute;
import com.leadstech.cabidz.custom_objects.JSONParse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.leadstech.cabidz.singleton.IntentGO.GOTO;

public class JobsDestinationDetails extends AppCompatActivity  {
    ImageView BACK;
    Button KICK_BIDDING;
    private GoogleMap mMap;
    DrawRoute rout;
    private LocationManager locationManager = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jobs_destination_details);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        rout = new DrawRoute(JobsDestinationDetails.this,mMap,mapFragment);
        rout.CallDrawPathClass();
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        KICK_BIDDING = (Button) findViewById(R.id.kick_bid);
        KICK_BIDDING.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GOTO(JobsDestinationDetails.this, KickBidding.class);
            }
        });
    }

}
