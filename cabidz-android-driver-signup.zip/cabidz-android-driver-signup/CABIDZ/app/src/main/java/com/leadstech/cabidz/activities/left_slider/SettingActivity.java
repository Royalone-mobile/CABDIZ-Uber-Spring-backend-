package com.leadstech.cabidz.activities.left_slider;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.baoyz.actionsheet.ActionSheet;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.PlaceArrayAdapter;
import com.leadstech.cabidz.activities.home.Home;
import com.leadstech.cabidz.activities.signup.Signup_StepOne;
import com.leadstech.cabidz.activities.signup.Signup_final_step;
import com.leadstech.cabidz.activities.signup.signup_varify_mobile;
import com.leadstech.cabidz.cloud_apis.MakeAPICall;
import com.leadstech.cabidz.cloud_apis.UploadImageAPICall;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.StripeResponse;
import com.leadstech.cabidz.singleton.URLs;
import com.stripe.android.Stripe;
import com.stripe.android.TokenCallback;
import com.stripe.android.model.BankAccount;
import com.stripe.android.model.Token;
import com.stripe.exception.APIConnectionException;
import com.stripe.exception.APIException;
import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.exception.InvalidRequestException;
import com.stripe.model.Customer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.leadstech.cabidz.activities.Login.login_parm;
import static com.leadstech.cabidz.activities.signup.Signup_StepOne.BITMAP_RESIZER;
import static com.leadstech.cabidz.activities.signup.Signup_StepOne.parm;
import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.ShowProgress;
import static com.leadstech.cabidz.singleton.StaticFunctios.emailValidator;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class SettingActivity extends AppCompatActivity implements APIResponseListner , ActionSheet.ActionSheetListener, GoogleApiClient.OnConnectionFailedListener,
        GoogleApiClient.ConnectionCallbacks, StripeResponse {
    Button UPDATE;
    String[] filePathColumn;
    Uri selectedImage;
    ImageView  BACK;
    String ERRO_MSG;
    String State_txt = "", City_txt = "";
    ImageView Profile;
    private GoogleApiClient mGoogleApiClient;
    private static final String LOG_TAG = "MainActivity";
    private static final int GOOGLE_API_CLIENT_ID = 0;
    AutoCompleteTextView Address,City,State;
    int PLACE_AUTOCOMPLETE_REQUEST_CODE = 19;
    private PlaceArrayAdapter mPlaceArrayAdapter;
    private static final LatLngBounds BOUNDS_MOUNTAIN_VIEW = new LatLngBounds(
            new LatLng(23.63936, 68.14712), new LatLng(28.20453, 97.34466));
    EditText First_name, Last_name, Phone_number, Postal_Code, Account_number, Account_holder_name, BSB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        First_name = (EditText) findViewById(R.id.first_name);
        Last_name = (EditText) findViewById(R.id.last_name);
        Phone_number = (EditText) findViewById(R.id.phone_number);
        City = (AutoCompleteTextView) findViewById(R.id.city);
        State = (AutoCompleteTextView) findViewById(R.id.state);
        mGoogleApiClient = new GoogleApiClient.Builder(SettingActivity.this)
                .addApi(Places.GEO_DATA_API)
                .enableAutoManage(this, GOOGLE_API_CLIENT_ID, this)
                .addConnectionCallbacks(this)
                .build();
        Address = (AutoCompleteTextView) findViewById(R.id.address);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            SetPermissions();
        }
        City.setThreshold(1);
        Address.setThreshold(1);
        State.setThreshold(1);
        Address.setOnItemClickListener(mAutocompleteClickListener);
        City.setOnItemClickListener(mAutocompleteClickListener);
        State.setOnItemClickListener(mAutocompleteClickListener);
        AutocompleteFilter filter = new AutocompleteFilter.Builder().setCountry("AU").build();
        mPlaceArrayAdapter = new PlaceArrayAdapter(this, android.R.layout.simple_list_item_1,
                null, filter);
        Address.setAdapter(mPlaceArrayAdapter);
        City.setAdapter(mPlaceArrayAdapter);
        State.setAdapter(mPlaceArrayAdapter);
        Postal_Code = (EditText) findViewById(R.id.postal_code);
        Account_number = (EditText) findViewById(R.id.bank_account);
        Account_holder_name = (EditText) findViewById(R.id.account_name);
        BSB = (EditText) findViewById(R.id.bsb);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                hideKeyboard(SettingActivity.this);
            }
        }, 200);
        setText();

        Profile = (ImageView) findViewById(R.id.profile_img);
        getDefaultImg();

        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActionSheet.createBuilder(SettingActivity.this, getSupportFragmentManager())
                        .setCancelButtonTitle("Cancel")
                        .setOtherButtonTitles("Camera", "Gallery")
                        .setCancelableOnTouchOutside(true)
                        .setListener(SettingActivity.this).show();
            }
        });
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        UPDATE = (Button) findViewById(R.id.update);
        UPDATE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Account_holder_name.getText().length() > 0 && Account_number.getText().length() > 0 && BSB.length() > 0){
                    CreateNewStripeCustomer(Account_holder_name.getText().toString() ,
                            Account_number.getText().toString() ,
                            BSB.getText().toString() ,
                            login_parm.get("email"),
                            SettingActivity.this);
                }else if (First_name.getText().length() > 0 && Last_name.getText().length() > 0 &&
                        Phone_number.getText().length() > 0 && Address.getText().length() > 0) {
                    login_parm.put("first_name", First_name.getText().toString());
                    login_parm.put("last_name", Last_name.getText().toString());
                    login_parm.put("phone_number", Phone_number.getText().toString());
                    login_parm.put("address", Address.getText().toString());
                    login_parm.put("city", City.getText().toString());
                    login_parm.put("state", State.getText().toString());
                    login_parm.put("postal_code", Postal_Code.getText().toString());
                    new MakeAPICall(SettingActivity.this, login_parm, PostMethod, URLs.UpdateUserProfile, APIActions.ApiActions.document_update, SettingActivity.this).execute();
                } else {
                    Toast.makeText(getApplicationContext(), "all fields are required", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", SettingActivity.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", SettingActivity.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if(decodedByte != null){
                SharedPrefrences.SetString("profile_pic_base64", SharedPrefrences.getString("profile_pic_base64", SettingActivity.this), getApplicationContext());
                RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                roundDrawable.setCircular(true);
                Profile.setImageDrawable(roundDrawable);
                Log.d("image", SharedPrefrences.getString("profile_pic_base64", SettingActivity.this));
            }
        }else if(!SharedPrefrences.getString("profile_pic", SettingActivity.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , SettingActivity.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
    }
    private AdapterView.OnItemClickListener mAutocompleteClickListener
            = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            final PlaceArrayAdapter.PlaceAutocomplete item = mPlaceArrayAdapter.getItem(position);
            final String placeId = String.valueOf(item.placeId);
            Log.i(LOG_TAG, "Selected: " + item.description);
            PendingResult<PlaceBuffer> placeResult = Places.GeoDataApi
                    .getPlaceById(mGoogleApiClient, placeId);
            placeResult.setResultCallback(mUpdatePlaceDetailsCallback);
            Log.i(LOG_TAG, "Fetching details for ID: " + item.placeId);
        }
    };

    private ResultCallback<PlaceBuffer> mUpdatePlaceDetailsCallback
            = new ResultCallback<PlaceBuffer>() {
        @Override
        public void onResult(PlaceBuffer places) {
            if (!places.getStatus().isSuccess()) {
                Log.e(LOG_TAG, "Place query did not complete. Error: " +
                        places.getStatus().toString());
                return;
            }
            // Selecting the first object buffer.
            final Place place = places.get(0);
            try {
                if (Address.isFocused()) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                List<android.location.Address> addresses = getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude);
                               if(addresses != null && addresses.size() >0){
                                   City.setText(addresses.get(0).getLocality());
                                   Postal_Code.setText(addresses.get(0).getPostalCode());
                                   State.setText(addresses.get(0).getAdminArea());
                               }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }, 100);
                } else if (City.isFocused()) {
                    City.setText(getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude).get(0).getLocality());
                    Postal_Code.setText(getCityNameByCoordinates(place.getLatLng().latitude, place.getLatLng().longitude).get(0).getPostalCode());
                    State.requestFocus();
                } else {
                    State.setText(place.getName().toString());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public void onConnected(Bundle bundle) {
        mPlaceArrayAdapter.setGoogleApiClient(mGoogleApiClient);
        Log.i(LOG_TAG, "Google Places API connected.");

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.e(LOG_TAG, "Google Places API connection failed with error code: "
                + connectionResult.getErrorCode());

        Toast.makeText(this,
                "Google Places API connection failed with error code:" +
                        connectionResult.getErrorCode(),
                Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConnectionSuspended(int i) {
        mPlaceArrayAdapter.setGoogleApiClient(null);
        Log.e(LOG_TAG, "Google Places API connection suspended.");
    }
    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("countries.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public void ReadJSONfile(String country_name) {
        String[] cities = new String[0];
        switch (country_name) {
            case "New South Wales":
                cities = getApplicationContext().getResources().getStringArray(R.array.SW);
                break;
            case "Northern Territory":
                cities = getApplicationContext().getResources().getStringArray(R.array.NT);
                break;
            case "Queensland":
                cities = getApplicationContext().getResources().getStringArray(R.array.QL);
                break;
            case "South Australia":
                cities = getApplicationContext().getResources().getStringArray(R.array.SA);
                break;
            case "Tasmania":
                cities = getApplicationContext().getResources().getStringArray(R.array.TAS);
                break;
            case "Victoria":
                cities = getApplicationContext().getResources().getStringArray(R.array.VIC);
                break;
            case "Western Australia":
                cities = getApplicationContext().getResources().getStringArray(R.array.WA);
                break;
        }
        City_txt = cities[0];
    }

    public void setText() {
        City.setText(login_parm.get("city"));
        State.setText(login_parm.get("state"));
        First_name.setText(login_parm.get("first_name"));
        Last_name.setText(login_parm.get("last_name"));
        Address.setText(login_parm.get("address"));
        Postal_Code.setText(login_parm.get("postal_code"));
        Phone_number.setText(login_parm.get("phone_number"));
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(apiActions == APIActions.ApiActions.upload_img){
            Log.d("img==>",response.message + "\n"+"test");
        }else {
            if (response.status != null) {
                if (response.status.equalsIgnoreCase("true")) {
                    Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_LONG).show();
                }
            }
        }

    }
    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {
        Toast.makeText(getApplicationContext(), "Error occurs,please try it again later!!", Toast.LENGTH_LONG).show();
    }

    private List<android.location.Address> getCityNameByCoordinates(double lat, double lon) throws IOException {
        Geocoder mGeocoder = new Geocoder(SettingActivity.this, Locale.getDefault());
        List<android.location.Address> addresses = mGeocoder.getFromLocation(lat, lon, 1);
        return addresses;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void SetPermissions() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(SettingActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(SettingActivity.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) && ActivityCompat.shouldShowRequestPermissionRationale(SettingActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(SettingActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        12);
                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 12: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                }else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && null != data) {
            selectedImage = data.getData();
            filePathColumn = new String[]{MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            SharedPrefrences.SetString("profile_pic", picturePath, getApplicationContext());
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(picturePath));
            roundDrawable.setCircular(true);

            Bitmap bitmapOrg = BitmapFactory.decodeFile(picturePath);
            Bitmap bitmap = BITMAP_RESIZER(bitmapOrg, 80, 80);
            ByteArrayOutputStream bao = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 30, bao);
            byte[] ba = bao.toByteArray();
            String ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
            ba1 = ba1.replace("\n","");
            SharedPrefrences.SetString("profile_pic_base64", ba1, getApplicationContext());
            UploadImage(ba1);
            Profile.setImageDrawable(roundDrawable);
//            Profile_IMG.setImageBitmap(BitmapFactory.decodeFile(picturePath));
        } else if (requestCode == 9 && resultCode == RESULT_OK && data != null) {
            onCaptureImageResult(data);
        }
    }

    @Override
    public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

    }

    @Override
    public void onOtherButtonClick(ActionSheet actionSheet, int index) {
        if (index == 0) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, 9);
        } else {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_PICK);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);
//            Intent i = new Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//            startActivityForResult(i, 1);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        SharedPrefrences.SetString("profile_pic", destination.getAbsolutePath(), getApplicationContext());
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), thumbnail);
        roundDrawable.setCircular(true);


        Bitmap bitmap = BITMAP_RESIZER(thumbnail, 80, 80);
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 30, bao);
        byte[] ba = bao.toByteArray();
        String ba1 = Base64.encodeToString(ba, Base64.DEFAULT);
        ba1 = ba1.replace("\n","");
        SharedPrefrences.SetString("profile_pic_base64", ba1, getApplicationContext());
        UploadImage(ba1);
        Profile.setImageDrawable(roundDrawable);
    }



    public void UploadImage(String base64) {
        int length = base64.length()/30;
        String data_1 = base64.substring(0,length);
        String data_2 = base64.substring((length),(length*2));
        String data_3 = base64.substring((length*2),(length*3));
        String data_4 = base64.substring((length*3),(length*4));
        String data_5 = base64.substring((length*4),(length*5));

        String data_6 = base64.substring((length*5),(length*6));
        String data_7 = base64.substring((length*6),(length*7));
        String data_8 = base64.substring((length*7),(length*8));
        String data_9 = base64.substring((length*8),(length*9));
        String data_10 = base64.substring((length*9),(length*10));

        String data_11 = base64.substring((length*10),(length*11));
        String data_12 = base64.substring((length*11),(length*12));
        String data_13 = base64.substring((length*12),(length*13));
        String data_14 = base64.substring((length*13),(length*14));
        String data_15 = base64.substring((length*14),(length*15));

        String data_16 = base64.substring((length*15),(length*16));
        String data_17 = base64.substring((length*16),(length*17));
        String data_18 = base64.substring((length*17),(length*18));
        String data_19 = base64.substring((length*18),(length*19));
        String data_20 = base64.substring((length*19),(length*20));

        String data_21 = base64.substring((length*20),(length*21));
        String data_22 = base64.substring((length*21),(length*22));
        String data_23 = base64.substring((length*22),(length*23));
        String data_24 = base64.substring((length*23),(length*24));
        String data_25 = base64.substring((length*24),(length*25));

        String data_26 = base64.substring((length*25),(length*26));
        String data_27 = base64.substring((length*26),(length*27));
        String data_28 = base64.substring((length*27),(length*28));
        String data_29 = base64.substring((length*28),(length*29));
        String data_30 = base64.substring((length*29), base64.length());

        Map<String, String> parm_img = new HashMap<>();
        parm_img.put("img_id" , login_parm.get("img_id"));
        parm_img.put("data_1" , data_1);
        parm_img.put("data_2" , data_2);
        parm_img.put("data_3" , data_3);
        parm_img.put("data_4" , data_4);
        parm_img.put("data_5" , data_5);
        parm_img.put("data_6" , data_6);
        parm_img.put("data_7" , data_7);
        parm_img.put("data_8" , data_8);
        parm_img.put("data_9" , data_9);

        parm_img.put("data_10" , data_10);
        parm_img.put("data_11" , data_11);
        parm_img.put("data_12" , data_12);
        parm_img.put("data_13" , data_13);
        parm_img.put("data_14" , data_14);
        parm_img.put("data_15" , data_15);
        parm_img.put("data_16" , data_16);
        parm_img.put("data_17" , data_17);
        parm_img.put("data_18" , data_18);
        parm_img.put("data_19" , data_19);
        parm_img.put("data_20" , data_20);

        parm_img.put("data_21" , data_21);
        parm_img.put("data_22" , data_22);
        parm_img.put("data_23" , data_23);
        parm_img.put("data_24" , data_24);
        parm_img.put("data_25" , data_25);
        parm_img.put("data_26" , data_26);
        parm_img.put("data_27" , data_27);
        parm_img.put("data_28" , data_28);
        parm_img.put("data_29" , data_29);
        parm_img.put("data_30" , data_30);
        new UploadImageAPICall(SettingActivity.this, parm_img, PostMethod, URLs.UploadImage, APIActions.ApiActions.upload_img, SettingActivity.this).execute();
    }

    public void  CreateNewStripeCustomer(final String Account_holder_name, final String Account_number, final String BSB , final String Email , final StripeResponse response){
        ShowProgress(SettingActivity.this);
        com.stripe.Stripe.apiKey = "sk_test_n8hO8g8giswb1pE1OOpDliSC";
        com.stripe.android.Stripe stripe = new com.stripe.android.Stripe(SettingActivity.this);
        stripe.setDefaultPublishableKey("pk_test_2BdrpyDNN2Vy5r220T9xp2d3");
        BankAccount bank = new BankAccount(Account_number , "AU" , "AUD" , BSB);
        bank.setAccountHolderName(Account_holder_name);
        bank.setAccountHolderType("individual");
        stripe.createBankAccountToken(bank, new TokenCallback() {
            @Override
            public void onError(Exception error) {
                HideProgress();
                Toast.makeText(getApplicationContext(),error.getMessage() , Toast.LENGTH_LONG).show();
            }
            @Override
            public void onSuccess(Token token) {
               UpdateCustomer(token, response);
            }
        });
    }

    public void UpdateCustomer(final Token token , final StripeResponse response){
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    final Map<String, Object> customerParams = new HashMap<String, Object>();
                    customerParams.put("source", token.getId());
                    Customer customer = Customer.retrieve(login_parm.get("stripe_id"));
                    Log.d("custmer" , customer.getId());
                    customer.createBankAccount(customerParams);
                    response.getResponse(true);
                } catch (AuthenticationException e) {
                    e.printStackTrace();
                    ERRO_MSG = e.getMessage();
                    e.printStackTrace();
                    response.getResponse(false);
                } catch (InvalidRequestException e) {
                    ERRO_MSG = e.getMessage();
                    e.printStackTrace();
                    response.getResponse(false);
                } catch (APIConnectionException e) {
                    ERRO_MSG = e.getMessage();
                    e.printStackTrace();
                    response.getResponse(false);
                } catch (CardException e) {
                    ERRO_MSG = e.getMessage();
                    e.printStackTrace();
                    response.getResponse(false);
                } catch (APIException e) {
                    ERRO_MSG = e.getMessage();
                    e.printStackTrace();
                    response.getResponse(false);
                }
            }
        };
        thread.start();
}

    @Override
    public void getResponse(boolean status) {
        if(status){
            this.runOnUiThread(new Runnable() {
                public void run() {
                    HideProgress();
                    if (First_name.getText().length() > 0 && Last_name.getText().length() > 0 &&
                            Phone_number.getText().length() > 0 && Address.getText().length() > 0 &&
                            City.getText().length() > 0 && State.getText().length() > 0 && Postal_Code.getText().length() > 0) {
                        login_parm.put("first_name", First_name.getText().toString());
                        login_parm.put("last_name", Last_name.getText().toString());
                        login_parm.put("phone_number", Phone_number.getText().toString());
                        login_parm.put("address", Address.getText().toString());
                        login_parm.put("city", City.getText().toString());
                        login_parm.put("state", State.getText().toString());
                        login_parm.put("postal_code", Postal_Code.getText().toString());
                        new MakeAPICall(SettingActivity.this, login_parm, PostMethod, URLs.UpdateUserProfile, APIActions.ApiActions.document_update, SettingActivity.this).execute();
                    } else {
                        Toast.makeText(getApplicationContext(), "all fields are required", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else {
            this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    HideProgress();
                    Toast.makeText(getApplicationContext(),ERRO_MSG,Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
