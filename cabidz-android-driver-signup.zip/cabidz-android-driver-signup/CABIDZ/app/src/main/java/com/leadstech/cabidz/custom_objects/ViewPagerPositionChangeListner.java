package com.leadstech.cabidz.custom_objects;

/**
 * Created by dany on 04/04/2017.
 */

public interface ViewPagerPositionChangeListner {
      void updatePosition(int position);
}
