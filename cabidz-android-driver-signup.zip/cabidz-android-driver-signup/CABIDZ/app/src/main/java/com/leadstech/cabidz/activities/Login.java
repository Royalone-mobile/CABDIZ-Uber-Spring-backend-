package com.leadstech.cabidz.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginBehavior;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.leadstech.cabidz.R;
import com.leadstech.cabidz.cloud_apis.MakeAPICall;
import com.leadstech.cabidz.model.LoginResponse;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.URLs;
import com.stripe.Stripe;
import com.stripe.exception.APIConnectionException;
import com.stripe.exception.APIException;
import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.exception.InvalidRequestException;
import com.stripe.model.BankAccount;
import com.stripe.model.Customer;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.leadstech.cabidz.singleton.IntentGO.GOTO;
import static com.leadstech.cabidz.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.ShowProgress;

public class Login extends AppCompatActivity implements APIResponseListner {
    Button btn_Login, Forgot_Password;
    EditText Username, Password;
    ImageView header_img;
    ImageView FACEBOOK_BTN;
    private String socialID="";
    public static Map<String, String> login_parm = new HashMap<>();
    private CallbackManager callbackManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        FacebookSdk.sdkInitialize(getApplicationContext());
        callbackManager = CallbackManager.Factory.create();
        Username = (EditText) findViewById(R.id.username);
        Password = (EditText) findViewById(R.id.password);
        header_img = (ImageView) findViewById(R.id.header_img);
        FACEBOOK_BTN = (ImageView) findViewById(R.id.face_book_login);
        btn_Login = (Button) findViewById(R.id.login);
        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Username.length() > 0 && Password.length() > 0) {
                    Map<String, String> parm = new HashMap<String, String>();
                    parm.put("email", Username.getText().toString());
                    parm.put("password", Password.getText().toString());
                    new MakeAPICall(Login.this, parm, PostMethod, URLs.LoginURL, APIActions.ApiActions.log_in, Login.this).execute();
                } else {
                    Toast.makeText(getApplicationContext(), "username or password is missing!", Toast.LENGTH_LONG).show();
                }
            }
        });
        Forgot_Password = (Button) findViewById(R.id.forgot_password);
        Forgot_Password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GOTO(Login.this, ForgotPassword.class);
            }
        });

        FACEBOOK_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginManager.getInstance().logInWithPublishPermissions(Login.this, Arrays.asList("publish_actions , public_profile, email, user_birthday, user_friends"));
                LoginManager.getInstance().setLoginBehavior(LoginBehavior.NATIVE_ONLY);
                LoginManager.getInstance().registerCallback(callbackManager,
                        new FacebookCallback<LoginResult>() {
                            @Override
                            public void onSuccess(LoginResult loginResult) {
                                ShowProgress(Login.this);
                                try {
                                    AccessToken aToken = loginResult.getAccessToken();
                                    Log.d("FaceBook_token" , aToken.getToken());
                                    GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(),
                                            new GraphRequest.GraphJSONObjectCallback() {
                                                @Override
                                                public void onCompleted(JSONObject object, GraphResponse response) {
                                                    if (response != null) {
                                                        String firstNAme = "";
                                                        String lastName = "";
                                                        String userEmail = "";
                                                        String userGender = "";
                                                        try {
                                                            JSONObject data = response.getJSONObject();
                                                            if (data.has("id")) {
                                                                socialID = data.getString("id");
                                                            }
                                                            if (data.has("email")) {
                                                                String socialID = data.getString("email");
                                                            }
                                                            JSONObject userObj = new JSONObject();
                                                            try {
                                                                userObj.put("facebook_id", socialID);
                                                                userObj.put("issocial", "1");
                                                            } catch (JSONException e) {
                                                                e.printStackTrace();
                                                            }
                                                            HideProgress();
                                                            login_parm.put("device_token" , data.getString("id"));
                                                            login_parm.put("first_name" , data.getString("first_name"));
                                                            login_parm.put("last_name" , data.getString("last_name"));
                                                            login_parm.put("phone_number" , "");
                                                            login_parm.put("email" , data.getString("email"));
                                                            login_parm.put("password" , "");
                                                            login_parm.put("address" , "");
                                                            login_parm.put("city" , "");
                                                            login_parm.put("state" ,"");
                                                            login_parm.put("postal_code" ,"");
                                                            login_parm.put("driver_license_expiry" ,"" );
                                                            login_parm.put("driver_license_doc_ID" , "");
                                                            login_parm.put("driver_license_status" , "");
                                                            login_parm.put("RMS_driver_history" , "");
                                                            login_parm.put("RMS_doc_ID" , "");
                                                            login_parm.put("RMS_doc_status" , "");
                                                            login_parm.put("driver_authority_card" , "");
                                                            login_parm.put("driver_authority_card_doc_ID" ,"");
                                                            login_parm.put("driver_authority_card_status" , "");
                                                            login_parm.put("driver_proof_ID" ,"");
                                                            login_parm.put("driver_proof_doc_ID" , "");
                                                            login_parm.put("driver_proof_doc_status" , "");
                                                            login_parm.put("driver_license_backdoc_ID" , "");
                                                            login_parm.put("driver_license_back_doc_Status" , "");
                                                            login_parm.put("additional_information" , "");
                                                            login_parm.put("vehicle" , "");
                                                            login_parm.put("category" ,"");
                                                            login_parm.put("number_plate" , "");
                                                            login_parm.put("texi_company" ,"");
                                                            login_parm.put("img_id","");
                                                            login_parm.put("stripe_id","");
                                                            SharedPrefrences.SetBool("islogin", true, Login.this);
                                                            SharedPrefrences.SetBool("islogin_social", true, Login.this);
                                                            Toast.makeText(getApplicationContext(),"Login Successfully!!" , Toast.LENGTH_LONG).show();
                                                            GOTO(Login.this, LocationEnalment.class);
                                                            finish();
                                                        } catch (Exception e) {
                                                            e.printStackTrace();
                                                        }
                                                        if (LoginManager.getInstance() != null) {
                                                            LoginManager.getInstance().logOut();
                                                        }
                                                    }else{
                                                        Toast.makeText(getApplicationContext(),"No public data received from Facebook!!" , Toast.LENGTH_LONG).show();
                                                    }
                                                }

                                            });
                                    Bundle parameters = new Bundle();
                                    parameters.putString("fields", "id,first_name,last_name,email,gender, birthday, picture.width(300)");
                                    request.setParameters(parameters);
                                    request.executeAsync();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onCancel() {
                                Toast.makeText(getApplicationContext(),"Login Canceled" , Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onError(FacebookException error) {
                                Toast.makeText(getApplicationContext(),"Login Error" , Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 195278 || requestCode == 64206) {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }
    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if (response.status != null) {
            if (response.status.equalsIgnoreCase("true")) {
                LoginResponse  result_response = (LoginResponse) response;
                SharedPrefrences.SetBool("islogin", true, Login.this);
                login_parm.put("device_token" , result_response.getDevice_token());
                login_parm.put("first_name" , result_response.getProperty().getFirst_name());
                login_parm.put("last_name" , result_response.getProperty().getLast_name());
                login_parm.put("phone_number" , result_response.getProperty().getPhone_number());
                login_parm.put("email" , result_response.getProperty().getEmail());
                login_parm.put("password" , result_response.getProperty().getPassword());
                login_parm.put("address" , result_response.getProperty().getAddress());
                login_parm.put("city" , result_response.getProperty().getCity());
                login_parm.put("state" ,result_response.getProperty().getState());
                login_parm.put("postal_code" ,result_response.getProperty().getPostal_code());
                login_parm.put("driver_license_expiry" ,result_response.getProperty().getDriver_license_expiry() );
                login_parm.put("driver_license_doc_ID" , result_response.getProperty().getDriver_license_doc_ID());
                login_parm.put("driver_license_status" , result_response.getProperty().getDriver_license_status());
                login_parm.put("RMS_driver_history" , result_response.getProperty().getRMS_driver_history());
                login_parm.put("RMS_doc_ID" , result_response.getProperty().getRMS_doc_ID());
                login_parm.put("RMS_doc_status" , result_response.getProperty().getRMS_doc_status());
                login_parm.put("driver_authority_card" , result_response.getProperty().getDriver_authority_card());
                login_parm.put("driver_authority_card_doc_ID" ,result_response.getProperty().getDriver_authority_card_doc_ID());
                login_parm.put("driver_authority_card_status" , result_response.getProperty().getDriver_authority_card_status());
                login_parm.put("driver_proof_ID" ,result_response.getProperty().getDriver_proof_ID());
                login_parm.put("driver_proof_doc_ID" , result_response.getProperty().getDriver_proof_doc_ID());
                login_parm.put("driver_proof_doc_status" ,result_response.getProperty().getDriver_proof_doc_status());
                login_parm.put("driver_license_backdoc_ID" , result_response.getProperty().getDriver_license_backdoc_ID());
                login_parm.put("driver_license_back_doc_Status" , result_response.getProperty().getDriver_license_back_doc_Status());
                login_parm.put("additional_information" ,result_response.getProperty().getAdditional_information() );
                login_parm.put("vehicle" , result_response.getProperty().getVehicle());
                login_parm.put("category" , result_response.getProperty().getCategory());
                login_parm.put("number_plate" , result_response.getProperty().getNumber_plate());
                login_parm.put("texi_company" , result_response.getProperty().getTexi_company());
                login_parm.put("img_id",result_response.getProperty().getImg_id());
                login_parm.put("stripe_id",result_response.getProperty().getStripe_id());

                Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
                GOTO(Login.this, LocationEnalment.class);
                finish();
            } else {
                Password.setText("");
                if(response.message != null){
                    Toast.makeText(getApplicationContext(), response.message, Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            Toast.makeText(getApplicationContext(), "Connection Error", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {
        Log.d("response", response.response_data);
    }

    public void GetUserStripeData(String User_Email){
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    Stripe.apiKey = "sk_test_n8hO8g8giswb1pE1OOpDliSC";
                    Customer c =  Customer.retrieve("cus_AgShAEMICzOdFV");
                    BankAccount bank = (BankAccount) c.getSources().retrieve(c.getDefaultSource());
                    Log.d("bank" , bank.getAccountHolderName());
                    Log.d("email" ,c.getEmail());
                    Log.d("email" ,c.getDefaultCard());
                } catch (AuthenticationException e) {
                    e.printStackTrace();
                } catch (InvalidRequestException e) {
                    e.printStackTrace();
                } catch (APIConnectionException e) {
                    e.printStackTrace();
                } catch (CardException e) {
                    e.printStackTrace();
                } catch (APIException e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();
    }
}
