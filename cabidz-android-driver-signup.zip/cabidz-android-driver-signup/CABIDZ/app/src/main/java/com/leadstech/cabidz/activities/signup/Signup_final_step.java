package com.leadstech.cabidz.activities.signup;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.leadstech.cabidz.R;
import com.leadstech.cabidz.activities.Enterance;
import com.leadstech.cabidz.activities.LocationEnalment;
import com.leadstech.cabidz.activities.Login;
import com.leadstech.cabidz.activities.home.Home;
import com.leadstech.cabidz.cloud_apis.MakeAPICall;
import com.leadstech.cabidz.model.Response;
import com.leadstech.cabidz.singleton.APIActions;
import com.leadstech.cabidz.singleton.APIResponseListner;
import com.leadstech.cabidz.singleton.SharedPrefrences;
import com.leadstech.cabidz.singleton.StripeResponse;
import com.leadstech.cabidz.singleton.URLs;
import com.stripe.Stripe;
import com.stripe.android.TokenCallback;
import com.stripe.android.model.BankAccount;
import com.stripe.android.model.Token;
import com.stripe.exception.APIConnectionException;
import com.stripe.exception.APIException;
import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.exception.InvalidRequestException;
import com.stripe.model.Account;
import com.stripe.model.Customer;
import com.stripe.net.RequestOptions;

import java.util.HashMap;
import java.util.Map;

import static com.leadstech.cabidz.activities.Login.login_parm;
import static com.leadstech.cabidz.activities.signup.Signup_StepOne.parm;
import static com.leadstech.cabidz.singleton.StaticFunctios.HideProgress;
import static com.leadstech.cabidz.singleton.StaticFunctios.PostMethod;
import static com.leadstech.cabidz.singleton.StaticFunctios.ShowProgress;
import static com.leadstech.cabidz.singleton.StaticFunctios.hideKeyboard;

public class Signup_final_step extends AppCompatActivity implements APIResponseListner , StripeResponse {
    ImageView BACK;
    Button Finis_btn;
    String error_msg = "";
    ImageView Profile;
    TextView ERROR;
    EditText Account_number, Account_holder_name, BSB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_final_step);
        Account_number= (EditText) findViewById(R.id.bank_account);
        Account_holder_name= (EditText) findViewById(R.id.account_name);
        BSB= (EditText) findViewById(R.id.bsb);
        ERROR= (TextView) findViewById(R.id.error);
        BACK = (ImageView) findViewById(R.id.cross);
        BACK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Profile = (ImageView) findViewById(R.id.profile_img);
        getDefaultImg();
        Finis_btn = (Button) findViewById(R.id.finis);
        Finis_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(Account_number.getText().length() > 0 &&
                       Account_holder_name.getText().length() > 0 &&
                       BSB.getText().toString().length() > 0){
                     CreateNewStripeCustomer(Account_holder_name.getText().toString(),Account_number.getText().toString(),BSB.getText().toString(), parm.get("email"), Signup_final_step.this);
                  }else {
                   Toast.makeText(getApplicationContext(),"required fields are missing!!" , Toast.LENGTH_LONG).show();
               }
            }
        });
    }

    @Override
    public void onRequestSuccess(Response response, APIActions.ApiActions apiActions) {
        if(response.message != null && response.status.equalsIgnoreCase("true")){
            Toast.makeText(getApplicationContext(),response.message,Toast.LENGTH_SHORT).show();
            login_parm = parm;
            Intent i = new Intent(getApplicationContext(), Home.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        }else {
            Toast.makeText(getApplicationContext(), "Error occour while registration, try again later", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    public void onRequestError(Response response, APIActions.ApiActions apiActions) {

    }
    public void CreateAccount(){
        Thread thread = new Thread() {
            @Override
            public void run() {
                com.stripe.Stripe.apiKey = "sk_test_n8hO8g8giswb1pE1OOpDliSC";
                Map<String, Object> accountParams = new HashMap<String, Object>();
                accountParams.put("country", "AU");
                accountParams.put("managed", true);
                try {
                    Account ac = Account.create(accountParams);
                    Log.d("create", "crea" + ac.getId());
                } catch (AuthenticationException e) {
                    e.printStackTrace();
                } catch (InvalidRequestException e) {
                    e.printStackTrace();
                } catch (APIConnectionException e) {
                    e.printStackTrace();
                } catch (CardException e) {
                    e.printStackTrace();
                } catch (APIException e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();
    }
    public void  CreateNewStripeCustomer(final String Account_holder_name, final String Account_number, final String BSB , final String Email , final StripeResponse response){
        ShowProgress(Signup_final_step.this);
        final String[] customer_id = {""};
        com.stripe.Stripe.apiKey = "sk_test_n8hO8g8giswb1pE1OOpDliSC";
        com.stripe.android.Stripe stripe = new com.stripe.android.Stripe(Signup_final_step.this);
        stripe.setDefaultPublishableKey("pk_test_2BdrpyDNN2Vy5r220T9xp2d3");
        BankAccount bank = new BankAccount(Account_number , "US" , "USD" , BSB);
        bank.setAccountHolderName(Account_holder_name);
        bank.setAccountHolderType("individual");
        stripe.createBankAccountToken(bank, new TokenCallback() {
            @Override
            public void onError(Exception error) {
                error_msg = error.getMessage();
                response.getResponse(false);
            }
            @Override
            public void onSuccess(Token token) {
                CreateAccount();
                final Map<String, Object> customerParams = new HashMap<String, Object>();
                customerParams.put("email", Email);
                customerParams.put("source", token.getId());
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        Customer customer = null;
                        try {
                            customer = Customer.create(customerParams);
                            HideProgress();
                            parm.put("stripe_id" , customer.getId());
                            response.getResponse(true);
                        } catch (AuthenticationException e) {
                           error_msg = e.getMessage();
                            response.getResponse(false);
                        } catch (InvalidRequestException e) {
                            error_msg = e.getMessage();
                            response.getResponse(false);
                        } catch (APIConnectionException e) {
                            error_msg = e.getMessage();
                            response.getResponse(false);
                        } catch (CardException e) {
                            error_msg = e.getMessage();
                            response.getResponse(false);
                        } catch (APIException e) {
                            error_msg = e.getMessage();
                            response.getResponse(false);
                        }
                    }
                };
                thread.start();
            }

        });
    }

    @Override
    public void getResponse(boolean status) {
       if(status){
           this.runOnUiThread(new Runnable() {
               public void run() {
                   new MakeAPICall(Signup_final_step.this,parm,PostMethod, URLs.SignupURL, APIActions.ApiActions.signup,Signup_final_step.this).execute();
               }
           });
       }else {
           this.runOnUiThread(new Runnable() {
               public void run() {
                   HideProgress();
                   Toast.makeText(getApplicationContext(),error_msg,Toast.LENGTH_LONG).show();
                   if(error_msg.length() >3){
                       ERROR.setText(error_msg);
                   }
               }
           });
       }
    }
    public void getDefaultImg(){
        if(!SharedPrefrences.getString("profile_pic_base64", Signup_final_step.this).equalsIgnoreCase("null")){
            byte[] decodedString = Base64.decode(SharedPrefrences.getString("profile_pic_base64", Signup_final_step.this), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            if(decodedByte != null){
                SharedPrefrences.SetString("profile_pic_base64", SharedPrefrences.getString("profile_pic_base64", Signup_final_step.this), getApplicationContext());
                RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), decodedByte);
                roundDrawable.setCircular(true);
                Profile.setImageDrawable(roundDrawable);
                Log.d("image", SharedPrefrences.getString("profile_pic_base64", Signup_final_step.this));
            }
        }else if(!SharedPrefrences.getString("profile_pic", Signup_final_step.this).equalsIgnoreCase("null")){
            RoundedBitmapDrawable roundDrawable = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeFile(SharedPrefrences.getString("profile_pic" , Signup_final_step.this)));
            roundDrawable.setCircular(true);
            Profile.setImageDrawable(roundDrawable);
        }
    }
}
